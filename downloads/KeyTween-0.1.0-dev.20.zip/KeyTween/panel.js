(function(){
  'use strict';
  const BUILD='0.1.0-dev.20',$=id=>document.getElementById(id);
  const events=[],openedAt=Date.now();
  function log(message){events.push(new Date().toLocaleTimeString()+'  '+message);if(events.length>200)events.shift();$('log').textContent=events.join('\n');$('log').scrollTop=$('log').scrollHeight;}
  function copyText(value){const box=$('clipboard');box.hidden=false;box.value=value;box.select();const copied=document.execCommand('copy');if(copied)box.hidden=true;return copied;}
  function status(title,message,error){$('state').textContent=title;$('message').textContent=message;document.querySelector('.status').className='status'+(error?' error':'');log(title+' · '+message);if(error)$('last-error').textContent=new Date().toLocaleString()+'\n'+title+'\n'+message;}
  $('log').onclick=()=>copyText(events.join('\n'));
  $('last-error').onclick=()=>copyText($('last-error').textContent);
  $('settings-open').onclick=()=>{$('settings-modal').hidden=false;$('settings-close').focus();};
  $('settings-close').onclick=()=>{$('settings-modal').hidden=true;$('settings-open').focus();};
  document.addEventListener('keydown',e=>{if(e.key==='Escape')$('settings-close').onclick();});
  function preview(){log('Preview only · Coop actions do not change files.');}
  for(const el of document.querySelectorAll('[data-preview]')){el.title='Preview only · not implemented';el[el.tagName==='INPUT'?'onchange':'onclick']=preview;}
  for(const el of document.querySelectorAll('[data-language-remove]'))el.onclick=()=>{el.parentNode.remove();preview();};
  $('add-language').onclick=()=>{const row=document.createElement('div');row.className='language-row';const name=document.createElement('input');name.value='EN';name.setAttribute('aria-label','Preview language');name.maxLength=3;row.appendChild(name);const remove=document.createElement('button');remove.className='tiny';remove.textContent='×';remove.setAttribute('aria-label','Remove preview language');remove.onclick=()=>{row.remove();preview();};row.appendChild(remove);$('language-rows').appendChild(row);preview();};
  $('english').onchange=()=>{$('english').checked=true;};$('german').onchange=()=>{$('german').checked=false;log('German translation is still in development.');};
  if(!window.__adobe_cep__||!window.cep_node){status('Adobe host required','Use the local Install / Update helper, then Window → Extensions → KeyTween in both Adobe applications.',true);return;}
  const req=window.cep_node.require,fs=req('fs'),path=req('path'),url=req('url');
  const base=path.dirname(decodeURIComponent(window.location.pathname));
  const storage=req(path.join(base,'src/storage/store.js')),store=new storage.Store();
  const feedback=req(path.join(base,'src/storage/feedback.js')),bridge=req(path.join(base,'host-bridge.js')),images=req(path.join(base,'src/storage/images.js')),placement=req(path.join(base,'src/storage/placement.js'));
  const nativeImages=req(path.join(base,'src/storage/native-images.js')),tree=req(path.join(base,'src/shared/tree.js'));
  const compatibility=req(path.join(base,'src/storage/compatibility.js'));
  const vectorProofs=new Map();
  let compatibilityResult=null,compatibilityPolling=false;
  let activeComposition=null,imagePolling=false,imageProcessing=null;
  const env=JSON.parse(window.__adobe_cep__.getHostEnvironment()),host=env.appId;
  const otherHost=host==='AEFT'?'FLPR':'AEFT',otherName=host==='AEFT'?'Animate':'After Effects';
  let sessionActive=false,hostPending=false,busy=false,last=null,lastBridge=null,scriptReady=false,failure=null,lastFailure=null,lastExample=null,operation=null,peerKey=null,reportError=null;
  const pendingReports=[];
  let hostInfo={host:host==='AEFT'?'After Effects':'Animate',version:env.appVersion,source:'CEP environment',scriptVerified:false};
  function snapshot(){
    let d;try{d=store.diagnostics(BUILD,host,last);}catch(e){d={product:'KeyTween',build:BUILD,host,error:e.message};}
    return feedback.redact(Object.assign(d,{actionLog:events.slice(-80),imageProcessing,compatibility:compatibilityResult,hostRuntime:hostInfo,hostScriptReady:scriptReady,hostBridge:lastBridge,hostRequest:hostPending||null,operation,example:lastExample,failure,lastFailure,reportError}));
  }
  function flushReports(){
    try{
      while(pendingReports.length){const r=pendingReports[0];store.saveFeedback(r.diagnostics,r.event);pendingReports.shift();}
      reportError=null;$('autosave').textContent='Automatically saved: Working Folder → feedback → KeyTween-feedback.jsonl';$('autosave').className='hint';
    }catch(e){reportError={message:e.message};$('autosave').textContent='Report not saved: '+e.message+' Pending details are included in Copy Diagnostics. Leave this panel open to retry.';$('autosave').className='hint report-error';}
  }
  function record(event){if(event.type==='host-reply')log(event.action+' · '+event.code);pendingReports.push({diagnostics:snapshot(),event:feedback.redact(Object.assign({at:new Date().toISOString()},event))});flushReports();}
  async function call(action,args,quiet){
    if(hostPending)throw Error('The Adobe host is still processing the previous request. Wait for it to finish; no new request was sent.');
    hostPending={action,startedAt:new Date().toISOString()};
    const scriptFile=path.join(base,'host',host==='AEFT'?'ae.jsx':'animate.jsfl');
    try{return await bridge.call({host,build:BUILD,action,args,requestId:storage.id(),scriptPath:host==='AEFT'?scriptFile:url.pathToFileURL(scriptFile).href,
      evalScript:(code,callback)=>window.__adobe_cep__.evalScript(code,callback),
      onRecord:r=>{if(quiet)return;lastBridge=r;scriptReady=r.hostScriptResponded===true;record({type:'host-reply',action,code:r.code});}
    });}finally{hostPending=false;}
  }
  function showResult(r){last=r;$('report').textContent=JSON.stringify(r?{build:BUILD,host:r.host,transferId:r.transferId,status:r.status,representation:r.representation,artworkVerification:r.artworkVerification,verification:r.verification,publish:r.publish,error:r.error,line:r.line,progress:r.progress,timeline:r.timeline,anchor:r.anchor,layers:r.layers,counts:r.counts,warnings:r.warnings}:'No host test has run.',null,2);$('results').open=true;}
  function paintPeer(p){
    $('connection-dot').className='connection-dot '+p.state;
    $('connection-label').textContent=p.state==='ready'?'open':p.state==='failed'?'error':/busy/.test(p.reason)?'busy':'not ready';$('connection-label').title=otherName+': '+p.reason;
    const next=JSON.stringify(p);if(next!==peerKey){peerKey=next;log(otherName+' · '+p.reason);record({type:'peer-status',peer:p});}
  }
  async function pollComposition(){
    imagePolling=true;
    try{
      const r=await call('composition-info',{},true);activeComposition=r.composition||null;
      if(compatibilityResult&&(!activeComposition||!compatibilityResult.composition||activeComposition.id!==compatibilityResult.composition.id)){
        compatibilityResult=null;paintCompatibility({state:'unknown',rows:[],reason:'Composition changed; choose check composition to refresh.',composition:activeComposition});
      }
      if(!busy)paintImageSettings();
    }catch(e){
      scriptReady=false;failure={message:e.message,operation:'Composition status',bridge:e.bridge||null,at:new Date().toISOString()};lastFailure=failure;
      status('Adobe connection paused','Composition status could not be read. Use Check Setup to reconnect. '+e.message,true);record({type:'host-poll-failed',error:e.message});
    }finally{imagePolling=false;}
  }
  function refresh(pollHost=true){
    // CEP can restore a docked panel while Adobe is still starting. Until the
    // user connects, do not dispatch scripts, read the working drive or replay messages.
    if(!sessionActive)return;
    if(pendingReports.length)flushReports();
    try{
      const c=store.config();store.root();if(!busy){const prefs=store.settings();$('create-new').checked=prefs.createNew;$('match-canvas').checked=prefs.matchCanvas;}$('folder').textContent=c.root;$('sync').hidden=!/Mobile Documents|CloudStorage|iCloud|Dropbox|OneDrive/.test(c.root);
      store.heartbeat(host,BUILD,busy||!!hostPending,scriptReady,failure||reportError);paintPeer(store.peer(otherHost,BUILD));
      if(!busy&&!hostPending&&scriptReady)serviceMessages();
      if(!busy){paintImageSettings();if(pollHost&&host==='AEFT'&&scriptReady&&!hostPending&&!imagePolling)pollComposition();}
      if(!busy&&host==='AEFT'&&last&&last.status==='waiting'){
        const delivery=store.message('delivery');if(delivery&&delivery.id===last.transferId&&delivery.state==='failed'){last={transferId:delivery.id,status:'failed',error:delivery.error};showResult(last);status('Push stopped',delivery.error,true);record({type:'delivery-failed',error:delivery.error});return;}
        if(delivery&&delivery.id===last.transferId&&delivery.state==='pending'&&Date.now()-delivery.time>15000){const peer=store.peer('FLPR',BUILD);if(!peer.available&&!/busy/.test(peer.reason)){store.message('delivery',Object.assign({},delivery,{state:'failed',error:'Animate panel is not open and ready. Reopen it and push again.'}));return;}}
        const r=store.recentResult();if(r&&r.transferId===last.transferId){showResult(r);const passed=!!(r.verification&&r.verification.pass);if(r.batch&&r.completed)importedStatus(r,false);else if(r.status==='imported-artwork-review')importedStatus(r,false);else if(r.status==='imported-review-required')status('Imported · opacity review','Animate saved the FLA. Geometry, anchor and timing pass; opacity readback needs review.');else status(passed?'Transform check passed':'Needs Attention',r.error||'Animate returned a report. Inspect its timeline; feedback is saved automatically.',!passed);record({type:'transfer-result',status:r.status});}
      }
    }catch(e){paintPeer({ready:false,state:'failed',reason:e.message});}
  }
  async function run(label,fn,lock,recovery){
    if(!sessionActive&&fn!==check){status('Connect KeyTween','Finish opening Adobe, then click Connect KeyTween.');return;}
    if(hostPending&&!busy){status('Waiting for Adobe','The previous host request has not finished. No new request was sent.');return;}
    if(busy)return;busy=true;let release=null,failed=false;
    sessionActive=true;
    operation={id:storage.id(),label,example:host==='AEFT'?$('example').value:null};
    for(const b of document.querySelectorAll('button,input,select'))b.disabled=!/^(log|last-error|copy|settings-close)$/.test(b.id);
    record({type:'operation-start',operation});
    try{if(lock)release=store.lock(label);refresh();status(label,'Working locally…');await fn();if(recovery)failure=null;}
    catch(e){if(fn===check)scriptReady=false;failed=true;failure={message:e.message,operation:label,bridge:e.bridge||null,at:new Date().toISOString()};lastFailure=failure;status('Needs Attention',e.message,true);showResult(e.result||{status:'failed',error:e.message,host:hostInfo});}
    finally{
      if(release){try{release();}catch(e){failed=true;failure={message:e.message,operation:'Release operation lock'};lastFailure=failure;status('Needs Attention',e.message,true);}}
      busy=false;record({type:failed?'operation-failed':'operation-complete',operation,error:failed?failure:null});operation=null;
      for(const b of document.querySelectorAll('button,input,select'))b.disabled=false;refresh(false);
    }
  }
  async function check(){scriptReady=false;hostInfo=await call('info');hostInfo.scriptVerified=true;$('host').textContent=hostInfo.host+' '+hostInfo.version;store.root();scriptReady=true;$('startup').hidden=true;status('Ready · '+BUILD,'Both panels share local transfers. Push selected layers or the composition; Animate can request a fresh composition.');}
  $('ae-actions').hidden=host!=='AEFT';$('an-actions').hidden=host!=='FLPR';$('ae-testing').hidden=host!=='AEFT';
  for(const id of ['ae-canvas','image-handling','compatibility','coop','ae-settings','load-example'])$(id).hidden=host!=='AEFT';$('an-destination').hidden=host!=='FLPR';$('peer-name').textContent=otherName.toLowerCase();$('ready-icon').src='assets/ready-'+(host==='AEFT'?'ae':'an')+'.svg';
  $('check').onclick=()=>run('Checking Setup',check,false,true);
  $('connect').onclick=$('check').onclick;
  $('load-example').onclick=()=>run('Loading Test Example',async()=>{
    store.root();const asset=store.at('tests/bitmap-proof.png');if(!fs.existsSync(asset))fs.copyFileSync(path.join(base,'fixtures/bitmap-proof.png'),asset);
    lastExample={requested:$('example').value};const r=await call('example',{asset,easing:$('example').value});lastExample=r;status('Example loaded',r.message);
  },true,true);
  function paintCompatibility(r){
    const list=$('compatibility-list');list.textContent='';list.className='compatibility-box '+r.state;
    $('compatibility-dot').className='compatibility-dot '+r.state;$('compatibility-dot').setAttribute('aria-label',r.state==='supported'?'All layers are supported':r.state==='unsupported'?'Unsupported layers':r.state==='pending'?'Vector conversion check pending':'Not checked');
    if(r.state==='supported'){const label=document.createElement('span');label.textContent='all layers are supported';list.appendChild(label);}
    else {
      if(r.reason||!r.rows.length){const label=document.createElement('span');label.textContent=r.reason||'The composition has no layers.';list.appendChild(label);}
      for(const row of r.rows.filter(row=>row.status!=='supported')){const item=document.createElement('div');item.className='compatibility-row';const title=document.createElement('strong');title.textContent='layer '+row.index+': '+row.name;const reason=document.createElement('span');reason.className='compatibility-reason';reason.textContent=row.reason||'Support could not be determined.';item.appendChild(title);item.appendChild(reason);list.appendChild(item);}
    }
    $('compatibility-note').textContent=(r.composition?r.composition.name+' · ':'')+'Read-only check of current support rules. Transfer also checks native motion and artwork conversion.';
  }
  async function scanCompatibility(){
    if(host!=='AEFT'||compatibilityPolling)return;
    if(!scriptReady)throw Error('Use Check Setup to reconnect before checking composition.');
    compatibilityPolling=true;
    try{
      const r=compatibility.evaluate(await call('compatibility',{}),store.settings(),vectorProofs);
      compatibilityResult=r;paintCompatibility(r);
      log('Compatibility · '+r.rows.filter(x=>x.status==='unsupported').length+' unsupported, '+r.rows.filter(x=>x.status==='pending').length+' pending.');record({type:'compatibility-check',report:r});
    }catch(e){const r={state:'unknown',rows:[],reason:'Compatibility check failed: '+e.message,composition:null};compatibilityResult=r;paintCompatibility(r);throw e;}
    finally{compatibilityPolling=false;}
  }
  $('check-compatibility').onclick=()=>run('Checking compatibility',scanCompatibility,false,false);
  async function exportBatch(scope,deliver){
    if(deliver){const peer=store.peer('FLPR',BUILD);if(!peer.available)throw Error('Animate panel is not open and ready. Open Window → Extensions → KeyTween in Animate. '+peer.reason);}
    const pending=store.message('delivery');if(deliver&&validMessage(pending)&&/^(pending|importing)$/.test(pending.state))throw Error('A push is already queued or importing. Open Animate and wait for its result first.');
    const renderFolder=fs.mkdtempSync(store.at('cache/precomp-'));
    try{
    const colorReferenceFile=path.join(renderFolder,'colour-reference.png');fs.writeFileSync(colorReferenceFile,nativeImages.referencePNG(),{flag:'wx'});
    const raw=await call('export',{scope,renderFolder,colorReferenceFile}),settings=store.settings();compatibility.rememberVectors(raw,vectorProofs);activeComposition=raw.composition;
    record({type:'raster-render-colour',renders:tree.flatten(raw.items).filter(item=>item.flattenedPSD&&item.flattenedPSD.render).map(item=>({layerId:item.layer.id,render:item.flattenedPSD.render}))});
    status('Preparing images','Resizing locally to '+(settings.imageMaxSide||Math.max(raw.composition.width,raw.composition.height))+' px on the longest side…');
    const prepared=await images.prepare(raw,settings,nativeImages.converter(store));prepared.settings=settings;imageProcessing=prepared.summary;record({type:'images-prepared',images:imageProcessing});
    const queued=store.queue(raw,BUILD,prepared);
    for(const item of imageProcessing)log(item.name+': '+item.sourceSize.join('×')+' → '+item.pixelSize.join('×')+' px ('+item.operation+', sRGB).' );
    if(deliver){const peer=store.peer('FLPR',BUILD);if(!peer.available)throw Error('Animate panel closed or became busy during export. Nothing was sent; reopen the panel and push again.');store.message('delivery',{id:queued.id,state:'pending',build:BUILD,time:Date.now()});}
    last={transferId:queued.id,status:'waiting',host:hostInfo,warnings:raw.warnings};
    status('Queued for Animate',raw.items.length+' layers ready. Keep the Animate panel open to receive them.');return queued;
    }finally{fs.rmSync(renderFolder,{recursive:true,force:true});}
  }
  function paintImageSettings(){
    const s=store.settings();$('upscale-images').checked=s.upscaleImages;$('place-images').checked=s.placeImages;
    const limit=s.imageMaxSide||(activeComposition?Math.max(activeComposition.width,activeComposition.height):null);
    if(document.activeElement!==$('image-limit'))$('image-limit').value=limit?limit+'px':'auto';
    $('image-auto').textContent='auto: '+(activeComposition?Math.max(activeComposition.width,activeComposition.height)+' px · '+activeComposition.width+'×'+activeComposition.height:'open an AE composition')+(s.imageMaxSide?' · use auto':'');
    const dir=s.imageFolder||store.at('_Links');$('image-folder-name').textContent=path.basename(dir);$('image-folder').title='Choose image folder · '+dir;$('image-folder-path').textContent=dir;
    $('image-summary').textContent=(s.imageMaxSide?'Manual limit. ':'Automatic composition limit. ')+(s.upscaleImages?'Smaller images will be upscaled.':'Smaller images stay unchanged.')+' PNG, JPG, PSD, TIFF → sRGB PNG. Layer size and animation stay the same.';
  }
  function imageSetting(label,value){return run(label,async()=>{store.settings(value);status('Image handling saved','Applies to the next Push, Pull or Update Layers.');},true,false);}
  $('upscale-images').onchange=()=>imageSetting('Image upscaling',{upscaleImages:$('upscale-images').checked});
  $('place-images').onchange=()=>imageSetting('Image placement',{placeImages:$('place-images').checked});
  $('image-auto').onclick=()=>imageSetting('Automatic image size',{imageMaxSide:null});
  $('image-limit').onchange=()=>run('Image size limit',async()=>{const text=$('image-limit').value.trim().toLowerCase();let limit=null;if(text&&text!=='auto'){if(!/^[0-9]+(?:px)?$/.test(text))throw Error('Enter a whole pixel size or auto.');limit=Number(text.replace(/px$/,''));images.plan({width:1,height:1},[1,1],{imageMaxSide:limit});}store.settings({imageMaxSide:limit});status('Image limit saved',limit?limit+' px on the longest side.':'Follows the active AE composition.');},true,false);
  $('image-folder').onclick=()=>run('Choosing image folder',async()=>{const picked=await call('choose-folder',{purpose:'images'});if(!picked.path)return;placement.folder(store,{imageFolder:picked.path},false);store.settings({imageFolder:picked.path,placeImages:true});status('Image folder saved','New prepared image copies will be stored here and imported from here into Animate.');},true,false);
  $('reset-image-folder').onclick=()=>imageSetting('Default image folder',{imageFolder:null});
  $('open-images').onclick=()=>run('Opening image folder',async()=>{const dir=placement.folder(store,store.settings(),true);const error=window.cep.util.openURLInDefaultBrowser(url.pathToFileURL(dir).href);if(error)throw Error('Could not open the image folder (CEP code '+error+').');},false,false);
  $('push').onclick=()=>run('Push Selection',()=>exportBatch('selection',true),true,true);
  $('push-composition').onclick=()=>run('Push Composition',()=>exportBatch('composition',true),true,true);
  // Settings are loaded by refresh only after the explicit connection.
  $('match-canvas').onchange=()=>run('Canvas setting',async()=>{store.settings({matchCanvas:$('match-canvas').checked});status('Canvas setting saved',$('match-canvas').checked?'Match the open canvas size to AE. Existing animation requires matching FPS.':'Keep the open canvas size. Layer coordinates remain in AE pixels.');},true,false);
  $('create-new').onchange=()=>run('Destination setting',async()=>{store.settings({createNew:$('create-new').checked});status('Destination updated',$('create-new').checked?'Pulls and pushes create a new matching file.':'Pulls and pushes add missing layers to the current matching Canvas.');},true,false);
  async function importEntry(entry,options){
    options.matchCanvas=store.settings().matchCanvas;const args=store.prepareImport(entry,BUILD,options);
    if(args.batch&&!args.createNew&&!args.existingResult){
      const prepared=await call('prepare-import',args);
      try{args.recoveryProof=req(path.join(base,'src/storage/recovery.js')).verify(prepared,args);record({type:'recovery-verified',checks:prepared.recoveryChecks,proof:args.recoveryProof});}
      catch(e){prepared.status='failed';prepared.error=e.message;prepared.progress={phase:'recovery-verification'};store.receipt(prepared);e.result=prepared;throw e;}
    }
    const r=args.existingResult||await call('import',args);
    if(!args.existingResult)store.receipt(r);showResult(r);importedStatus(r,!!args.existingResult);return r;
  }
  function validMessage(m){return m&&m.build===BUILD&&Number.isFinite(m.time)&&m.time<=Date.now()+5000&&Date.now()-m.time<180000;}
  function serviceMessages(){
    // Poll later when another panel owns the lock; do not recurse into run's cleanup.
    if(fs.existsSync(store.locator+'.lock'))return;
    if(host==='AEFT'){
      const request=store.message('ae-request');
      if(validMessage(request)&&request.state==='pending'&&request.time<openedAt){store.message('ae-request',Object.assign({},request,{state:'failed',error:'AE panel was reopened after this request. Pull again; stale requests are not exported.'}));log('Earlier AE request cancelled after panel reopen. Pull again.');return;}
      if(validMessage(request)&&request.state==='pending')run('Export requested composition',async()=>{
        store.message('ae-request',Object.assign({},request,{state:'exporting'}));
        try{const queued=await exportBatch('composition',false);store.message('ae-request',Object.assign({},request,{state:'ready',transferId:queued.id}));}
        catch(e){store.message('ae-request',Object.assign({},request,{state:'failed',error:e.message}));throw e;}
      },true,true);
    }else{
      const delivery=store.message('delivery');
      if(validMessage(delivery)&&delivery.state==='pending'&&delivery.time<openedAt){store.message('delivery',Object.assign({},delivery,{state:'failed',error:'Animate panel was reopened after this push. Push again; stale deliveries are not imported.'}));log('Earlier push cancelled after panel reopen. Push again.');return;}
      if(validMessage(delivery)&&delivery.state==='pending')run('Receiving AE layers',async()=>{
        store.message('delivery',Object.assign({},delivery,{state:'importing'}));
        try{const createNew=store.settings().createNew,target=createNew?{}:await call('target');if(!createNew&&target.id==null)throw Error('Open the intended Animate Canvas first, or enable Create new file on pull.');await importEntry({id:delivery.id},{createNew,targetId:target.id,mode:'pull'});store.message('delivery',Object.assign({},delivery,{state:'complete'}));}
        catch(e){store.message('delivery',Object.assign({},delivery,{state:'failed',error:e.message}));throw e;}
      },true,true);
    }
  }
  async function requestComposition(mode){
    const peer=store.peer('AEFT',BUILD);if(!peer.available)throw Error('Open the matching AE panel and wait for its green Ready dot. '+peer.reason);
    const createNew=mode==='pull'&&store.settings().createNew,target=createNew?{}:await call('target');
    if(!createNew&&target.id==null)throw Error('Open the intended Animate Canvas first, or enable Create new file on pull.');
    const request={id:storage.id(),build:BUILD,time:Date.now(),state:'pending',mode};
    let unlock=store.lock('Request AE composition');try{const pending=store.message('ae-request');if(validMessage(pending)&&/^(pending|exporting)$/.test(pending.state))throw Error('An AE request is already in progress.');store.message('ae-request',request);}finally{unlock();}
    status('Waiting for AE','Exporting the currently open composition, including all visible layers…');
    // Do not hold the shared operation lock while the AE panel is doing its export.
    while(Date.now()-request.time<180000){
      const reply=store.message('ae-request');if(!reply||reply.id!==request.id)throw Error('The local AE request was replaced or its working folder changed.');
      if(reply.state==='failed')throw Error(reply.error||'AE export failed.');
      if(reply.state==='ready'){
        unlock=store.lock('Import requested composition');try{store.message('ae-request',Object.assign({},reply,{state:'consuming'}));await importEntry({id:reply.transferId},{mode,createNew,targetId:target.id});store.message('ae-request',Object.assign({},reply,{state:'complete'}));}finally{unlock();}return;
      }
      await new Promise(resolve=>setTimeout(resolve,500));
    }
    throw Error('AE did not complete the request within three minutes. Inspect both panels; this request will not be imported automatically.');
  }
  function importedStatus(r,already){
    if(r.batch){if(!r.completed){const e=Error(r.error||'Batch stopped; inspect per-layer results.');e.result=r;throw e;}status('Layers transferred · review',r.counts.added+' added · '+r.counts.updated+' images updated · '+r.counts.unchanged+' retained. '+(r.saved?'New FLA saved.':'Save the current document when satisfied.')+' Check text, vector artwork and native tweens.');return;}
    if(r.status==='failed') {const e=Error(r.error||'Animate could not finish the import.');e.result=r;throw e;}
    if(r.saved&&r.status==='imported-artwork-review'){const text=r.artwork==='editable-text';status(text?'Imported · text layout review':'Imported · vector appearance review',text?'Native text is saved. Double-click the symbol, then edit with the Text tool. Compare baseline and spacing with AE.':'Native vectors are saved inside the tween symbol. Open the nested artwork and edit its paths; compare strokes, holes and overlaps with AE.');return;}
    if(r.verification&&r.verification.pass){status(already?'Already imported · checks passed':'Transform check passed','Test FLA saved. Inspect the classic tweens. Feedback is saved automatically.');return;}
    if(r.saved&&r.status==='imported-review-required'){status(already?'Already imported · opacity review':'Imported · opacity review','Geometry, anchor and timing pass. Opacity readback needs review; the FLA is saved. See Test result for measured errors.');return;}
    const e=Error(r.error||'Import needs verification review. Details have been saved automatically.');e.result=r;throw e;
  }
  $('import').onclick=()=>run('Pull from AE',()=>requestComposition('pull'),false,true);
  $('update').onclick=()=>run('Update Layers',()=>requestComposition('update'),false,true);
  $('choose').onclick=()=>run('Choosing Working Folder',async()=>{const result=await call('choose-folder');if(!result.path){status('Folder unchanged','Folder selection cancelled.');return;}store.choose(result.path,$('migration').value);peerKey=null;refresh();status('Working Folder updated','Both panels will use this setting. Feedback is saved in this folder too.');},false,false);
  $('open-folder').onclick=()=>run('Opening Working Folder',async()=>{const folder=store.root();const error=window.cep.util.openURLInDefaultBrowser(url.pathToFileURL(folder).href);if(error)throw Error('Could not open the folder (CEP code '+error+'). The path is shown in Storage.');status('Working Folder',folder);},false,false);
  $('clean').onclick=()=>run('Cleanup Preview',async()=>{const r=store.cleanupPreview(),u=store.usage();$('usage').textContent=Object.keys(u).map(k=>k+': '+(u[k]/1048576).toFixed(2)+' MB').join('\n')+'\n\n'+r.message;status('Nothing marked disposable',r.message);},true,false);
  function diagnostics(){let history;try{history=store.feedback();history.events=history.events.slice(-20);}catch(e){history={error:e.message};}return JSON.stringify(feedback.redact({current:snapshot(),history,pendingReports}),null,2);}
  $('copy').onclick=()=>{if(copyText(diagnostics()))log('Full diagnostics copied.');else status('Copy Diagnostics','Select this text and press Cmd+C.');};
  $('save').onclick=()=>{record({type:'manual-snapshot'});status(reportError?'Report not saved':'Feedback saved',reportError?reportError.message:'Updated the same automatic feedback file. You can simply ask me to read the latest report.',!!reportError);};
  window.addEventListener('beforeunload',()=>{if(!sessionActive)return;record({type:'panel-closed'});try{store.heartbeat(host,BUILD,false,scriptReady,failure,true);}catch(ignored){}});
  setInterval(refresh,2000);
  $('connection-label').textContent='not connected';
  status('Connect KeyTween','After Adobe has finished opening, click Connect KeyTween in each panel.');
}());
