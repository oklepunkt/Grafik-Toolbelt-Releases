'use strict';
const fs=require('fs'),path=require('path'),cp=require('child_process'),crypto=require('crypto'),Metadata=require('./image-metadata'),RenderColour=require('./render-colour');
const SRGB='/System/Library/ColorSync/Profiles/sRGB Profile.icc',GRAY='/System/Library/ColorSync/Profiles/Generic Gray Gamma 2.2 Profile.icc';
function profile(){if(process.platform!=='darwin'||!fs.existsSync('/usr/bin/sips')||!fs.existsSync(SRGB))throw Error('Local sRGB conversion requires macOS ColorSync and its sRGB profile. No unconverted image will be exported.');return fs.readFileSync(SRGB);}
function run(args,tmp){return new Promise((resolve,reject)=>cp.execFile('/usr/bin/sips',args,{timeout:60000,maxBuffer:256*1024,env:Object.assign({},process.env,{LC_ALL:'C',TMPDIR:tmp})},(error,stdout,stderr)=>{if(error)return reject(Error('Local image conversion failed: '+(stderr||error.message).slice(0,1500)));resolve(stdout);}));}
function converter(store){const icc=profile(),outputProfiles=new Map();return async function(data,format,size,target,metadata){
 const temp=fs.mkdtempSync(store.at('cache/image-')),source=path.join(temp,'source.'+format),outputFormat='png',output=path.join(temp,'output.'+outputFormat),proof=path.join(temp,'output.icc');
 try{
  if(metadata.aeRender&&metadata.aeRender.requireEmbeddedProfile&&!metadata.icc&&!metadata.srgb&&!Metadata.calibrated(metadata)){
   const key=JSON.stringify([metadata.aeRender.colorProof,metadata.aeRender.template,metadata.aeRender.workingSpace,metadata.aeRender.linear,metadata.aeRender.depth]);
   const verified=outputProfiles.get(key)||await RenderColour.resolve(metadata.aeRender,icc,async tagged=>{
    const input=path.join(temp,'colour-reference.png'),result=path.join(temp,'colour-reference-srgb.png');fs.writeFileSync(input,tagged);
    await run(['-m',SRGB,'-s','format','png',input,'--out',result],temp);return fs.readFileSync(result);
   });
   outputProfiles.set(key,verified);
   metadata.aeRender.verifiedOutput={profile:verified.name,maximumError:verified.score.maximum,meanError:verified.score.mean};
   data=Metadata.embed(data,verified.profile);metadata=Object.assign(Metadata.inspect(data),{aeRender:metadata.aeRender});
  }
  fs.writeFileSync(source,data,{flag:'wx'});const args=[];
  if(!metadata.icc&&!metadata.srgb&&Metadata.calibrated(metadata)){
   // ColorSync derives an ICC from the PNG's own primaries/gamma. Do not replace
   // a linear/wide-gamut source with an assumed sRGB profile before conversion.
   const sourceProfile=path.join(temp,'source.icc');await run(['-x',sourceProfile,source],temp);
   if(!fs.existsSync(sourceProfile))throw Error('ColorSync could not read the calibrated PNG colour space.');
   const tagged=Metadata.embed(data,fs.readFileSync(sourceProfile));metadata=Metadata.inspect(tagged);fs.writeFileSync(source,tagged);
  }
  if(!metadata.icc){if(metadata.space==='CMYK')throw Error('CMYK images need an embedded ICC profile before export.');if(metadata.format==='png'&&!metadata.srgb&&metadata.gamma&&Math.abs(metadata.gamma-45455)>10)throw Error('PNG uses a custom gamma without an ICC profile. Embed its source profile before export.');args.push('-E',metadata.space==='Gray'?GRAY:SRGB);}
  args.push('-m',SRGB,'-s','format',outputFormat);if(outputFormat==='jpeg')args.push('-s','formatOptions','94');
  if(size[0]!==target[0]||size[1]!==target[1])args.push('-z',String(target[1]),String(target[0]));args.push(source,'--out',output);
  await run(args,temp);if(!fs.existsSync(output))throw Error('Image conversion produced no output.');
  await run(['-x',proof,output],temp);if(!fs.existsSync(proof)||!fs.readFileSync(proof).equals(icc))throw Error('ColorSync output did not verify as sRGB. Transfer stopped.');
  const result=Metadata.embed(fs.readFileSync(output),icc),m=Metadata.inspect(result);if(m.space!=='RGB'||m.format!==outputFormat||m.size[0]!==target[0]||m.size[1]!==target[1]||!m.icc||!m.icc.equals(icc))throw Error('Converted image format, dimensions or sRGB profile did not verify.');return result;
 }finally{fs.rmSync(temp,{recursive:true,force:true});}
 };}
module.exports={profile,converter,referencePNG:()=>RenderColour.reference(profile())};
