'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const Batch=require('../shared/batch'),Vector=require('../shared/vectors');
function api(){return require('./store');}
function queue(store,raw,build,prepared){
 const {id,hash,atomic}=api(),c=store.config(),bid=id(),p=JSON.parse(JSON.stringify(raw));
 p.id=bid;p.createdAt=new Date().toISOString();p.storage={rootId:c.rootId};require('./vector-ops').prepare(p);
 const files=[];require('../shared/tree').flatten(p.items).forEach((item,i)=>{
  item.id=bid+'-'+i;item.storage=p.storage;item.createdAt=p.createdAt;
  if(item.layer.type==='bitmap'){
   const source=item.sourceFile,ext=source&&path.extname(source).toLowerCase();
   if(!source||!/^\.(png|jpe?g|psd|tiff?)$/.test(ext)||!fs.existsSync(source))throw Error('Source bitmap is missing or is not PNG/JPEG/PSD/TIFF.');
   const cooked=prepared&&(prepared.byItem?prepared.byItem[i]:prepared.entries[item.layer.id]),sourceHash=hash(source);
   if(prepared&&!cooked)throw Error('Prepared bitmap is missing.');
   if(cooked&&cooked.sourceHash!==sourceHash)throw Error('Source image changed during preparation. Push again.');
   const digest=cooked?crypto.createHash('sha256').update(cooked.data).digest('hex'):sourceHash,name='assets/'+bid+'-'+digest+(cooked?(cooked.format==='jpeg'?'.jpg':'.png'):ext);
   item.layer.asset={hash:digest,path:name,logicalId:item.layer.id};
   if(cooked){Object.assign(item.layer.asset,{pixelSize:cooked.pixelSize,sourceHash,processing:cooked.processing});require('./images').verifyAsset(item.layer.asset,cooked.data);}
   files.push(cooked?{data:cooked.data,name,digest}:{source,name,digest});
  }
  if(item.layer.type==='shape'){
   const data=Vector.svg(item.layer.artwork),digest=crypto.createHash('sha256').update(data).digest('hex'),name='vectors/'+i+'-'+digest+'.svg';
   item.layer.vectorAsset={hash:digest,path:name};files.push({data,name,digest});
  }
  delete item.sourceFile;
 });
 const plans=Batch.validate(p,build),tmp=store.at('transfers/.pending-'+bid),ready=store.at('transfers/transfer-'+bid);
 fs.mkdirSync(tmp);
 try{
  const written=new Set();for(const f of files){if(written.has(f.name))continue;written.add(f.name);const dest=path.join(tmp,f.name);fs.mkdirSync(path.dirname(dest),{recursive:true});if(f.source)fs.copyFileSync(f.source,dest,fs.constants.COPYFILE_EXCL);else fs.writeFileSync(dest,f.data,{flag:'wx'});if(hash(dest)!==f.digest)throw Error('Batch artwork copy verification failed.');}
  if(prepared)require('./placement').place(store,p,tmp,prepared.settings);
  atomic(path.join(tmp,'manifest.json'),p);atomic(path.join(tmp,'plan.json'),plans);fs.renameSync(tmp,ready);
  return {id:bid,manifest:p,path:ready};
 }catch(e){atomic(store.at('recovery/export-'+bid+'.json'),{id:bid,state:'failed-export',message:e.message});throw e;}
}
function prepare(store,entry,build,options={}){
 const {json,noLinks,hash,id,atomic}=api();
 if(!/^[a-z0-9-]+$/.test(entry.id))throw Error('Invalid transfer identity.');
 const base=store.at('transfers/transfer-'+entry.id),manifest=noLinks(base,'manifest.json'),p=json(manifest);
 Batch.validate(p,build);if(p.id!==entry.id||p.storage.rootId!==store.config().rootId)throw Error('Batch working history mismatch.');
 function prepareItem(item){
  const out={payload:item};
  for(const [key,field] of [['asset','assetPath'],['vectorAsset','vectorPath']]){
   if(!item.layer[key])continue;const a=item.layer[key],file=noLinks(base,a.path);if(hash(file)!==a.hash)throw Error('Batch artwork checksum failed.');out[field]=file;if(key==='asset'){require('./images').verifyAsset(a,fs.readFileSync(file));out[field]=require('./placement').resolve(store,a)||file;}
   if(key==='vectorAsset'&&fs.readFileSync(file,'utf8')!==Vector.svg(item.layer.artwork))throw Error('Vector geometry differs from manifest.');
  }
  if(item.layer.type==='bitmap'&&!out.assetPath||item.layer.type==='shape'&&!out.vectorPath)throw Error('Batch artwork is missing.');
  if(item.children)out.children=item.children.map(prepareItem);
  return out;
 }
 const items=p.items.map(prepareItem);
 const receipt=store.at('reports/'+p.id+'.json');if(fs.existsSync(receipt))throw Error('This transfer has already been attempted. Request a fresh transfer; no automatic re-import.');
 const journal=store.at('recovery/'+p.id+'.json');if(fs.existsSync(journal))throw Error('An interrupted import needs inspection before retrying.');
 const attempt=id(),outputPath=store.at('tests/KeyTween-'+p.id+'-'+attempt+'.fla'),recoveryPath=store.at('recovery/Before-'+p.id+'-'+attempt+'.fla');
 atomic(journal,{id:p.id,attempt,state:'importing',target:options.targetId,mode:options.mode||'pull',started:Date.now()});
 return {batch:true,id:p.id,manifest,items,outputPath,recoveryPath,build,createNew:options.createNew===true,matchCanvas:options.matchCanvas!==false,mode:options.mode||'pull',targetId:options.targetId};
}
module.exports={queue,prepare};
