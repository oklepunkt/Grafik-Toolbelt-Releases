'use strict';
const fs=require('fs'),zlib=require('zlib'),crypto=require('crypto');
function crc(data){let c=0xffffffff;for(let i=0;i<data.length;i++){c^=data[i];for(let j=0;j<8;j++)c=(c>>>1)^((c&1)?0xedb88320:0);}return (c^0xffffffff)>>>0;}
// Adobe 24 writes valid local ZIP records but sometimes malformed central-directory
// name lengths. Validate every local member and checksum without rewriting the FLA.
function inspect(file){
 const stat=fs.lstatSync(file);if(!stat.isFile()||stat.size>256*1024*1024)throw Error('Recovery copy is not a supported local FLA (256 MB limit).');
 const b=fs.readFileSync(file);let at=0,total=0,count=0,dom=false,mime=false;
 while(at+30<=b.length&&b.readUInt32LE(at)===0x04034b50){
  const flags=b.readUInt16LE(at+6),method=b.readUInt16LE(at+8),sum=b.readUInt32LE(at+14),size=b.readUInt32LE(at+18),expanded=b.readUInt32LE(at+22),n=b.readUInt16LE(at+26),extra=b.readUInt16LE(at+28),start=at+30+n+extra,end=start+size;
  if(flags&9||method!==0&&method!==8||end>b.length||expanded>128*1024*1024||total+expanded>512*1024*1024||count>=20000)throw Error('Recovery FLA is truncated or uses an unsupported archive layout.');
  const name=b.toString('utf8',at+30,at+30+n),raw=b.subarray(start,end),data=method===8?zlib.inflateRawSync(raw,{maxOutputLength:128*1024*1024}):raw;
  if(data.length!==expanded||crc(data)!==sum)throw Error('Recovery FLA member failed its checksum: '+name);
  if(name==='DOMDocument.xml')dom=/<DOMDocument\b/.test(data.toString('utf8'))&&/<\/DOMDocument>/.test(data.toString('utf8'));
  if(name==='mimetype')mime=/adobe/.test(data.toString('utf8'));
  total+=expanded;count++;at=end;
 }
 const end=b.lastIndexOf(Buffer.from([0x50,0x4b,0x05,0x06]));
 if(!dom||!mime||count<3||end<at||end+22>b.length||end+22+b.readUInt16LE(end+20)!==b.length||b.readUInt16LE(end+4)!==0||b.readUInt16LE(end+6)!==0||b.readUInt16LE(end+10)>count)throw Error('Recovery copy is not a complete Animate FLA archive.');
 return {sha256:crypto.createHash('sha256').update(b).digest('hex'),bytes:b.length,entries:count,expandedBytes:total,method:'local-ZIP-members-and-CRC32',nativeReopen:'not-run'};
}
function verify(prepared,args){
 if(prepared.status!=='recovery-prepared')throw Error(prepared.error||'Animate could not prepare a recovery copy.');
 if(!prepared.recoveryNeeded)return null;
 if(prepared.transferId!==args.id||prepared.documentId!==args.targetId||prepared.recoveryFile!==args.recoveryPath)throw Error('Recovery identity differs from the destination request.');
 return Object.assign(inspect(args.recoveryPath),{transferId:args.id,documentId:prepared.documentId,documentStamp:prepared.documentStamp,path:args.recoveryPath,hostChecks:prepared.recoveryChecks});
}
module.exports={inspect,verify,crc};
