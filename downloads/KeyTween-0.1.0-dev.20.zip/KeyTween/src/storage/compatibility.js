'use strict';
// Read-only file checks extend the same host preflight used for transfer.
const fs=require('fs'),Meta=require('./image-metadata'),Images=require('./images'),PSD=require('./psd-layers');
function sourceKey(source){return JSON.stringify([source.file,source.id,source.name,source.size,source.format]);}
function fingerprint(source){const stat=fs.statSync(source.file);if(!stat.isFile()||stat.size>128*1024*1024)throw Error('Vector source is missing or exceeds 128 MB.');return {hash:Images.digest(fs.readFileSync(source.file)),length:stat.size,modified:stat.mtimeMs};}
function rememberVectors(raw,proofs){for(const item of require('../shared/tree').flatten(raw.items||[])){if(item.layer.type!=='shape'||!item.vectorSource)continue;const s=item.vectorSource,f=fingerprint(s);if(s.modified!=null&&Math.floor(s.modified/1000)!==Math.floor(f.modified/1000)||s.length!=null&&s.length!==f.length)throw Error('Vector source changed after conversion. Refresh footage and push again.');proofs.set(sourceKey(s),f.hash);while(proofs.size>100)proofs.delete(proofs.keys().next().value);}}
function evaluate(report,settings={},proofs=new Map()){
 if(!report||!Array.isArray(report.rows))throw Error('Invalid compatibility response from AE.');
 const result=JSON.parse(JSON.stringify(report)),cache=new Map();
 for(const row of result.rows){
  if(row.vector&&row.status!=='unsupported')try{require('./vector-ops').normalize(row.vector);delete row.vector;}catch(e){row.status='unsupported';row.reason=e.message;}
  if(row.children&&row.children.length){const child=evaluate({composition:result.composition,rows:row.children},settings,proofs);const bad=child.rows.filter(r=>r.status!=='supported');if(bad.length){row.status=child.state;row.reason=bad.map(r=>'Inside layer '+r.index+' ('+r.name+'): '+r.reason).join('\n');}}
  if(row.status==='pending'&&row.vectorSource){
   try{const hash=fingerprint(row.vectorSource).hash;if(proofs.get(sourceKey(row.vectorSource))===hash){row.status='supported';row.reason=null;}else row.reason='Vector contents need conversion checking on the next Push/Pull. The read-only scan leaves your project unchanged.';}catch(e){row.status='unsupported';row.reason=e.message;}
  }
  if(row.status==='unsupported'||!row.sourceFile)continue;
  try{
   const stat=fs.statSync(row.sourceFile);if(!stat.isFile()||stat.size>128*1024*1024)throw Error('Source image is missing or exceeds 128 MB.');
   const data=fs.readFileSync(row.sourceFile),m=Meta.inspect(data);let actual=m;
   if(m.format==='psd')actual=PSD.extract(data,m,row.psdSource,row.size,cache,Images.digest(data)).metadata;
   if(actual.size[0]!==row.size[0]||actual.size[1]!==row.size[1])throw Error('Image dimensions differ from AE footage interpretation.');
   if(!actual.icc&&actual.space==='CMYK')throw Error('CMYK images need an embedded ICC profile.');
   if(actual.format==='png'&&!actual.icc&&!actual.srgb&&actual.gamma&&Math.abs(actual.gamma-45455)>10)throw Error('PNG uses custom gamma without an embedded ICC profile.');
   Images.plan(result.composition,row.size,settings);
  }catch(e){row.status='unsupported';row.reason=e.message;}
 }
 // A failed/unknown scan can never paint the all-supported state.
 result.state=result.reason||!result.composition||!result.rows.length?'unknown':result.rows.some(r=>r.status==='unsupported')?'unsupported':result.rows.some(r=>r.status!=='supported')?'pending':'supported';
 result.checkedAt=new Date().toISOString();return result;
}
module.exports={evaluate,rememberVectors};
