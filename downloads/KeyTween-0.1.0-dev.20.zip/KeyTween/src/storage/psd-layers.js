'use strict';
const zlib=require('zlib'),Metadata=require('./image-metadata'),{crc}=require('./recovery'),PSD=require('../vendor/ag-psd');
PSD.initializeCanvas(()=>{throw Error('PSD extraction does not use a browser canvas.');},(width,height)=>({width,height,data:new Uint8ClampedArray(width*height*4)}));
function chunk(name,data){const type=Buffer.from(name),size=Buffer.alloc(4),sum=Buffer.alloc(4);size.writeUInt32BE(data.length);sum.writeUInt32BE(crc(Buffer.concat([type,data])));return Buffer.concat([size,type,data,sum]);}
function png(width,height,depth,sample,icc){const bytes=depth/8,row=width*4*bytes+1,raw=Buffer.alloc(row*height);for(let y=0;y<height;y++)for(let x=0;x<width;x++){const values=sample(x,y),offset=y*row+1+x*4*bytes;for(let c=0;c<4;c++){if(bytes===2)raw.writeUInt16BE(values[c],offset+c*2);else raw[offset+c]=values[c];}}const h=Buffer.alloc(13);h.writeUInt32BE(width);h.writeUInt32BE(height,4);h[8]=depth;h[9]=6;const chunks=[chunk('IHDR',h)];if(icc)chunks.push(chunk('iCCP',Buffer.concat([Buffer.from('PSD source profile\0\0'),zlib.deflateSync(icc)])));chunks.push(chunk('IDAT',zlib.deflateSync(raw)),chunk('IEND',Buffer.alloc(0)));return Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),...chunks]);}
// ag-psd 31's RLE reader consumes byte samples even for 16-bit channels.
// Decode PackBits rows to their original big-endian bytes before its raw reader.
function unpackRLE(input,width,height,depth,large){
 const data=Buffer.from(input.buffer,input.byteOffset,input.byteLength),rowBytes=width*(depth/8),countBytes=large?4:2,table=height*countBytes;
 if(!Number.isInteger(rowBytes)||rowBytes<1||height<1||rowBytes*height>256*1024*1024||table>data.length)throw Error('Invalid PSD RLE dimensions/table.');
 const output=Buffer.alloc(rowBytes*height);let at=table;
 for(let y=0;y<height;y++){
  const count=large?data.readUInt32BE(y*4):data.readUInt16BE(y*2),end=at+count;let x=0;
  if(end>data.length)throw Error('Truncated PSD RLE row.');
  while(at<end){const header=data[at++];if(header===128)continue;const n=header<128?header+1:257-header;
   if(x+n>rowBytes)throw Error('PSD RLE row exceeds its pixel width.');
   if(header<128){if(at+n>end)throw Error('Truncated PSD RLE literal.');data.copy(output,y*rowBytes+x,at,at+n);at+=n;}
   else {if(at>=end)throw Error('Truncated PSD RLE run.');output.fill(data[at++],y*rowBytes+x,y*rowBytes+x+n);}x+=n;
  }
  if(x!==rowBytes)throw Error('PSD RLE row does not fill its pixel width.');
 }
 if(at!==data.length&&!(at+1===data.length&&data[at]===0))throw Error('Unexpected trailing PSD RLE data.');
 return output;
}
function normalizedLayer(layer){
 const raw=layer.rawData;if(!raw)throw Error('PSD layer has no saved channel data.');
 return Object.assign({},layer,{rawData:Object.assign({},raw,{channels:raw.channels.map(channel=>{
  if(channel.compression!==1||![0,1,2,-1,-2].includes(channel.id))return channel;
  const bounds=channel.id===-2?layer.mask:layer;if(!bounds)throw Error('PSD channel mask bounds are missing.');
  return Object.assign({},channel,{compression:0,data:unpackRLE(channel.data,bounds.right-bounds.left,bounds.bottom-bounds.top,raw.bitsPerChannel,raw.large)});
 })})});
}
function extract(data,metadata,selection,size,cache,key){
 if(!selection||selection.mode==='merged')return {data,metadata,report:{mode:'merged'}};
 if(selection.mode!=='layer'||typeof selection.name!=='string'||!selection.name)throw Error('PSD layer identity is missing. Reimport the PSD into AE with its original footage names.');
 if(metadata.space!=='RGB')throw Error('Individual PSD layers currently require RGB color. Merged PSD footage can also use profiled CMYK.');
 let parsed=cache.get(key);if(!parsed){cache.clear();parsed=PSD.readPsd(data,{useRawData:true,useImageData:true,skipCompositeImageData:true,skipThumbnail:true,skipLinkedFilesData:true,totalMemoryLimit:256*1024*1024});cache.set(key,parsed);}
 const found=[];let count=0;
 function visit(nodes,parents){if(parents.length>32)throw Error('PSD layer hierarchy is too deep.');for(const node of nodes||[]){if(++count>2048)throw Error('PSD has too many layers.');const names=parents.concat(node.name||'');if(!node.children&&(node.name===selection.name||names.join('/')===selection.name))found.push(node);visit(node.children,names);}}
 visit(parsed.children,[]);if(found.length!==1)throw Error(found.length?'PSD layer name is ambiguous: '+selection.name+'. Use unique Photoshop layer names and reimport/refresh AE footage.':'PSD layer not found: '+selection.name+'. Keep the original AE footage item name and refresh the source.');
 const layer=found[0],w=layer.right-layer.left,h=layer.bottom-layer.top,depth=metadata.depth,max=depth===16?65535:255;
 if(!Number.isInteger(w)||!Number.isInteger(h)||w<1||h<1||w*h*4*(depth/8)>256*1024*1024)throw Error('PSD layer pixels exceed the supported memory/dimension limit.');
 if(layer.adjustment||layer.clipping||layer.vectorMask||layer.realMask||layer.effects&&!layer.effects.disabled&&Object.keys(layer.effects).some(k=>k!=='scale'&&k!=='disabled'))throw Error('PSD layer '+selection.name+' has adjustment/clipping/vector-mask/layer-style content requiring a separate renderer. Rasterize those features within that Photoshop layer first.');
 if(layer.opacity!=null&&Math.abs(layer.opacity-1)>.00001||layer.fillOpacity!=null&&Math.abs(layer.fillOpacity-1)>.00001)throw Error('PSD layer opacity/fill must be 100% in Photoshop for this prototype. Animate opacity using the AE layer transform.');
 const documentSize=size[0]===metadata.size[0]&&size[1]===metadata.size[1],layerSize=size[0]===w&&size[1]===h;
 if(!documentSize&&!layerSize)throw Error('AE PSD footage size matches neither the Photoshop layer nor document bounds. Refresh the footage interpretation before transfer.');
 if(documentSize&&layerSize&&(layer.left!==0||layer.top!==0))throw Error('PSD layer/document dimensions are ambiguous with offset bounds. Use a source with distinct layer bounds before transfer.');
 const decoded=normalizedLayer(layer),pixels=PSD.getLayerImageData(decoded);if(!pixels||pixels.width!==w||pixels.height!==h||pixels.data.length!==w*h*4)throw Error('PSD layer has no usable saved raster pixels. Save the PSD in Photoshop and refresh it.');
 if(depth===16&&!(pixels.data instanceof Uint16Array)||depth===8&&!(pixels.data instanceof Uint8Array)&&!(pixels.data instanceof Uint8ClampedArray))throw Error('PSD layer bit depth differs from its saved pixels.');
 const mask=layer.mask&&!layer.mask.disabled?layer.mask:null;let maskPixels=null;
 if(mask){if(mask.userMaskFeather||mask.vectorMaskFeather||mask.fromVectorData)throw Error('Feathered/vector PSD masks require rasterization before this prototype can extract the layer.');const mw=mask.right-mask.left,mh=mask.bottom-mask.top;if(mw*mh*4*(depth/8)>256*1024*1024)throw Error('PSD mask is too large.');maskPixels=PSD.getLayerMaskImageData(decoded);if(!maskPixels||maskPixels.width!==mw||maskPixels.height!==mh)throw Error('PSD mask pixels are missing.');}
 const dx=documentSize?layer.left:0,dy=documentSize?layer.top:0,density=mask&&mask.userMaskDensity!=null?mask.userMaskDensity:1;
 if(!Number.isFinite(density)||density<0||density>1)throw Error('PSD mask density is invalid.');
 const result=png(size[0],size[1],depth,(x,y)=>{
  const lx=x-dx,ly=y-dy;if(lx<0||ly<0||lx>=w||ly>=h)return [0,0,0,0];const at=(ly*w+lx)*4,v=[pixels.data[at],pixels.data[at+1],pixels.data[at+2],pixels.data[at+3]];
  if(mask){const mx=lx+layer.left-(mask.left+(mask.positionRelativeToLayer?layer.left:0)),my=ly+layer.top-(mask.top+(mask.positionRelativeToLayer?layer.top:0));const factor=mx<0||my<0||mx>=maskPixels.width||my>=maskPixels.height?(mask.defaultColor||0)/255:maskPixels.data[(my*maskPixels.width+mx)*4]/max;v[3]=Math.round(v[3]*(1-density*(1-factor)));}return v;
 },metadata.icc);
 return {data:result,metadata:Metadata.inspect(result),report:{mode:'layer',name:layer.name,id:layer.id==null?null:layer.id,canvas:documentSize?'document-size':'layer-size',documentSize:metadata.size,bounds:{left:layer.left,top:layer.top,width:w,height:h},maskApplied:!!mask}};
}
module.exports={extract,unpackRLE};
