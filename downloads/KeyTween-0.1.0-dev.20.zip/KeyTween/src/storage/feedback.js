'use strict';
const fs=require('fs');
const NAME='feedback/KeyTween-feedback.jsonl';

function redact(value,depth=0){
  if(depth>18)return '[depth limit]';
  if(typeof value==='string')return value.replace(/(?:file:\/\/\/|[A-Za-z]:[\\/]|\/(?:Users|Volumes|private|tmp|Applications|home|mnt|var|opt)\/)[^\r\n"'<>]*/g,'[local path redacted]').slice(0,8000);
  if(Array.isArray(value))return value.slice(0,200).map(v=>redact(v,depth+1));
  if(value&&typeof value==='object'){const out={};for(const key of Object.keys(value))out[key]=redact(value[key],depth+1);return out;}
  return value;
}
function append(file,entry){
  // One local O_APPEND write per complete record: the two panel processes never
  // read/replace each other's history, nor need the transfer/folder-change lock.
  // The leading newline also separates a previous power-loss/partial record.
  // Readers ignore blank lines; a damaged tail cannot consume the next report.
  const line=Buffer.from('\n'+JSON.stringify(redact(entry))+'\n','utf8');
  if(line.length>256*1024)throw Error('Feedback record is too large. Copy Diagnostics to retain it.');
  const fd=fs.openSync(file,'a',0o600);
  try{if(fs.writeSync(fd,line,0,line.length)!==line.length)throw Error('Feedback write was incomplete. Copy Diagnostics to retain this result.');}
  finally{fs.closeSync(fd);}
}
function recent(file){
  if(!fs.existsSync(file))return [];
  const fd=fs.openSync(file,'r');
  try{
    const size=fs.fstatSync(fd).size,start=Math.max(0,size-512*1024),buffer=Buffer.alloc(size-start);
    fs.readSync(fd,buffer,0,buffer.length,start);
    let lines=buffer.toString('utf8').split('\n');if(start)lines.shift();
    return lines.filter(Boolean).slice(-100).map(line=>{try{return JSON.parse(line);}catch(e){return {event:{type:'report-write-incomplete',message:'A report record was interrupted; other records are retained.'}};}});
  }finally{fs.closeSync(fd);}
}
module.exports={NAME,redact,append,recent};
