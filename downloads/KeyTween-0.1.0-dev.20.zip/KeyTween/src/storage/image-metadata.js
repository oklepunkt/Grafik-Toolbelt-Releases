'use strict';
const zlib=require('zlib'),{crc}=require('./recovery');
const MAX_ICC=4*1024*1024;
function bounded(b,at,n){if(!Number.isSafeInteger(at)||!Number.isSafeInteger(n)||at<0||n<0||at+n>b.length)throw Error('Truncated or malformed image metadata.');return b.subarray(at,at+n);}
function profile(b){if(b.length>MAX_ICC||b.length<128||b.toString('ascii',36,40)!=='acsp'||b.readUInt32BE(0)!==b.length)throw Error('Invalid embedded ICC profile.');return b;}
function tiff(b){
 const le=b.toString('ascii',0,2)==='II';if(!le&&b.toString('ascii',0,2)!=='MM')throw Error('Invalid TIFF byte order.');
 const u16=p=>{bounded(b,p,2);return le?b.readUInt16LE(p):b.readUInt16BE(p);},u32=p=>{bounded(b,p,4);return le?b.readUInt32LE(p):b.readUInt32BE(p);};
 if(u16(2)!==42)throw Error('BigTIFF is not supported; save a standard TIFF.');const at=u32(4),n=u16(at);if(n>1024)throw Error('TIFF metadata is too large.');bounded(b,at,2+n*12+4);const tags={};
 for(let i=0;i<n;i++){const p=at+2+i*12,key=u16(p),type=u16(p+2),count=u32(p+4),unit=({1:1,2:1,3:2,4:4,5:8,7:1,9:4,10:8,11:4,12:8})[type];if(!unit)continue;const len=count*unit,offset=len<=4?p+8:u32(p+8);if([256,257,258,262,274,339,34675].includes(key)){const data=bounded(b,offset,len);if(key===34675)tags[key]=profile(data);else tags[key]=type===3?u16(offset):type===4?u32(offset):data[0];}}
 return {size:[tags[256],tags[257]],depth:tags[258]||8,space:tags[262]===5?'CMYK':tags[262]===0||tags[262]===1?'Gray':'RGB',orientation:tags[274]||1,icc:tags[34675]||null,multiPage:u32(at+2+n*12)!==0,float:tags[339]===3};
}
function pngChunks(b){let at=8,out=[];while(at<b.length){bounded(b,at,12);const n=b.readUInt32BE(at),type=b.toString('ascii',at+4,at+8),data=bounded(b,at+8,n);bounded(b,at+8+n,4);out.push({type,data,raw:b.subarray(at,at+12+n)});at+=12+n;if(type==='IEND'){if(at!==b.length)throw Error('Unexpected data after PNG end.');return out;}}throw Error('PNG end is missing.');}
function jpegSegments(b){let at=2,out=[];while(at<b.length){const start=at;if(b[at++]!==255)throw Error('Invalid JPEG marker.');while(b[at]===255)at++;const marker=b[at++];if(marker===218||marker===217){out.push({marker,raw:b.subarray(start),data:Buffer.alloc(0)});return out;}if(marker===1||marker>=208&&marker<=215){out.push({marker,raw:b.subarray(start,at),data:Buffer.alloc(0)});continue;}bounded(b,at,2);const len=b.readUInt16BE(at);if(len<2)throw Error('Invalid JPEG segment.');const data=bounded(b,at+2,len-2);at+=len;out.push({marker,data,raw:b.subarray(start,at)});}throw Error('Incomplete JPEG.');}
function inspect(b){
 let m={format:null,icc:null,orientation:1,space:'RGB',depth:8};
 if(b.length>=33&&b.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]))){
  m.format='png';m.size=[b.readUInt32BE(16),b.readUInt32BE(20)];m.depth=b[24];m.space=[0,4].includes(b[25])?'Gray':'RGB';
  for(const c of pngChunks(b)){if(c.type==='iCCP'){const zero=c.data.indexOf(0);if(m.icc||zero<1||zero>79||c.data[zero+1]!==0)throw Error('Invalid PNG color profile.');m.icc=profile(zlib.inflateSync(c.data.subarray(zero+2),{maxOutputLength:MAX_ICC}));}if(c.type==='sRGB')m.srgb=c.data.length===1&&c.data[0]<=3;if(c.type==='gAMA'){if(m.gamma!=null||c.data.length!==4||!c.data.readUInt32BE(0))throw Error('Invalid PNG gamma.');m.gamma=c.data.readUInt32BE(0);}if(c.type==='cHRM'){if(m.chromaticities||c.data.length!==32)throw Error('Invalid PNG chromaticities.');m.chromaticities=Array.from({length:8},(_,i)=>c.data.readUInt32BE(i*4));for(let i=0;i<8;i+=2){const x=m.chromaticities[i],y=m.chromaticities[i+1];if(!y||x+y>100002)throw Error('Invalid PNG chromaticities.');}}if(c.type==='acTL')throw Error('Animated PNG is not a still image.');if(c.type==='eXIf')m.orientation=tiff(c.data).orientation;}
 }else if(b.length>=26&&b.toString('ascii',0,4)==='8BPS'){
  if(b.readUInt16BE(4)!==1)throw Error('Use PSD, not PSB.');m.format='psd';m.size=[b.readUInt32BE(18),b.readUInt32BE(14)];m.depth=b.readUInt16BE(22);const mode=b.readUInt16BE(24);m.space=mode===3?'RGB':mode===4?'CMYK':mode===1?'Gray':'unsupported';
  let at=26;bounded(b,at,4);at+=4+b.readUInt32BE(at);bounded(b,at,4);const length=b.readUInt32BE(at);at+=4;const end=at+length;bounded(b,at,length);
  while(at<end){bounded(b,at,7);if(b.toString('ascii',at,at+4)!=='8BIM')throw Error('Invalid PSD resource.');const id=b.readUInt16BE(at+4),name=b[at+6];at+=6+(1+name+(1+name)%2);bounded(b,at,4);const n=b.readUInt32BE(at);at+=4;const data=bounded(b,at,n);if(id===1039)m.icc=profile(data);at+=n+n%2;}
  if(at!==end)throw Error('Invalid PSD resource length.');bounded(b,at,4);const layers=b.readUInt32BE(at);bounded(b,at+4,layers);if(layers>=6&&b.readUInt32BE(at+4)>=2)m.layerCount=Math.abs(b.readInt16BE(at+8));
 }else if(b.length>=8&&['II','MM'].includes(b.toString('ascii',0,2))){m=Object.assign(m,tiff(b),{format:'tiff'});}
 else if(b.length>4&&b[0]===255&&b[1]===216){
  m.format='jpeg';const chunks=[],parts={};let total=null;
  for(const s of jpegSegments(b)){if([192,193,194,195,197,198,199,201,202,203,205,206,207].includes(s.marker)){bounded(s.data,0,6);m.depth=s.data[0];m.size=[s.data.readUInt16BE(3),s.data.readUInt16BE(1)];m.space=s.data[5]===4?'CMYK':s.data[5]===1?'Gray':'RGB';}if(s.marker===226&&s.data.toString('ascii',0,12)==='ICC_PROFILE\0'){bounded(s.data,0,14);const seq=s.data[12],count=s.data[13];if(!seq||seq>count||parts[seq]||total!==null&&total!==count)throw Error('Invalid JPEG color profile segments.');total=count;parts[seq]=s.data.subarray(14);}if(s.marker===225&&s.data.toString('ascii',0,6)==='Exif\0\0')m.orientation=tiff(s.data.subarray(6)).orientation;}
  if(total!==null){for(let n=1;n<=total;n++){if(!parts[n])throw Error('Incomplete JPEG color profile.');chunks.push(parts[n]);}m.icc=profile(Buffer.concat(chunks));}
 }
 if(!m.format||!m.size||m.size.some(n=>!Number.isInteger(n)||n<1||n>32768)||m.size[0]*m.size[1]>64*1024*1024)throw Error('Image must be PNG, JPEG, PSD or TIFF within 64 megapixels and 32768 pixels per side.');
 if(m.orientation!==1)throw Error('Normalize the image orientation before transfer; rotated EXIF footage is not supported yet.');if(m.multiPage)throw Error('Multi-page TIFF is not supported; save one image per TIFF.');if(m.depth>16||m.float)throw Error('32-bit/HDR imagery requires a tone-mapping workflow; use an 8-bit or 16-bit image.');if(m.space==='unsupported')throw Error('Use an RGB, grayscale or profiled CMYK image.');
 return m;
}
function chunk(type,data){const name=Buffer.from(type),head=Buffer.alloc(4),tail=Buffer.alloc(4);head.writeUInt32BE(data.length);tail.writeUInt32BE(crc(Buffer.concat([name,data])));return Buffer.concat([head,name,data,tail]);}
function embed(data,icc){profile(icc);const m=inspect(data);if(m.format==='png'){const chunks=pngChunks(data),keep=new Set(['IHDR','PLTE','tRNS','IDAT','IEND']);return Buffer.concat([data.subarray(0,8),...chunks.flatMap(c=>c.type==='IHDR'?[c.raw,chunk('iCCP',Buffer.concat([Buffer.from('KeyTween ICC\0\0'),zlib.deflateSync(icc)]))]:keep.has(c.type)?[c.raw]:[])]);}
 if(m.format==='jpeg'){const segment=Buffer.concat([Buffer.from('ICC_PROFILE\0'),Buffer.from([1,1]),icc]);if(segment.length>65533)throw Error('sRGB profile is too large for a JPEG segment.');const head=Buffer.from([255,226,0,0]);head.writeUInt16BE(segment.length+2,2);return Buffer.concat([Buffer.from([255,216]),head,segment,...jpegSegments(data).filter(s=>s.marker!==225&&s.marker!==237&&!(s.marker===226&&s.data.toString('ascii',0,12)==='ICC_PROFILE\0')).map(s=>s.raw)]);}
 throw Error('Only PNG/JPEG export files can be tagged.');
}
// PNG gAMA + cHRM define calibrated RGB even when there is no iCCP chunk.
function calibrated(m){return m.format==='png'&&m.space==='RGB'&&!!m.gamma&&!!m.chromaticities;}
module.exports={inspect,embed,calibrated};
