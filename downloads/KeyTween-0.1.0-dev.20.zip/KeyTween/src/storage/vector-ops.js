 'use strict';
const fs=require('fs'),vm=require('vm'),V=require('../shared/vectors');
const code=fs.readFileSync(require.resolve('../vendor/paper-core.js'),'utf8');
function normalize(root){
 V.validate(root);
 if(!JSON.stringify(root).includes('"operation":"merge"'))return root;
 const context={self:{navigator:{userAgent:'KeyTween geometry'}},input:JSON.parse(JSON.stringify(root))};vm.createContext(context);
 vm.runInContext(code,context,{timeout:10000});
 vm.runInContext(`
 paper.setup(new paper.Size(1,1));paper.view.autoUpdate=false;
 function convert(p){if(p.operation){var a=p.paths.map(convert),r=a[0];if(p.mode===1)return new paper.CompoundPath({children:a,insert:false});for(var i=1;i<a.length;i++)r=r[['','', 'unite','subtract','intersect','exclude'][p.mode]](a[i],{insert:false});return r;}return new paper.Path({insert:false,closed:p.closed,segments:p.vertices.map(function(v,i){return new paper.Segment(v,p.inTangents[i],p.outTangents[i]);})});}
 function contours(p){if(p.children)return p.children.reduce(function(a,c){return a.concat(contours(c));},[]);if(p.segments.length<2)return [];return [{vertices:p.segments.map(function(s){return [s.point.x,s.point.y];}),inTangents:p.segments.map(function(s){return [s.handleIn.x,s.handleIn.y];}),outTangents:p.segments.map(function(s){return [s.handleOut.x,s.handleOut.y];}),closed:p.closed}];}
 function walk(n){if(n.kind==='group'){n.children=n.children.map(walk).filter(function(c){return c.kind==='group'?c.children.length:c.paths.length;});}else n.paths=n.paths.reduce(function(a,p){return a.concat(p.operation?contours(convert(p)):p);},[]);return n;}
 output=walk(input);paper.project.remove();`,context,{timeout:15000});
 const out=JSON.parse(JSON.stringify(context.output));V.validate(out);return out;
}
function prepare(raw){for(const item of require('../shared/tree').flatten(raw.items||[]))if(item.layer.type==='shape')item.layer.artwork.vector=normalize(item.layer.artwork.vector);return raw;}
module.exports={normalize,prepare};
