'use strict';
const fs=require('fs'),path=require('path'),os=require('os'),crypto=require('crypto');
const Plan=require('../shared/plan'),Vector=require('../shared/vectors');
const Feedback=require('./feedback');
const CATEGORIES=['transfers','cache','logs','reports','recovery','tests','builds','feedback','state'];
function id(){return Date.now().toString(36)+'-'+crypto.randomBytes(8).toString('hex');}
function hash(file){return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');}
function json(file){return JSON.parse(fs.readFileSync(file,'utf8'));}
function atomic(file,value){
  const tmp=file+'.'+id()+'.tmp';let fd,owned=false;
  try{fd=fs.openSync(tmp,'wx',0o600);owned=true;fs.writeFileSync(fd,JSON.stringify(value,null,2));fs.closeSync(fd);fd=undefined;fs.renameSync(tmp,file);owned=false;}
  finally{if(fd!==undefined){try{fs.closeSync(fd);}catch(ignored){}}if(owned){try{fs.unlinkSync(tmp);}catch(ignored){}}}
}
function noLinks(root,relative){
  if(typeof relative!=='string'||!relative||path.isAbsolute(relative)||/[\\:\0]/.test(relative)||relative.split('/').some(p=>!p||p==='.'||p==='..'))throw Error('Unsafe relative path.');
  function check(file){let s;try{s=fs.lstatSync(file);}catch(e){if(e.code==='ENOENT')return;throw e;}if(s.isSymbolicLink())throw Error('KeyTween does not follow links inside working data.');}
  let at=root;
  check(at);
  for(const part of relative.split('/')){at=path.join(at,part);check(at);}
  return at;
}
function copyTree(from,to){
  const stat=fs.lstatSync(from);if(stat.isSymbolicLink())throw Error('Symbolic links cannot be copied as KeyTween data.');
  if(stat.isDirectory()){fs.mkdirSync(to,{recursive:true});for(const name of fs.readdirSync(from))copyTree(path.join(from,name),path.join(to,name));}
  else {if(!stat.isFile())throw Error('Only regular files can be copied as KeyTween data.');fs.copyFileSync(from,to,fs.constants.COPYFILE_EXCL);if(hash(from)!==hash(to))throw Error('Copy verification failed. Source retained.');}
}
function layerSummaries(layers){return layers&&layers.map(l=>({layerId:l.layerId,name:l.name,status:l.status,artwork:l.artwork,representation:l.representation,verification:l.verification?{pass:l.verification.pass,status:l.verification.status,geometryPass:l.verification.geometryPass,opacityPass:l.verification.opacityPass,maxErrors:l.verification.maxErrors,timelinePass:l.verification.timelinePass,anchorPivotPass:l.verification.anchorPivotPass}:null,artworkVerification:l.artworkVerification?{nativeContent:l.artworkVerification.nativeContent,rasterized:l.artworkVerification.rasterized,styleReadback:l.artworkVerification.styleReadback,boundsPass:l.artworkVerification.boundsPass,boundsError:l.artworkVerification.boundsError,layoutVerification:l.artworkVerification.layoutVerification}:null,error:l.error,progress:l.progress,note:l.note}));}
function defaultLocator(){return process.platform==='darwin'?path.join(os.homedir(),'Library','Application Support','KeyTween','locator.json'):path.join(process.env.APPDATA||os.homedir(),'KeyTween','locator.json');}
class Store {
  constructor(locator){this.locator=locator||defaultLocator();}
  config(){if(!fs.existsSync(this.locator))throw Error('Choose a Working Folder to finish setup.');return json(this.locator);}
  root(){const c=this.config();const marker=noLinks(c.root,'.keytween-root.json');if(!fs.existsSync(c.root))throw Error('Working Folder Unavailable. Reconnect the drive or choose a folder.');if(!fs.existsSync(marker)||json(marker).id!==c.rootId)throw Error('Working Folder Unavailable: the original folder marker is missing.');for(const category of CATEGORIES)noLinks(c.root,category);return c.root;}
  at(relative){return noLinks(this.root(),relative);}
  lock(label){fs.mkdirSync(path.dirname(this.locator),{recursive:true});const file=this.locator+'.lock';try{fs.writeFileSync(file,JSON.stringify({id:id(),operation:label,started:Date.now()}),{flag:'wx',mode:0o600});}catch(e){if(e.code==='EEXIST')throw Error('Another KeyTween operation is active. Wait for it to finish. If interrupted, use the setup helper’s Recover action.');throw e;}return ()=>fs.unlinkSync(file);}
  initialize(root){
    if(!path.isAbsolute(root)||/^[/\\]{2}/.test(root))throw Error('Choose an absolute local folder. Network paths are unsupported.');
    if(process.platform==='darwin'&&root.startsWith('/Volumes/')){const volume='/Volumes/'+root.split('/')[2];if(!fs.existsSync(volume))throw Error('Working Folder Unavailable: external disk is disconnected.');}
    if(fs.existsSync(root)&&fs.lstatSync(root).isSymbolicLink())throw Error('Choose the actual folder, not a symbolic link.');
    fs.mkdirSync(root,{recursive:true});const marker=noLinks(root,'.keytween-root.json');
    if(!fs.existsSync(marker)){
      if(fs.readdirSync(root).length)throw Error('Choose an empty dedicated folder. Your unrelated files will not be used or moved.');
      atomic(marker,{schema:1,id:id(),owner:'KeyTween'});
    }
    const m=json(marker);if(m.schema!==1||m.owner!=='KeyTween')throw Error('Not a supported KeyTween working folder.');
    for(const category of CATEGORIES){noLinks(root,category);fs.mkdirSync(path.join(root,category),{recursive:true});}
    const probe=path.join(root,'state',id()+'.probe');fs.writeFileSync(probe,'KeyTween local write/rename probe',{flag:'wx'});fs.renameSync(probe,probe+'.renamed');fs.unlinkSync(probe+'.renamed');
    return m;
  }
  choose(root,mode){
    const release=this.lock('change working folder');
    try {
      const old=fs.existsSync(this.locator)?this.config():null;
      root=path.resolve(root);if(old&&root===old.root){this.root();return old;}
      if(old&&(root.startsWith(old.root+path.sep)||old.root.startsWith(root+path.sep)))throw Error('Choose a separate folder, outside the current working folder.');
      let marker;
      if(mode==='move'&&old){
        this.root();
        if(fs.existsSync(root)&&fs.readdirSync(root).length)throw Error('Moving data requires an empty destination.');
        copyTree(old.root,root);marker=this.initialize(root);
      }else {
        marker=this.initialize(root);
        // Build rollback is a persistent setting, even when transfer history starts afresh.
        if(old&&fs.existsSync(path.join(old.root,'builds','installation.json'))){
          const dest=path.join(root,'builds');
          if(fs.readdirSync(dest).length)throw Error('Destination already has build history. Choose an empty working folder.');
          copyTree(path.join(old.root,'builds'),dest);
        }
      }
      const next={schema:1,root,rootId:marker.id,machineId:old&&old.machineId||id(),revision:(old?old.revision:0)+1,previousRoot:old?old.root:null,panelSettings:old&&old.panelSettings||{}};
      atomic(this.locator,next);return next;
    }finally{release();}
  }
  reconnect(root){
    const release=this.lock('reconnect moved working folder');
    try{
      const old=this.config();root=path.resolve(root);
      const marker=noLinks(root,'.keytween-root.json');
      if(!fs.existsSync(marker)||json(marker).id!==old.rootId)throw Error('The moved folder does not match the selected working history.');
      this.initialize(root);
      const next=Object.assign({},old,{root,machineId:old.machineId||id(),revision:old.revision+1,previousRoot:old.root});
      atomic(this.locator,next);return next;
    }finally{release();}
  }
  ensureMachine(){
    if(this.config().machineId)return;
    const release=this.lock('initialize machine identity');
    try{const c=this.config();if(!c.machineId)atomic(this.locator,Object.assign({},c,{machineId:id(),revision:c.revision+1}));}finally{release();}
  }
  settings(value){const c=this.config();if(value){atomic(this.locator,Object.assign({},c,{panelSettings:Object.assign({},c.panelSettings,value)}));}return Object.assign({createNew:false,matchCanvas:true,imageMaxSide:null,upscaleImages:false,placeImages:true,imageFolder:null},c.panelSettings,value);}
  message(name,value){if(!/^[a-z-]+$/.test(name))throw Error('Invalid local message.');const file=this.at('state/'+name+'.json');if(value){atomic(file,Object.assign({},value,{build:value.build,machineId:this.config().machineId,rootId:this.config().rootId}));return value;}if(!fs.existsSync(file))return null;const v=json(file),c=this.config();return v.machineId===c.machineId&&v.rootId===c.rootId?v:null;}
  usage(){const out={};function size(dir){let bytes=0;for(const n of fs.readdirSync(dir)){const f=path.join(dir,n),s=fs.lstatSync(f);if(s.isSymbolicLink())continue;bytes+=s.isDirectory()?size(f):s.size;}return bytes;}for(const n of CATEGORIES)out[n]=size(this.at(n));return out;}
  heartbeat(host,build,busy,scriptReady,failure=null,closed=false){const c=this.config();atomic(this.at('state/'+host+'.json'),{host,build,machineId:c.machineId,busy:!!busy,scriptReady:scriptReady===true,failure:Feedback.redact(failure),closed:!!closed,rootId:c.rootId,revision:c.revision,time:Date.now()});}
  peer(host,build){
    const f=this.at('state/'+host+'.json');if(!fs.existsSync(f))return {ready:false,state:'waiting',reason:'Other panel has not connected'};
    let p;try{p=json(f);}catch(e){return {ready:false,state:'failed',reason:'Other panel status could not be read'};}
    const c=this.config();let state='ready',reason='Host script ready';
    if(p.closed||!Number.isFinite(p.time)||Date.now()-p.time>=15000||p.time>Date.now()+5000){state='waiting';reason='Open the other panel and run Check Setup';}
    else if(!c.machineId||p.machineId!==c.machineId){state='waiting';reason='Waiting for this Mac’s other panel; saved status came from another installation';}
    else if(p.build!==build){state='failed';reason='Other panel is running a different build';}
    else if(p.revision!==c.revision||p.rootId!==c.rootId){state='waiting';reason='Other panel has not acknowledged this working folder';}
    else if(p.busy){state='waiting';reason='Other panel is busy';}
    else if(p.failure){state='failed';reason=p.failure.message||'Other panel reported a failure';}
    else if(p.scriptReady!==true){state='waiting';reason='Panel is open; its host script has not passed Check Setup';}
    return {ready:state==='ready',available:state==='ready'||(state==='failed'&&!!p.failure&&p.scriptReady===true&&p.build===build&&!p.busy&&!p.closed&&Date.now()-p.time<15000&&p.machineId===c.machineId&&p.rootId===c.rootId&&p.revision===c.revision),state,build:p.build,reason};
  }
  saveFeedback(snapshot,event){const entry={schema:1,id:id(),at:new Date().toISOString(),host:snapshot.host,build:snapshot.build,event,diagnostics:snapshot};Feedback.append(this.at(Feedback.NAME),entry);return Feedback.NAME;}
  feedback(){const events=Feedback.recent(this.at(Feedback.NAME)),panels={};for(const e of events)if(e.diagnostics)panels[e.host]=e.diagnostics;return {product:'KeyTween',format:'combined-feedback',panels,events};}
  queue(raw,build,prepared){
    if(raw.schemaVersion===2)return require('./batches').queue(this,raw,build,prepared);
    const source=raw.sourceFile,isBitmap=raw.layer&&raw.layer.type==='bitmap';let ext=null,digest=null;
    if(isBitmap){if(!source||!fs.existsSync(source))throw Error('Source bitmap is missing.');ext=path.extname(source).toLowerCase();if(!/^\.(png|jpe?g)$/.test(ext))throw Error('PNG or JPEG required.');digest=hash(source);}
    const c=this.config(),transferId=id(),tmp=this.at('transfers/.pending-'+transferId),ready=this.at('transfers/transfer-'+transferId);
    const p=JSON.parse(JSON.stringify(raw));delete p.sourceFile;p.id=transferId;p.createdAt=new Date().toISOString();p.storage={rootId:c.rootId};
    if(isBitmap)p.layer.asset={hash:digest,path:'assets/'+digest+ext,logicalId:p.layer.id};
    const plan=Plan.create(p,build);
    const svg=p.layer.type==='shape'?Vector.svg(p.layer.artwork):null;
    if(svg)p.layer.vectorAsset={path:'vectors/artwork.svg',hash:crypto.createHash('sha256').update(svg).digest('hex')};
    fs.mkdirSync(tmp,{recursive:true});
    try {
      if(isBitmap){fs.mkdirSync(path.join(tmp,'assets'));fs.copyFileSync(source,path.join(tmp,p.layer.asset.path));if(hash(path.join(tmp,p.layer.asset.path))!==digest)throw Error('Bitmap copy failed verification.');}
      if(svg){fs.mkdirSync(path.join(tmp,'vectors'));fs.writeFileSync(path.join(tmp,p.layer.vectorAsset.path),svg,{flag:'wx'});if(hash(path.join(tmp,p.layer.vectorAsset.path))!==p.layer.vectorAsset.hash)throw Error('Vector write failed verification.');}
      atomic(path.join(tmp,'manifest.json'),p);atomic(path.join(tmp,'plan.json'),plan);fs.renameSync(tmp,ready);
      return {id:transferId,manifest:p,plan,path:ready};
    }catch(e){atomic(this.at('recovery/export-'+transferId+'.json'),{id:transferId,state:'failed-export',message:e.message,ownedTemporaryDirectory:'.pending-'+transferId});throw e;}
  }
  packages(){return fs.readdirSync(this.at('transfers')).filter(n=>/^transfer-[a-z0-9-]+$/.test(n)).map(n=>{try{const f=this.at('transfers/'+n+'/manifest.json'),p=json(f);if(!p||p.id!==n.slice(9)||typeof p.createdAt!=='string'||!Number.isFinite(Date.parse(p.createdAt))||!p.composition||typeof p.composition.name!=='string')return null;return {id:p.id,createdAt:p.createdAt,name:p.composition.name,path:path.dirname(f)};}catch(e){return null;}}).filter(Boolean).sort((a,b)=>Date.parse(a.createdAt)-Date.parse(b.createdAt));}
  latest(){const p=this.packages();if(!p.length)throw Error('No completed transfer. Push Selection in AE first.');return p[p.length-1];}
  prepareImport(entry,build,options){
    if(!entry||typeof entry.id!=='string'||!/^[a-z0-9-]+$/.test(entry.id))throw Error('Invalid transfer identity.');
    if(json(this.at('transfers/transfer-'+entry.id+'/manifest.json')).schemaVersion===2)return require('./batches').prepare(this,entry,build,options);
    const base=this.at('transfers/transfer-'+entry.id),manifestFile=noLinks(base,'manifest.json'),p=json(manifestFile);
    Plan.create(p,build);if(p.id!==entry.id||p.storage.rootId!==this.config().rootId)throw Error('Package identity or working history mismatch.');
    let asset=null;if(p.layer.type==='bitmap'){asset=noLinks(base,p.layer.asset.path);if(hash(asset)!==p.layer.asset.hash)throw Error('Bitmap checksum failed. Push again from AE.');}
    let vector=null;if(p.layer.type==='shape'){if(!p.layer.vectorAsset)throw Error('Vector asset is missing. Push again from AE.');vector=noLinks(base,p.layer.vectorAsset.path);if(hash(vector)!==p.layer.vectorAsset.hash||fs.readFileSync(vector,'utf8')!==Vector.svg(p.layer.artwork))throw Error('Vector checksum or geometry differs. Push again from AE.');}
    const receipt=this.at('reports/'+p.id+'.json');if(fs.existsSync(receipt)){const previous=json(receipt);if(previous.saved)return {existingResult:previous,alreadyImported:true};throw Error('This transfer already has an import result. '+(previous.error?'Original failure: '+previous.error+' ':'')+'Push Selection again in AE to create a fresh test.');}
    const journal=this.at('recovery/'+p.id+'.json');if(fs.existsSync(journal))throw Error('An interrupted import needs inspection. Check open Animate documents before pushing a new test.');
    const attempt=id(),out=this.at('tests/KeyTween-'+p.id+'-'+attempt+'.fla');
    atomic(journal,{id:p.id,attempt,state:'importing',output:path.basename(out),started:Date.now()});
    return {id:p.id,manifest:manifestFile,assetPath:asset,vectorPath:vector,outputPath:out,build};
  }
  receipt(result){const copy=JSON.parse(JSON.stringify(result));atomic(this.at('reports/'+result.transferId+'.json'),copy);atomic(this.at('recovery/'+result.transferId+'.json'),{id:result.transferId,state:result.status,completedAt:Date.now(),recovery:result.recovery||'Generated test FLA retained.'});}
  recentResult(){const entries=fs.readdirSync(this.at('reports')).filter(n=>/^[a-z0-9-]+\.json$/.test(n)).map(n=>({n,time:fs.statSync(this.at('reports/'+n)).mtimeMs})).sort((a,b)=>b.time-a.time);return entries.length?json(this.at('reports/'+entries[0].n)):null;}
  cleanupPreview(){return {eligible:[],bytes:0,message:'No files are marked disposable in this proof build. Packages, assets, test projects, and recovery records are retained until save/reopen/publish tests establish safe cleanup.'};}
  diagnostics(build,host,last){let c=null,peer=null;try{c=this.config();peer=this.peer(host==='AEFT'?'FLPR':'AEFT',build);}catch(e){}
    const latestImport=this.recentResult(),r=last||latestImport;const imported=latestImport?{id:latestImport.transferId,build:latestImport.build,status:latestImport.status,saved:latestImport.saved,representation:latestImport.representation,artworkVerification:latestImport.artworkVerification,layers:layerSummaries(latestImport.layers),verification:latestImport.verification,error:latestImport.error}:null;return {product:'KeyTween',build,host,latestImport:imported,storage:c?{revision:c.revision,machineId:c.machineId,folderName:path.basename(c.root),syncFolder:/Mobile Documents|CloudStorage|iCloud|Dropbox|OneDrive/.test(c.root)}:null,peer,transfer:r?{id:r.transferId,status:r.status,host:r.host,motion:r.motion,artwork:r.artwork,representation:r.representation,artworkVerification:r.artworkVerification,verification:r.verification,publish:r.publish,error:r.error,line:r.line,progress:r.progress,timeline:r.timeline,anchor:r.anchor,layers:layerSummaries(r.layers),counts:r.counts,warnings:r.warnings}:null,privacy:'Local summary only. No artwork or full file paths included.'};}
}
module.exports={Store,id,hash,json,atomic,copyTree,noLinks,CATEGORIES,defaultLocator};
