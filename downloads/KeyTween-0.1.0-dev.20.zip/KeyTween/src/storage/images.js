'use strict';
const fs=require('fs'),crypto=require('crypto');
const MAX_BYTES=128*1024*1024,MAX_PIXELS=64*1024*1024;
const digest=data=>crypto.createHash('sha256').update(data).digest('hex');
const Metadata=require('./image-metadata');
function dimensions(b){const m=Metadata.inspect(b);return {size:m.size,format:m.format};}
function plan(composition,size,settings={}){
 const manual=settings.imageMaxSide;const limit=manual==null?Math.max(composition.width,composition.height):manual;
 if(!Number.isInteger(limit)||limit<1||limit>8192)throw Error('Image limit must be 1–8192 px. Enter auto to follow the composition.');
 const longest=Math.max(size[0],size[1]),ratio=limit/longest,resize=ratio<1||ratio>1&&settings.upscaleImages===true;
 const pixelSize=resize?size.map(n=>Math.max(1,Math.round(n*ratio))):size.slice();
 if(pixelSize[0]*pixelSize[1]>MAX_PIXELS)throw Error('Resized image exceeds the 64 megapixel limit.');
 return {pixelSize,limit,mode:manual==null?'composition':'manual',operation:resize?(ratio<1?'downscale':'upscale'):'unchanged',upscale:settings.upscaleImages===true};
}
async function prepare(raw,settings,convert){
 const entries={},byItem=[],cache=new Map(),colourCache=new Map(),psdCache=new Map(),summary=[];let total=0;
 const items=require('../shared/tree').flatten(raw.items);
 for(let index=0;index<items.length;index++){const item=items[index];
  if(item.layer.type!=='bitmap')continue;
  const file=item.sourceFile,stat=fs.statSync(file);if(!stat.isFile()||stat.size>MAX_BYTES)throw Error('Image exceeds the 128 MB source-file limit: '+item.layer.name);
  const source=fs.readFileSync(file),sourceMetadata=Metadata.inspect(source),size=item.layer.artwork.size,sourceHash=digest(source);let input=source,original=sourceMetadata,psd=null;
  if(item.flattenedPSD&&item.flattenedPSD.render){sourceMetadata.aeRender=item.flattenedPSD.render;if(sourceMetadata.aeRender.requireEmbeddedProfile&&!sourceMetadata.icc&&!sourceMetadata.srgb&&!Metadata.calibrated(sourceMetadata)&&!sourceMetadata.aeRender.colorProof)throw Error('AE PNG output has no usable colour information. Colour settings are recorded in local feedback; the source project was left unchanged.');}
  if(sourceMetadata.format==='psd'){const extracted=require('./psd-layers').extract(source,sourceMetadata,item.psdSource,size,psdCache,sourceHash);input=extracted.data;original=extracted.metadata;psd=extracted.report;}
  if(original.size[0]!==size[0]||original.size[1]!==size[1])throw Error('Image pixel dimensions differ from AE footage interpretation: '+item.layer.name+'. Reimport the source or use a normalized PNG/JPEG.');
  const task=plan(raw.composition,size,settings),key=sourceHash+':'+JSON.stringify(psd)+':'+JSON.stringify(original.aeRender?[original.aeRender.workingSpace,original.aeRender.linear,original.aeRender.depth,original.aeRender.template,original.aeRender.colorProof]:null)+':'+size.join('x')+':'+task.pixelSize.join('x');let data=cache.get(key);
  if(!data){data=Buffer.from(await convert(input,original.format,size,task.pixelSize,original));const actual=dimensions(data);if(actual.format!=='png'||actual.size[0]!==task.pixelSize[0]||actual.size[1]!==task.pixelSize[1])throw Error('Image resizer returned the wrong format or pixel dimensions.');const icc=Metadata.inspect(data).icc;if(!icc||!icc.equals(require('./native-images').profile()))throw Error('Exported image must contain the verified sRGB ICC profile.');total+=data.length;if(total>256*1024*1024)throw Error('Prepared image batch exceeds 256 MB. Transfer fewer layers.');cache.set(key,data);if(original.aeRender&&original.aeRender.verifiedOutput)colourCache.set(key,original.aeRender.verifiedOutput);}
  if(original.aeRender&&colourCache.has(key))original.aeRender.verifiedOutput=colourCache.get(key);
  const processing=Object.assign({sourceSize:size.slice(),flattenedPSD:item.flattenedPSD||null,format:'png',sourceFormat:sourceMetadata.format,colorSpace:'sRGB',colorConversion:original.aeRender&&original.aeRender.verifiedOutput?'verified AE '+original.aeRender.verifiedOutput.profile+' → sRGB':original.icc?'embedded profile → sRGB':Metadata.calibrated(original)?'PNG gamma + primaries → ColorSync → sRGB':original.space==='Gray'?'assumed Gray Gamma 2.2 → sRGB':'assumed sRGB (untagged RGB)',profileSHA256:digest(require('./native-images').profile()),psdComposite:!!psd&&psd.mode==='merged',psdSource:psd},task);
  entries[item.layer.id]=byItem[index]={data,sourceHash,pixelSize:task.pixelSize,processing,format:processing.format};summary.push(Object.assign({layerId:item.layer.id,name:item.layer.name,sourceBytes:source.length,outputBytes:data.length},processing));
 }
 return {entries,byItem,summary};
}
function verifyAsset(asset,data){if(!asset.pixelSize)return;const d=dimensions(data);if(asset.processing&&asset.processing.colorSpace==='sRGB'){const icc=Metadata.inspect(data).icc;if(!icc||digest(icc)!==asset.processing.profileSHA256||!icc.equals(require('./native-images').profile()))throw Error('Prepared image does not contain the expected sRGB ICC profile.');}if(d.size[0]!==asset.pixelSize[0]||d.size[1]!==asset.pixelSize[1])throw Error('Prepared image dimensions do not match the package.');}
module.exports={dimensions,plan,prepare,verifyAsset,digest};
