'use strict';
const fs=require('fs'),path=require('path');
function folder(store,settings,create=false){
 const custom=settings.imageFolder,dir=custom||store.at('_Links');
 if(!path.isAbsolute(dir)||/^[/\\]{2}/.test(dir))throw Error('Choose an absolute local image folder.');
 if(!custom&&create)fs.mkdirSync(dir,{recursive:true});
 if(!fs.existsSync(dir))throw Error('Image Folder Unavailable. Reconnect it or choose another folder: '+dir);
 const stat=fs.lstatSync(dir);if(!stat.isDirectory()||stat.isSymbolicLink())throw Error('Choose the actual image folder, not a file or symbolic link.');
 fs.accessSync(dir,fs.constants.R_OK|fs.constants.W_OK);return dir;
}
function place(store,p,packageRoot,settings){
 const items=require('../shared/tree').flatten(p.items);
 if(!settings.placeImages||!items.some(i=>i.layer.type==='bitmap'))return;
 const dir=folder(store,settings,true),copied=new Map(),{hash}=require('./store');
 for(const item of items){if(item.layer.type!=='bitmap')continue;const a=item.layer.asset,name=path.basename(a.path),source=path.join(packageRoot,a.path),dest=path.join(dir,name);
  if(!copied.has(dest)){fs.copyFileSync(source,dest,fs.constants.COPYFILE_EXCL);if(hash(dest)!==a.hash)throw Error('Placed image did not pass its checksum. Transfer was not published.');copied.set(dest,true);}
  a.placement=settings.imageFolder?{kind:'chosen-folder',file:dest}:{kind:'working-folder',relative:'_Links/'+name};
 }
}
function resolve(store,a){
 if(!a.placement)return null;const p=a.placement;let file;
 if(p.kind==='working-folder'&&/^_Links\/[a-z0-9-]+\.(png|jpe?g)$/.test(p.relative))file=store.at(p.relative);
 else if(p.kind==='chosen-folder'&&typeof p.file==='string'&&path.isAbsolute(p.file)&&!/^[/\\]{2}/.test(p.file))file=p.file;
 else throw Error('Invalid placed-image location.');
 if(!fs.existsSync(file)||!fs.lstatSync(file).isFile()||fs.lstatSync(file).isSymbolicLink())throw Error('Image Folder Unavailable or placed image missing. Reconnect the image folder, or choose another and push again.');
 if(require('./store').hash(file)!==a.hash)throw Error('Placed image changed after export. Push again to create a fresh transfer.');return file;
}
module.exports={folder,place,resolve};
