/* Batch envelope; every layer retains the existing transform/artwork contract. */
var KTBatchJSON=typeof KTJSON!=='undefined'?KTJSON:JSON;
var KTBatch=(function(){
 function validate(p,build){
  if(!p||p.schemaVersion!==2||p.build!==build||!p.items||!p.items.length||p.items.length>50||!(/^[a-z0-9-]+$/.test(p.sourceKey))||!(/^[a-z0-9-]+$/.test(p.id)))throw Error('Invalid batch envelope or build.');
  if(p.scope!=='selection'&&p.scope!=='composition')throw Error('Invalid batch scope.');
  var plans=[],total=0,count=0;
  function check(items,composition,depth){
   if(depth>8||!items||!items.length||items.length>50)throw Error('Invalid or too-deep nested composition.');var seen={},previous=0;
   for(var i=0;i<items.length;i++){var item=items[i];if(++count>200)throw Error('Transfer exceeds 200 nested layers.');
    if(!item.layer||!(/^[0-9]+$/.test(item.layer.id))||seen['$'+item.layer.id])throw Error('Duplicate or invalid source layer identity.');seen['$'+item.layer.id]=true;
    if(item.source.identity!==p.sourceKey||item.layer.stackingIndex<=previous)throw Error('Batch identity or stacking order differs.');previous=item.layer.stackingIndex;
    if(KTBatchJSON.stringify(item.composition)!==KTBatchJSON.stringify(composition))throw Error('Batch composition settings differ.');
    var plan=KTPlan.create(item,build);if(depth===0)plans.push(plan);total+=plan.totalFrames;
    if(item.layer.type==='symbol'){
     var a=item.layer.artwork,c=item.children&&item.children[0]&&item.children[0].composition;
     if(typeof item.layer.startTime!=='number'||!isFinite(item.layer.startTime)||Math.abs(item.layer.startTime*composition.fps-Math.round(item.layer.startTime*composition.fps))>1e-6||item.layer.inPoint<item.layer.startTime-1e-6||item.layer.outPoint>item.layer.startTime+a.duration+1e-6)throw Error('Invalid nested playback interval.');
     if(!c||c.width!==a.size[0]||c.height!==a.size[1]||c.duration!==a.duration||c.fps!==a.fps||c.fps!==composition.fps)throw Error('Nested symbol composition differs.');check(item.children,c,depth+1);
    }else if(item.children&&item.children.length)throw Error('Only symbols may contain child layers.');
   }
  }
  check(p.items,p.composition,0);
  if(total>90000)throw Error('Batch frame budget exceeded.');return plans;
 }
 return {validate:validate};
}());
if(typeof module!=='undefined'&&module.exports){var KTPlan=require('./plan');module.exports=KTBatch;}
