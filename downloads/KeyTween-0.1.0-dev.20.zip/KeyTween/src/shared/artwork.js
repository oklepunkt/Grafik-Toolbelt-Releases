var KTArtwork = (function () {
    var V=typeof module!=='undefined'?require('./vectors'):KTVector;
    function need(ok,msg){if(!ok)throw Error(msg);}
    function number(n){return typeof n==='number'&&isFinite(n);}
    function vector(v,n){if(!v||v.length!==n)return false;for(var i=0;i<n;i++)if(!number(v[i]))return false;return true;}
    function color(c){return vector(c,3)&&c[0]>=0&&c[0]<=1&&c[1]>=0&&c[1]<=1&&c[2]>=0&&c[2]<=1;}
    function validate(l){
        if(l&&l.type==='symbol'){var sym=l.artwork;need(sym&&sym.representation==='editable-symbol'&&sym['static']===false&&vector(sym.size,2)&&sym.size[0]>0&&sym.size[1]>0&&sym.size[0]<=8192&&sym.size[1]<=8192&&vector(sym.origin,2)&&sym.origin[0]===0&&sym.origin[1]===0&&number(sym.duration)&&sym.duration>0&&number(sym.fps),'Invalid nested symbol artwork.');return;}
        need(l&&l.artwork&&l.artwork['static']===true,'Static bitmap, text or vector artwork is required.');var a=l.artwork,s,t,m,i;
        need(vector(a.size,2)&&a.size[0]>0&&a.size[1]>0&&a.size[0]<=32768&&a.size[1]<=32768,'Invalid artwork dimensions.');
        if(l.type==='bitmap'){
            need(a.representation==='raster-artwork'&&l.asset&&/^assets\/([a-z0-9-]{8,80}-)?[a-f0-9]{64}\.(png|jpg|jpeg)$/.test(l.asset.path)&&/^[a-f0-9]{64}$/.test(l.asset.hash),'Invalid bitmap path or SHA-256.');
            if(l.asset.pixelSize){var px=l.asset.pixelSize;need(vector(px,2)&&px[0]>=1&&px[1]>=1&&px[0]<=32768&&px[1]<=32768&&px[0]===Math.floor(px[0])&&px[1]===Math.floor(px[1]),'Invalid processed bitmap dimensions.');}
            return;
        }
        need(vector(a.origin,2),'Native artwork needs its source origin.');need(!l.asset,'Native artwork must not carry a raster asset.');
        if(l.type==='shape'){
            need(a.representation==='editable-vector','Shape must be native vector artwork.');V.validate(a.vector);
            if(l.vectorAsset)need((/^vectors\/(artwork|[0-9]+-[a-f0-9]{64})\.svg$/.test(l.vectorAsset.path))&&/^[a-f0-9]{64}$/.test(l.vectorAsset.hash),'Invalid vector asset path or SHA-256.');
        }else if(l.type==='text'){
            need(a.representation==='editable-text','Text must remain editable.');t=a.text;need(t&&typeof t.content==='string'&&t.content.length>0&&t.content.length<=1000&&!/[\r\n\t]/.test(t.content),'Use single-line point text.');
            need(typeof t.font==='string'&&t.font.length>0&&t.font.length<=256&&typeof t.fontFamily==='string'&&t.fontFamily.length>0&&t.fontFamily.length<=256&&typeof t.fontStyle==='string'&&t.fontStyle.length<=128,'Invalid font description.');
            need(number(t.fontSize)&&t.fontSize>=1&&t.fontSize<=1000&&color(t.fill)&&typeof t.bold==='boolean'&&typeof t.italic==='boolean'&&/^(left|center|right)$/.test(t.alignment),'Invalid text styling.');
        }else throw Error('Each layer must contain a bitmap, single-style point text, or static vector artwork.');
    }
    return {validate:validate};
}());
if(typeof module!=='undefined')module.exports=KTArtwork;
