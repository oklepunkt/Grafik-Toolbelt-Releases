/* ES3-compatible conversion math, shared by Node tests and both host engines. */
var KTMath = (function () {
    var EPS = 1e-7, LINEAR = [{x:0,y:0},{x:1/3,y:1/3},{x:2/3,y:2/3},{x:1,y:1}];
    function arr(v) { return typeof v === 'number' ? [v] : v; }
    function lerp(a,b,t) { return a+(b-a)*t; }
    function point(a,b,t) { return {x:lerp(a.x,b.x,t),y:lerp(a.y,b.y,t)}; }
    function split(c,t) { var a=point(c[0],c[1],t), b=point(c[1],c[2],t), d=point(c[2],c[3],t), e=point(a,b,t), f=point(b,d,t), g=point(e,f,t); return [[c[0],a,e,g],[g,f,d,c[3]]]; }
    function at(c,t) { return split(c,t)[0][3]; }
    function solve(c,x) { var lo=0,hi=1,m,i; for(i=0;i<55;i++){m=(lo+hi)/2;if(at(c,m).x<x)lo=m;else hi=m;}return (lo+hi)/2; }
    function sliceCurve(c,x0,x1) {
        if(x1-x0<EPS) return LINEAR;
        var t0=solve(c,x0),t1=solve(c,x1), sub=split(c,t1)[0];
        if(t0>EPS) sub=split(sub,t0/t1)[1];
        var dx=sub[3].x-sub[0].x,dy=sub[3].y-sub[0].y,out=[],i;
        if(Math.abs(dy)<EPS) { if(Math.abs(sub[1].y-sub[0].y)>EPS || Math.abs(sub[2].y-sub[0].y)>EPS) throw Error('Zero-change endpoints with overshoot need a later sampled-tween build.'); return LINEAR; }
        for(i=0;i<4;i++)out.push({x:(sub[i].x-sub[0].x)/dx,y:(sub[i].y-sub[0].y)/dy});
        return out;
    }
    function frame(t,fps) { return Math.floor(t*fps+0.5+EPS); }
    function firstVisible(t,fps) { return Math.ceil(t*fps-EPS); }
    function matrix(p,s,r,a) { var rad=r*Math.PI/180,c=Math.cos(rad),n=Math.sin(rad),sx=s[0]/100,sy=s[1]/100;
        var m={a:c*sx,b:n*sx,c:-n*sy,d:c*sy,tx:0,ty:0}; m.tx=p[0]-m.a*a[0]-m.c*a[1];m.ty=p[1]-m.b*a[0]-m.d*a[1];return m; }
    function transform(m,p) { return [m.a*p[0]+m.c*p[1]+m.tx,m.b*p[0]+m.d*p[1]+m.ty]; }
    function curve(prop,left,right) {
        if(left.outType==='hold') return null;
        var a=arr(left.value),b=arr(right.value), dt=right.time-left.time, curves=[],i,d,out,inc,x1,x2,y1,y2;
        if(left.outType==='linear' && right.inType==='linear')return LINEAR;
        for(i=0;i<(prop.spatial?1:a.length);i++) {
            d=prop.spatial?Math.sqrt(Math.pow(b[0]-a[0],2)+Math.pow(b[1]-a[1],2)):b[i]-a[i];
            out=left.outEase[i]||left.outEase[0];inc=right.inEase[i]||right.inEase[0];
            x1=left.outType==='linear'?1/3:out.influence/100;
            x2=right.inType==='linear'?2/3:1-inc.influence/100;
            if(Math.abs(d)<EPS) { if((left.outType!=='linear'&&Math.abs(out.speed)>EPS)||(right.inType!=='linear'&&Math.abs(inc.speed)>EPS))throw Error('Zero-change endpoints with temporal overshoot are unsupported in this prototype.'); continue; }
            y1=left.outType==='linear'?x1:out.speed*dt*x1/d;
            y2=right.inType==='linear'?x2:1-inc.speed*dt*(1-x2)/d;
            if(x1>x2+EPS)throw Error('Overlapping temporal handles need a host-verified sampled-tween converter.');
            curves.push([{x:0,y:0},{x:x1,y:y1},{x:x2,y:y2},{x:1,y:1}]);
        }
        if(!curves.length)return LINEAR;
        for(i=1;i<curves.length;i++)for(d=1;d<3;d++)if(Math.abs(curves[i][d].x-curves[0][d].x)>EPS || Math.abs(curves[i][d].y-curves[0][d].y)>EPS)throw Error('Different easing per axis needs sampled native tweens (not enabled yet).');
        return curves[0];
    }
    function segment(prop,t) { var k=prop.keys,i;for(i=0;i<k.length-1;i++)if(t>=k[i].time-EPS&&t<k[i+1].time-EPS)return i;return -1; }
    function evaluate(prop,t) {
        var k=prop.keys,i=segment(prop,t),a,b,c,u,v=[],j;
        if(!k.length)return prop.value;
        if(i<0)return t<k[0].time?k[0].value:k[k.length-1].value;
        a=arr(k[i].value);b=arr(k[i+1].value);c=curve(prop,k[i],k[i+1]);
        u=c?at(c,solve(c,(t-k[i].time)/(k[i+1].time-k[i].time))).y:0;
        for(j=0;j<a.length;j++)v.push(lerp(a[j],b[j],u));
        return typeof k[i].value==='number'?v[0]:v;
    }
    function spanCurve(prop,t0,t1) {
        var i=segment(prop,(t0+t1)/2),k=prop.keys,c;
        if(i<0)return LINEAR;
        c=curve(prop,k[i],k[i+1]); if(!c)return LINEAR;
        return sliceCurve(c,(t0-k[i].time)/(k[i+1].time-k[i].time),(t1-k[i].time)/(k[i+1].time-k[i].time));
    }
    function pose(props,t) { var p=evaluate(props.position,t),s=evaluate(props.scale,t),r=evaluate(props.rotation,t),a=evaluate(props.anchor,t),o=evaluate(props.opacity,t);
        return {position:p,scale:s,rotation:r,anchor:a,opacity:o,matrix:matrix(p,s,r,a)}; }
    function compose(outer,inner) {return {a:outer.a*inner.a+outer.c*inner.b,b:outer.b*inner.a+outer.d*inner.b,c:outer.a*inner.c+outer.c*inner.d,d:outer.b*inner.c+outer.d*inner.d,tx:outer.a*inner.tx+outer.c*inner.ty+outer.tx,ty:outer.b*inner.tx+outer.d*inner.ty+outer.ty};}
    function inverse(m) {var q=m.a*m.d-m.b*m.c;if(!isFinite(q)||Math.abs(q)<1e-8)throw Error('Artwork transform is not invertible.');return {a:m.d/q,b:-m.b/q,c:-m.c/q,d:m.a/q,tx:(m.c*m.ty-m.d*m.tx)/q,ty:(m.b*m.tx-m.a*m.ty)/q};}
    return {inverse:inverse,compose:compose,EPS:EPS,LINEAR:LINEAR,arr:arr,frame:frame,firstVisible:firstVisible,matrix:matrix,transform:transform,curve:curve,evaluate:evaluate,spanCurve:spanCurve,pose:pose,at:at,solve:solve,sliceCurve:sliceCurve};
}());
if (typeof module !== 'undefined') module.exports = KTMath;
