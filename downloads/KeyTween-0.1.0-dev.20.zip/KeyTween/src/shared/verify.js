var KTVerify = (function () {
    var M=typeof KTMath!=='undefined'?KTMath:require('./math');
    function compare(p,actual) {
        var max={position:0,scale:0,rotation:0,opacity:0,corners:0},failures=[],firstFailure=null,geometryPass=true,opacityPass=true,prevAngle=null,i,j,a,e,m,angle,sx,sy,pa,pe,d;
        function fail(f,kind,error) { if(kind==='opacity percentage points')opacityPass=false;else geometryPass=false; if(!firstFailure)firstFailure={frame:f+1,kind:kind,error:error};if(failures.length<30)failures.push({frame:f+1,kind:kind,error:error}); }
        if(actual.length!==p.reference.length)return {pass:false,status:'incomplete-readback',expected:p.reference.length,received:actual.length};
        var anchor=p.layer.properties.anchor.value,size=p.layer.artwork.size,origin=p.layer.artwork.origin||[0,0],points=[origin,[origin[0]+size[0],origin[1]],[origin[0],origin[1]+size[1]],[origin[0]+size[0],origin[1]+size[1]],anchor];
        for(i=0;i<actual.length;i++) {
            a=actual[i];e=p.reference[i];
            if(a.frame!==i||a.visible!==e.visible){fail(i,'timing/visibility',null);continue;}
            if(!e.visible)continue;
            m=a.matrix;
            if(!m||!isFinite(m.a+m.b+m.c+m.d+m.tx+m.ty)||typeof a.opacity!=='number'||!isFinite(a.opacity)){fail(i,'missing tween readback',null);continue;}
            pa=M.transform(m,anchor);d=Math.max(Math.abs(pa[0]-e.position[0]),Math.abs(pa[1]-e.position[1]));max.position=Math.max(max.position,d);if(d>0.5)fail(i,'position',d);
            sx=Math.sqrt(m.a*m.a+m.b*m.b)*100;sy=Math.sqrt(m.c*m.c+m.d*m.d)*100;
            d=Math.max(Math.abs(sx-e.scale[0]),Math.abs(sy-e.scale[1]));max.scale=Math.max(max.scale,d);if(d>0.1)fail(i,'scale percentage points',d);
            angle=Math.atan2(m.b,m.a)*180/Math.PI;
            if(prevAngle===null)angle+=360*Math.round((e.rotation-angle)/360);
            else angle+=360*Math.round((prevAngle-angle)/360);
            prevAngle=angle;d=Math.abs(angle-e.rotation);max.rotation=Math.max(max.rotation,d);if(d>0.1)fail(i,'unwrapped rotation degrees',d);
            d=Math.abs(a.opacity-e.opacity);max.opacity=Math.max(max.opacity,d);if(d>0.5)fail(i,'opacity percentage points',d);
            var expected=M.matrix(e.position,e.scale,e.rotation,anchor);
            for(j=0;j<points.length;j++){pa=M.transform(m,points[j]);pe=M.transform(expected,points[j]);d=Math.max(Math.abs(pa[0]-pe[0]),Math.abs(pa[1]-pe[1]));max.corners=Math.max(max.corners,d);if(d>0.5)fail(i,'artwork corner/anchor pixels',d);}
        }
        return {pass:failures.length===0,geometryPass:geometryPass,opacityPass:opacityPass,status:failures.length?'failed':'passed',frameCount:actual.length,maxErrors:max,firstFailure:firstFailure,failures:failures,tolerances:{position:0.5,scale:0.1,rotation:0.1,opacity:0.5,corners:0.5}};
    }
    return {compare:compare};
}());
if(typeof module!=='undefined')module.exports=KTVerify;
