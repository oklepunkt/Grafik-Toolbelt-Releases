var KTPlan = (function () {
    var M = typeof KTMath !== 'undefined' ? KTMath : require('./math');
    var Art=typeof KTArtwork!=='undefined'?KTArtwork:require('./artwork');
    var props=['position','scale','rotation','opacity','anchor'];
    function need(ok,msg) { if(!ok)throw Error(msg); }
    function number(v) { return typeof v==='number'&&isFinite(v); }
    function vector(v,n) { if(n===1)return number(v);if(!v||v.length!==n)return false;for(var i=0;i<n;i++)if(!number(v[i]))return false;return true; }
    function supportedScale(v){return v&&v[0]>0&&v[1]>0;}
    function validate(p,build,sourceOnly) {
        need(p&&p.schemaVersion===1,'Unsupported package schema.');
        need(p.build===build,'Build mismatch: reinstall and reopen both KeyTween panels.');
        if(!sourceOnly)need(typeof p.id==='string'&&/^[a-zA-Z0-9_-]{8,100}$/.test(p.id),'Invalid transfer ID.');
        need(p.target&&p.target.kind==='new-matching','This proof only creates New Matching Documents.');
        need(p.timeDomain==='composition-relative-seconds','Unsupported time domain.');
        var c=p.composition,l=p.layer,n,i,j,k,v,dim;
        need(c&&number(c.width)&&c.width>0&&c.width<=8192&&number(c.height)&&c.height>0&&c.height<=8192,'Invalid stage size.');
        need(c.fps===30,'Set the After Effects composition to 30 fps before transfer.');
        need(c.pixelAspect===1&&number(c.duration)&&c.duration>0&&c.duration*c.fps<=18000,'Square pixels and a maximum of 18,000 frames are required.');
        need(c.rangeStart===0&&c.rangeEnd===c.duration,'The prototype exports the full composition.');
        need(c.displayStart===0,'Nonzero display-start time awaits the time-domain host fixture.');
        if(!sourceOnly||l.type!=='bitmap')Art.validate(l);
        need(number(l.inPoint)&&number(l.outPoint)&&l.outPoint>l.inPoint,'Invalid layer visibility range.');
        for(i=0;i<props.length;i++) {
            n=props[i];v=l.properties[n];dim=(n==='rotation'||n==='opacity')?1:2;
            need(v&&vector(v.value,dim)&&v.keys&&v.keys.length<=2000&&!v.expression,'Invalid or expression-driven '+n+'.');
            need(n!=='anchor'||v.keys.length===0,'Animated anchors are not supported yet.');
            for(j=0;j<v.keys.length;j++) {
                k=v.keys[j];need(number(k.time)&&vector(k.value,dim),'Invalid '+n+' key.');
                need(j===0||k.time>v.keys[j-1].time,'Key times must increase.');
                need(Math.abs(k.time*c.fps-M.frame(k.time,c.fps))<1e-6,'Subframe keys require a later time-conversion build.');
                need(/^(linear|hold|bezier)$/.test(k.inType)&&/^(linear|hold|bezier)$/.test(k.outType),'Unknown interpolation.');
                need(k.inEase&&k.outEase&&k.inEase.length>0&&k.outEase.length>0,'Missing temporal ease.');
                var e=k.inEase.concat(k.outEase),ei;
                for(ei=0;ei<e.length;ei++)need(number(e[ei].speed)&&number(e[ei].influence)&&e[ei].influence>=0.1&&e[ei].influence<=100,'Invalid temporal ease.');
                need(!k.roving&&!k.autoBezier,'Roving and temporal auto-Bezier keys await host probes.');
                if(v.spatial)need(k.spatialLinear,'Curved spatial paths require sampled native tweens (not enabled).');
            }
        }
        if(sourceOnly){
            var scale=l.properties.scale;need(supportedScale(scale.value),'Negative/zero scale requires the extended-transform fixture.');
            for(i=0;i<scale.keys.length;i++)need(supportedScale(scale.keys[i].value),'Negative/zero scale requires the extended-transform fixture.');
            return p;
        }
        need(p.reference&&p.reference.length===Math.ceil(c.duration*c.fps-1e-7),'Missing full-frame AE references.');
        for(i=0;i<p.reference.length;i++) {
            v=p.reference[i];need(v.frame===i&&number(v.time)&&Math.abs(v.time-i/c.fps)<1e-7&&typeof v.visible==='boolean','Invalid reference frame.');
            if(v.visible){need(vector(v.position,2)&&vector(v.scale,2)&&number(v.rotation)&&number(v.opacity),'Invalid reference transform.');need(supportedScale(v.scale),'Negative/zero scale requires the extended-transform fixture.');}
        }
        return p;
    }
    function create(p,build) {
        validate(p,build);
        var c=p.composition,l=p.layer,fps=c.fps,total=p.reference.length;
        var first=Math.max(0,M.firstVisible(l.inPoint,fps)),end=Math.min(total,M.firstVisible(l.outPoint,fps));
        need(end>first,'The layer has no visible destination frames.');
        var set={},frames=[],i,j,k,n,f,keys,poses=[],spans=[],from,to,r,curves,properties=l.properties;
        var animated=false;for(i=0;i<props.length;i++)if(properties[props[i]].keys.length)animated=true;
        set[first]=true;if(animated)set[end-1]=true;
        for(i=0;i<props.length;i++) {
            keys=properties[props[i]].keys;
            for(j=0;j<keys.length;j++) {
                f=M.frame(keys[j].time,fps);
                if(f>=first&&f<end)set[f]=true;
                if(j>0&&keys[j-1].outType==='hold'&&f-1>=first&&f-1<end)set[f-1]=true;
            }
        }
        for(k in set)if(Object.prototype.hasOwnProperty.call(set,k))frames.push(Number(k));
        frames.sort(function(a,b){return a-b;});
        for(i=0;i<frames.length;i++)poses.push(M.pose(properties,frames[i]/fps));
        for(i=0;i<frames.length-1;i++) {
            from=frames[i];to=frames[i+1];r=poses[i+1].rotation-poses[i].rotation;
            curves={};for(j=0;j<4;j++){n=props[j];curves[n]=M.spanCurve(properties[n],from/fps,to/fps);}
            spans.push({from:from,to:to,kind:to-from>1?'classic-tween':'boundary-key',curves:curves,rotationDelta:r});
        }
        // Check analytic conversion against independently evaluated AE properties before host mutation.
        var ref,calc,error=0,d,maxRotationStep=0;
        for(i=first;i<end;i++) {
            ref=p.reference[i];calc=M.pose(properties,i/fps);
            for(j=0;j<2;j++) {error=Math.max(error,Math.abs(calc.position[j]-ref.position[j]));need(Math.abs(calc.scale[j]-ref.scale[j])<=0.01,'Scale easing conversion disagrees with AE at frame '+(i+1)+'.');}
            need(Math.abs(calc.rotation-ref.rotation)<=0.01&&Math.abs(calc.opacity-ref.opacity)<=0.01,'Easing conversion disagrees with AE at frame '+(i+1)+'.');
            if(i>first)maxRotationStep=Math.max(maxRotationStep,Math.abs(ref.rotation-p.reference[i-1].rotation));
        }
        need(error<=0.05,'Position easing conversion disagrees with AE; sampled native support is pending.');
        need(maxRotationStep<180,'Rotation changes 180° or more in one frame; unwrapped verification would be ambiguous.');
        return {build:build,totalFrames:total,first:first,end:end,frames:frames,poses:poses,spans:spans,representation:animated?'classic-tween':'held-frame',artwork:l.artwork.representation,sampling:animated?'original-keys-with-boundary-splits':'one-key-held-for-layer-duration',status:'host-verification-required'};
    }
    return {validate:function(p,build){return validate(p,build,false);},validateSource:function(p,build){return validate(p,build,true);},create:create};
}());
if(typeof module!=='undefined')module.exports=KTPlan;
