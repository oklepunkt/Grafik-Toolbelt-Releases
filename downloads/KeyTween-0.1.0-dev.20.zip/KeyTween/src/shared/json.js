/* Small ES3 JSON codec for Adobe hosts. No eval of package contents. */
var KTJSON = (function () {
    function quote(s) {
        return '"' + String(s).replace(/["\\\x00-\x1f\u2028\u2029]/g, function (c) {
            var n = c.charCodeAt(0).toString(16);
            if (c === '"') return '\\"';
            if (c === '\\') return '\\\\';
            return '\\u' + ('0000' + n).slice(-4);
        }) + '"';
    }
    function stringify(v) {
        var a = [], k, i;
        if (v === null || v === undefined) return 'null';
        if (typeof v === 'string') return quote(v);
        if (typeof v === 'number') { if (!isFinite(v)) throw Error('Non-finite JSON number'); return String(v); }
        if (typeof v === 'boolean') return String(v);
        if (Object.prototype.toString.call(v) === '[object Array]') {
            for (i = 0; i < v.length; i++) a.push(stringify(v[i]));
            return '[' + a.join(',') + ']';
        }
        for (k in v) if (Object.prototype.hasOwnProperty.call(v, k) && typeof v[k] !== 'function' && v[k] !== undefined) a.push(quote(k) + ':' + stringify(v[k]));
        return '{' + a.join(',') + '}';
    }
    function parse(s) {
        var p = 0, depth = 0;
        function fail() { throw Error('Invalid JSON at character ' + p); }
        function ws() { while (/\s/.test(s.charAt(p)) && p < s.length) p++; }
        function str() {
            var out = '', c, e, hex;
            if (s.charAt(p++) !== '"') fail();
            while (p < s.length) {
                c = s.charAt(p++);
                if (c === '"') return out;
                if (c === '\\') {
                    e = s.charAt(p++);
                    if (e === 'u') { hex = s.substr(p, 4); if (!/^[0-9a-fA-F]{4}$/.test(hex)) fail(); out += String.fromCharCode(parseInt(hex, 16)); p += 4; }
                    else if (e === '"' || e === '\\' || e === '/') out += e;
                    else if (e === 'b') out += '\b'; else if (e === 'f') out += '\f';
                    else if (e === 'n') out += '\n'; else if (e === 'r') out += '\r'; else if (e === 't') out += '\t'; else fail();
                } else { if (c.charCodeAt(0) < 32) fail(); out += c; }
            }
            fail();
        }
        function value() {
            ws(); if (++depth > 80) fail();
            var c = s.charAt(p), v, k, m;
            if (c === '"') v = str();
            else if (c === '[') {
                p++; v = []; ws();
                if (s.charAt(p) !== ']') { while (true) { v.push(value()); ws(); if (s.charAt(p) !== ',') break; p++; } }
                if (s.charAt(p++) !== ']') fail();
            } else if (c === '{') {
                p++; v = {}; ws();
                if (s.charAt(p) !== '}') { while (true) {
                    ws(); k = str(); if (k === '__proto__' || k === 'prototype' || k === 'constructor' || Object.prototype.hasOwnProperty.call(v, k)) fail();
                    ws(); if (s.charAt(p++) !== ':') fail(); v[k] = value(); ws(); if (s.charAt(p) !== ',') break; p++;
                } }
                if (s.charAt(p++) !== '}') fail();
            } else if (s.substr(p, 4) === 'true') { p += 4; v = true; }
            else if (s.substr(p, 5) === 'false') { p += 5; v = false; }
            else if (s.substr(p, 4) === 'null') { p += 4; v = null; }
            else { m = /^-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?/.exec(s.slice(p)); if (!m) fail(); p += m[0].length; v = Number(m[0]); if (!isFinite(v)) fail(); }
            depth--; return v;
        }
        var v = value(); ws(); if (p !== s.length) fail(); return v;
    }
    return { stringify: stringify, parse: parse };
}());
if (typeof module !== 'undefined') module.exports = KTJSON;
