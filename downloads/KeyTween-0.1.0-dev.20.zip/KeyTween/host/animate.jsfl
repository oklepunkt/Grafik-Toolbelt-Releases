/* Small ES3 JSON codec for Adobe hosts. No eval of package contents. */
var KTJSON = (function () {
    function quote(s) {
        return '"' + String(s).replace(/["\\\x00-\x1f\u2028\u2029]/g, function (c) {
            var n = c.charCodeAt(0).toString(16);
            if (c === '"') return '\\"';
            if (c === '\\') return '\\\\';
            return '\\u' + ('0000' + n).slice(-4);
        }) + '"';
    }
    function stringify(v) {
        var a = [], k, i;
        if (v === null || v === undefined) return 'null';
        if (typeof v === 'string') return quote(v);
        if (typeof v === 'number') { if (!isFinite(v)) throw Error('Non-finite JSON number'); return String(v); }
        if (typeof v === 'boolean') return String(v);
        if (Object.prototype.toString.call(v) === '[object Array]') {
            for (i = 0; i < v.length; i++) a.push(stringify(v[i]));
            return '[' + a.join(',') + ']';
        }
        for (k in v) if (Object.prototype.hasOwnProperty.call(v, k) && typeof v[k] !== 'function' && v[k] !== undefined) a.push(quote(k) + ':' + stringify(v[k]));
        return '{' + a.join(',') + '}';
    }
    function parse(s) {
        var p = 0, depth = 0;
        function fail() { throw Error('Invalid JSON at character ' + p); }
        function ws() { while (/\s/.test(s.charAt(p)) && p < s.length) p++; }
        function str() {
            var out = '', c, e, hex;
            if (s.charAt(p++) !== '"') fail();
            while (p < s.length) {
                c = s.charAt(p++);
                if (c === '"') return out;
                if (c === '\\') {
                    e = s.charAt(p++);
                    if (e === 'u') { hex = s.substr(p, 4); if (!/^[0-9a-fA-F]{4}$/.test(hex)) fail(); out += String.fromCharCode(parseInt(hex, 16)); p += 4; }
                    else if (e === '"' || e === '\\' || e === '/') out += e;
                    else if (e === 'b') out += '\b'; else if (e === 'f') out += '\f';
                    else if (e === 'n') out += '\n'; else if (e === 'r') out += '\r'; else if (e === 't') out += '\t'; else fail();
                } else { if (c.charCodeAt(0) < 32) fail(); out += c; }
            }
            fail();
        }
        function value() {
            ws(); if (++depth > 80) fail();
            var c = s.charAt(p), v, k, m;
            if (c === '"') v = str();
            else if (c === '[') {
                p++; v = []; ws();
                if (s.charAt(p) !== ']') { while (true) { v.push(value()); ws(); if (s.charAt(p) !== ',') break; p++; } }
                if (s.charAt(p++) !== ']') fail();
            } else if (c === '{') {
                p++; v = {}; ws();
                if (s.charAt(p) !== '}') { while (true) {
                    ws(); k = str(); if (k === '__proto__' || k === 'prototype' || k === 'constructor' || Object.prototype.hasOwnProperty.call(v, k)) fail();
                    ws(); if (s.charAt(p++) !== ':') fail(); v[k] = value(); ws(); if (s.charAt(p) !== ',') break; p++;
                } }
                if (s.charAt(p++) !== '}') fail();
            } else if (s.substr(p, 4) === 'true') { p += 4; v = true; }
            else if (s.substr(p, 5) === 'false') { p += 5; v = false; }
            else if (s.substr(p, 4) === 'null') { p += 4; v = null; }
            else { m = /^-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?/.exec(s.slice(p)); if (!m) fail(); p += m[0].length; v = Number(m[0]); if (!isFinite(v)) fail(); }
            depth--; return v;
        }
        var v = value(); ws(); if (p !== s.length) fail(); return v;
    }
    return { stringify: stringify, parse: parse };
}());
if (typeof module !== 'undefined') module.exports = KTJSON;

/* ES3-compatible conversion math, shared by Node tests and both host engines. */
var KTMath = (function () {
    var EPS = 1e-7, LINEAR = [{x:0,y:0},{x:1/3,y:1/3},{x:2/3,y:2/3},{x:1,y:1}];
    function arr(v) { return typeof v === 'number' ? [v] : v; }
    function lerp(a,b,t) { return a+(b-a)*t; }
    function point(a,b,t) { return {x:lerp(a.x,b.x,t),y:lerp(a.y,b.y,t)}; }
    function split(c,t) { var a=point(c[0],c[1],t), b=point(c[1],c[2],t), d=point(c[2],c[3],t), e=point(a,b,t), f=point(b,d,t), g=point(e,f,t); return [[c[0],a,e,g],[g,f,d,c[3]]]; }
    function at(c,t) { return split(c,t)[0][3]; }
    function solve(c,x) { var lo=0,hi=1,m,i; for(i=0;i<55;i++){m=(lo+hi)/2;if(at(c,m).x<x)lo=m;else hi=m;}return (lo+hi)/2; }
    function sliceCurve(c,x0,x1) {
        if(x1-x0<EPS) return LINEAR;
        var t0=solve(c,x0),t1=solve(c,x1), sub=split(c,t1)[0];
        if(t0>EPS) sub=split(sub,t0/t1)[1];
        var dx=sub[3].x-sub[0].x,dy=sub[3].y-sub[0].y,out=[],i;
        if(Math.abs(dy)<EPS) { if(Math.abs(sub[1].y-sub[0].y)>EPS || Math.abs(sub[2].y-sub[0].y)>EPS) throw Error('Zero-change endpoints with overshoot need a later sampled-tween build.'); return LINEAR; }
        for(i=0;i<4;i++)out.push({x:(sub[i].x-sub[0].x)/dx,y:(sub[i].y-sub[0].y)/dy});
        return out;
    }
    function frame(t,fps) { return Math.floor(t*fps+0.5+EPS); }
    function firstVisible(t,fps) { return Math.ceil(t*fps-EPS); }
    function matrix(p,s,r,a) { var rad=r*Math.PI/180,c=Math.cos(rad),n=Math.sin(rad),sx=s[0]/100,sy=s[1]/100;
        var m={a:c*sx,b:n*sx,c:-n*sy,d:c*sy,tx:0,ty:0}; m.tx=p[0]-m.a*a[0]-m.c*a[1];m.ty=p[1]-m.b*a[0]-m.d*a[1];return m; }
    function transform(m,p) { return [m.a*p[0]+m.c*p[1]+m.tx,m.b*p[0]+m.d*p[1]+m.ty]; }
    function curve(prop,left,right) {
        if(left.outType==='hold') return null;
        var a=arr(left.value),b=arr(right.value), dt=right.time-left.time, curves=[],i,d,out,inc,x1,x2,y1,y2;
        if(left.outType==='linear' && right.inType==='linear')return LINEAR;
        for(i=0;i<(prop.spatial?1:a.length);i++) {
            d=prop.spatial?Math.sqrt(Math.pow(b[0]-a[0],2)+Math.pow(b[1]-a[1],2)):b[i]-a[i];
            out=left.outEase[i]||left.outEase[0];inc=right.inEase[i]||right.inEase[0];
            x1=left.outType==='linear'?1/3:out.influence/100;
            x2=right.inType==='linear'?2/3:1-inc.influence/100;
            if(Math.abs(d)<EPS) { if((left.outType!=='linear'&&Math.abs(out.speed)>EPS)||(right.inType!=='linear'&&Math.abs(inc.speed)>EPS))throw Error('Zero-change endpoints with temporal overshoot are unsupported in this prototype.'); continue; }
            y1=left.outType==='linear'?x1:out.speed*dt*x1/d;
            y2=right.inType==='linear'?x2:1-inc.speed*dt*(1-x2)/d;
            if(x1>x2+EPS)throw Error('Overlapping temporal handles need a host-verified sampled-tween converter.');
            curves.push([{x:0,y:0},{x:x1,y:y1},{x:x2,y:y2},{x:1,y:1}]);
        }
        if(!curves.length)return LINEAR;
        for(i=1;i<curves.length;i++)for(d=1;d<3;d++)if(Math.abs(curves[i][d].x-curves[0][d].x)>EPS || Math.abs(curves[i][d].y-curves[0][d].y)>EPS)throw Error('Different easing per axis needs sampled native tweens (not enabled yet).');
        return curves[0];
    }
    function segment(prop,t) { var k=prop.keys,i;for(i=0;i<k.length-1;i++)if(t>=k[i].time-EPS&&t<k[i+1].time-EPS)return i;return -1; }
    function evaluate(prop,t) {
        var k=prop.keys,i=segment(prop,t),a,b,c,u,v=[],j;
        if(!k.length)return prop.value;
        if(i<0)return t<k[0].time?k[0].value:k[k.length-1].value;
        a=arr(k[i].value);b=arr(k[i+1].value);c=curve(prop,k[i],k[i+1]);
        u=c?at(c,solve(c,(t-k[i].time)/(k[i+1].time-k[i].time))).y:0;
        for(j=0;j<a.length;j++)v.push(lerp(a[j],b[j],u));
        return typeof k[i].value==='number'?v[0]:v;
    }
    function spanCurve(prop,t0,t1) {
        var i=segment(prop,(t0+t1)/2),k=prop.keys,c;
        if(i<0)return LINEAR;
        c=curve(prop,k[i],k[i+1]); if(!c)return LINEAR;
        return sliceCurve(c,(t0-k[i].time)/(k[i+1].time-k[i].time),(t1-k[i].time)/(k[i+1].time-k[i].time));
    }
    function pose(props,t) { var p=evaluate(props.position,t),s=evaluate(props.scale,t),r=evaluate(props.rotation,t),a=evaluate(props.anchor,t),o=evaluate(props.opacity,t);
        return {position:p,scale:s,rotation:r,anchor:a,opacity:o,matrix:matrix(p,s,r,a)}; }
    function compose(outer,inner) {return {a:outer.a*inner.a+outer.c*inner.b,b:outer.b*inner.a+outer.d*inner.b,c:outer.a*inner.c+outer.c*inner.d,d:outer.b*inner.c+outer.d*inner.d,tx:outer.a*inner.tx+outer.c*inner.ty+outer.tx,ty:outer.b*inner.tx+outer.d*inner.ty+outer.ty};}
    function inverse(m) {var q=m.a*m.d-m.b*m.c;if(!isFinite(q)||Math.abs(q)<1e-8)throw Error('Artwork transform is not invertible.');return {a:m.d/q,b:-m.b/q,c:-m.c/q,d:m.a/q,tx:(m.c*m.ty-m.d*m.tx)/q,ty:(m.b*m.tx-m.a*m.ty)/q};}
    return {inverse:inverse,compose:compose,EPS:EPS,LINEAR:LINEAR,arr:arr,frame:frame,firstVisible:firstVisible,matrix:matrix,transform:transform,curve:curve,evaluate:evaluate,spanCurve:spanCurve,pose:pose,at:at,solve:solve,sliceCurve:sliceCurve};
}());
if (typeof module !== 'undefined') module.exports = KTMath;

/* Typed vector geometry and a self-contained SVG interchange, never raster content. */
var KTVector = (function () {
    function need(ok,message){if(!ok)throw Error('Vector artwork: '+message);}
    function finite(n){return typeof n==='number'&&isFinite(n)&&Math.abs(n)<=10000000;}
    function pair(p){return p&&p.length===2&&finite(p[0])&&finite(p[1]);}
    function identity(){return {a:1,b:0,c:0,d:1,tx:0,ty:0};}
    function path(v,inside,outside,closed){var z=[],i;for(i=0;i<v.length;i++)z.push([0,0]);return {vertices:v,inTangents:inside||z,outTangents:outside||z,closed:!!closed};}
    function reverse(p){var v=[],a=[],b=[],i;for(i=p.vertices.length-1;i>=0;i--){v.push(p.vertices[i]);a.push(p.outTangents[i]);b.push(p.inTangents[i]);}return path(v,a,b,p.closed);}
    function transformed(p,m){if(p.operation==='merge'){var operands=[],oi;for(oi=0;oi<p.paths.length;oi++)operands.push(transformed(p.paths[oi],m));return {operation:'merge',mode:p.mode,paths:operands};}var v=[],a=[],b=[],i,q;for(i=0;i<p.vertices.length;i++){q=p.vertices[i];v.push([m.a*q[0]+m.c*q[1]+m.tx,m.b*q[0]+m.d*q[1]+m.ty]);q=p.inTangents[i];a.push([m.a*q[0]+m.c*q[1],m.b*q[0]+m.d*q[1]]);q=p.outTangents[i];b.push([m.a*q[0]+m.c*q[1],m.b*q[0]+m.d*q[1]]);}return path(v,a,b,p.closed);}
    function rectangle(size,pos,r){var x=pos[0],y=pos[1],w=size[0]/2,h=size[1]/2,k=.5522847498307936;r=Math.min(Math.max(0,r),w,h);if(!r)return path([[x-w,y-h],[x+w,y-h],[x+w,y+h],[x-w,y+h]],null,null,true);
        return path([[x-w+r,y-h],[x+w-r,y-h],[x+w,y-h+r],[x+w,y+h-r],[x+w-r,y+h],[x-w+r,y+h],[x-w,y+h-r],[x-w,y-h+r]],[[ -k*r,0],[0,0],[0,-k*r],[0,0],[k*r,0],[0,0],[0,k*r],[0,0]],[[0,0],[k*r,0],[0,0],[0,k*r],[0,0],[-k*r,0],[0,0],[0,-k*r]],true);}
    function ellipse(size,pos){var x=pos[0],y=pos[1],w=size[0]/2,h=size[1]/2,k=.5522847498307936;return path([[x,y-h],[x+w,y],[x,y+h],[x-w,y]],[[-k*w,0],[0,-k*h],[k*w,0],[0,k*h]],[[k*w,0],[0,k*h],[-k*w,0],[0,-k*h]],true);}
    function star(count,outer,inner,pos,rotation,isStar){need(count===Math.floor(count)&&count>=3&&count<=1000,'fractional or invalid polystar point count.');var n=isStar?count*2:count,v=[],i,a,r;for(i=0;i<n;i++){a=(rotation-90+i*360/n)*Math.PI/180;r=isStar&&i%2?inner:outer;v.push([pos[0]+Math.cos(a)*r,pos[1]+Math.sin(a)*r]);}return path(v,null,null,true);}
    function validate(root){var nodes=0,paths=0,points=0,paints=0;
        function unit(n){return finite(n)&&n>=0&&n<=1;}
        function color(c){return c&&c.length===3&&unit(c[0])&&unit(c[1])&&unit(c[2]);}
        function checkPath(p,depth){need(depth<=16,'path operations are nested too deeply.');var j;if(p&&p.operation){need(p.operation==='merge'&&p.mode>=1&&p.mode<=5&&p.mode===Math.floor(p.mode)&&p.paths&&p.paths.length>0&&p.paths.length<=4000,'invalid Merge Paths operation.');for(j=0;j<p.paths.length;j++)checkPath(p.paths[j],depth+1);return;}need(p&&p.vertices&&p.vertices.length>=2&&typeof p.closed==='boolean','invalid path vertices.');need(p.inTangents&&p.outTangents&&p.vertices.length===p.inTangents.length&&p.vertices.length===p.outTangents.length,'path tangent count differs.');need(++paths<=4000,'too many contours.');for(j=0;j<p.vertices.length;j++){need(++points<=100000,'too many points.');need(pair(p.vertices[j])&&pair(p.inTangents[j])&&pair(p.outTangents[j]),'non-finite vertex or tangent.');}}
        function walk(n,depth){need(n&&++nodes<=4096&&depth<=16,'too many or deeply nested groups.');var i,j,p,m,fields;
            if(n.kind==='group'){m=n.matrix;need(m,'missing group matrix.');fields=['a','b','c','d','tx','ty'];for(i=0;i<fields.length;i++)need(finite(m[fields[i]]),'invalid group matrix '+fields[i]+'.');need(Math.abs(m.a*m.d-m.b*m.c)>1e-8,'collapsed group transform.');need(unit(n.opacity),'invalid group opacity.');need(n.children&&n.children.length<=4096,'invalid group children.');for(i=0;i<n.children.length;i++)walk(n.children[i],depth+1);}
            else {need(n.kind==='paint','unknown vector node.');paints++;need(n.paths&&n.paths.length>0,'paint needs paths.');need(n.fill||n.stroke,'path has no paint.');for(i=0;i<n.paths.length;i++)checkPath(n.paths[i],0);
                if(n.fill)need(color(n.fill.color)&&unit(n.fill.opacity)&&/^(nonzero|evenodd)$/.test(n.fill.rule),'invalid fill color, alpha or winding rule.');
                if(n.stroke){p=n.stroke;need(color(p.color)&&unit(p.opacity)&&finite(p.width)&&p.width>0&&/^(butt|round|square)$/.test(p.cap)&&/^(miter|round|bevel)$/.test(p.join)&&finite(p.miter)&&p.miter>=1,'invalid stroke.');need(p.dashes&&p.dashes.length<=6&&finite(p.offset),'invalid dashes.');for(j=0;j<p.dashes.length;j++)need(finite(p.dashes[j])&&p.dashes[j]>=0,'invalid dash length.');}
            }
        }walk(root,0);need(paths>0,'no painted vector paths.');return {nodes:nodes,paths:paths,points:points,paints:paints};}
    function svg(artwork){validate(artwork.vector);var o=artwork.origin,s=artwork.size;need(pair(o)&&pair(s)&&s[0]>0&&s[1]>0,'invalid SVG viewport.');
        function num(v){return String(Math.round(v*1000000)/1000000);}
        function rgb(c){return 'rgb('+Math.round(c[0]*255)+','+Math.round(c[1]*255)+','+Math.round(c[2]*255)+')';}
        function data(p){need(!p.operation,'path operations must be converted before SVG output.');var d='M'+num(p.vertices[0][0])+' '+num(p.vertices[0][1]),n=p.vertices.length,i,j,a,b,c,e;for(i=0;i<(p.closed?n:n-1);i++){j=(i+1)%n;a=p.vertices[i];e=p.vertices[j];b=p.outTangents[i];c=p.inTangents[j];if(b[0]===0&&b[1]===0&&c[0]===0&&c[1]===0)d+='L'+num(e[0])+' '+num(e[1]);else d+='C'+num(a[0]+b[0])+' '+num(a[1]+b[1])+' '+num(e[0]+c[0])+' '+num(e[1]+c[1])+' '+num(e[0])+' '+num(e[1]);}if(p.closed)d+='Z';return d;}
        function walk(n){var i,d='',m=n.matrix,f=n.fill,t=n.stroke;if(n.kind==='group'){d='<g opacity="'+num(n.opacity)+'" transform="matrix('+[num(m.a),num(m.b),num(m.c),num(m.d),num(m.tx),num(m.ty)].join(' ')+')">';for(i=0;i<n.children.length;i++)d+=walk(n.children[i]);return d+'</g>';}
            for(i=0;i<n.paths.length;i++)d+=data(n.paths[i]);d='<path d="'+d+'" fill="'+(f?rgb(f.color):'none')+'"';if(f)d+=' fill-opacity="'+num(f.opacity)+'" fill-rule="'+f.rule+'"';if(t){d+=' stroke="'+rgb(t.color)+'" stroke-opacity="'+num(t.opacity)+'" stroke-width="'+num(t.width)+'" stroke-linecap="'+t.cap+'" stroke-linejoin="'+t.join+'" stroke-miterlimit="'+num(t.miter)+'"';if(t.dashes.length)d+=' stroke-dasharray="'+t.dashes.join(' ')+'" stroke-dashoffset="'+num(t.offset)+'"';}return d+'/>';}
        return '<svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="'+num(s[0])+'px" height="'+num(s[1])+'px" viewBox="'+[num(o[0]),num(o[1]),num(s[0]),num(s[1])].join(' ')+'">'+walk(artwork.vector)+'</svg>\n';}
    return {identity:identity,path:path,reverse:reverse,transformed:transformed,rectangle:rectangle,ellipse:ellipse,star:star,validate:validate,svg:svg};
}());
if(typeof module!=='undefined')module.exports=KTVector;

var KTArtwork = (function () {
    var V=typeof module!=='undefined'?require('./vectors'):KTVector;
    function need(ok,msg){if(!ok)throw Error(msg);}
    function number(n){return typeof n==='number'&&isFinite(n);}
    function vector(v,n){if(!v||v.length!==n)return false;for(var i=0;i<n;i++)if(!number(v[i]))return false;return true;}
    function color(c){return vector(c,3)&&c[0]>=0&&c[0]<=1&&c[1]>=0&&c[1]<=1&&c[2]>=0&&c[2]<=1;}
    function validate(l){
        if(l&&l.type==='symbol'){var sym=l.artwork;need(sym&&sym.representation==='editable-symbol'&&sym['static']===false&&vector(sym.size,2)&&sym.size[0]>0&&sym.size[1]>0&&sym.size[0]<=8192&&sym.size[1]<=8192&&vector(sym.origin,2)&&sym.origin[0]===0&&sym.origin[1]===0&&number(sym.duration)&&sym.duration>0&&number(sym.fps),'Invalid nested symbol artwork.');return;}
        need(l&&l.artwork&&l.artwork['static']===true,'Static bitmap, text or vector artwork is required.');var a=l.artwork,s,t,m,i;
        need(vector(a.size,2)&&a.size[0]>0&&a.size[1]>0&&a.size[0]<=32768&&a.size[1]<=32768,'Invalid artwork dimensions.');
        if(l.type==='bitmap'){
            need(a.representation==='raster-artwork'&&l.asset&&/^assets\/([a-z0-9-]{8,80}-)?[a-f0-9]{64}\.(png|jpg|jpeg)$/.test(l.asset.path)&&/^[a-f0-9]{64}$/.test(l.asset.hash),'Invalid bitmap path or SHA-256.');
            if(l.asset.pixelSize){var px=l.asset.pixelSize;need(vector(px,2)&&px[0]>=1&&px[1]>=1&&px[0]<=32768&&px[1]<=32768&&px[0]===Math.floor(px[0])&&px[1]===Math.floor(px[1]),'Invalid processed bitmap dimensions.');}
            return;
        }
        need(vector(a.origin,2),'Native artwork needs its source origin.');need(!l.asset,'Native artwork must not carry a raster asset.');
        if(l.type==='shape'){
            need(a.representation==='editable-vector','Shape must be native vector artwork.');V.validate(a.vector);
            if(l.vectorAsset)need((/^vectors\/(artwork|[0-9]+-[a-f0-9]{64})\.svg$/.test(l.vectorAsset.path))&&/^[a-f0-9]{64}$/.test(l.vectorAsset.hash),'Invalid vector asset path or SHA-256.');
        }else if(l.type==='text'){
            need(a.representation==='editable-text','Text must remain editable.');t=a.text;need(t&&typeof t.content==='string'&&t.content.length>0&&t.content.length<=1000&&!/[\r\n\t]/.test(t.content),'Use single-line point text.');
            need(typeof t.font==='string'&&t.font.length>0&&t.font.length<=256&&typeof t.fontFamily==='string'&&t.fontFamily.length>0&&t.fontFamily.length<=256&&typeof t.fontStyle==='string'&&t.fontStyle.length<=128,'Invalid font description.');
            need(number(t.fontSize)&&t.fontSize>=1&&t.fontSize<=1000&&color(t.fill)&&typeof t.bold==='boolean'&&typeof t.italic==='boolean'&&/^(left|center|right)$/.test(t.alignment),'Invalid text styling.');
        }else throw Error('Each layer must contain a bitmap, single-style point text, or static vector artwork.');
    }
    return {validate:validate};
}());
if(typeof module!=='undefined')module.exports=KTArtwork;

var KTPlan = (function () {
    var M = typeof KTMath !== 'undefined' ? KTMath : require('./math');
    var Art=typeof KTArtwork!=='undefined'?KTArtwork:require('./artwork');
    var props=['position','scale','rotation','opacity','anchor'];
    function need(ok,msg) { if(!ok)throw Error(msg); }
    function number(v) { return typeof v==='number'&&isFinite(v); }
    function vector(v,n) { if(n===1)return number(v);if(!v||v.length!==n)return false;for(var i=0;i<n;i++)if(!number(v[i]))return false;return true; }
    function supportedScale(v){return v&&v[0]>0&&v[1]>0;}
    function validate(p,build,sourceOnly) {
        need(p&&p.schemaVersion===1,'Unsupported package schema.');
        need(p.build===build,'Build mismatch: reinstall and reopen both KeyTween panels.');
        if(!sourceOnly)need(typeof p.id==='string'&&/^[a-zA-Z0-9_-]{8,100}$/.test(p.id),'Invalid transfer ID.');
        need(p.target&&p.target.kind==='new-matching','This proof only creates New Matching Documents.');
        need(p.timeDomain==='composition-relative-seconds','Unsupported time domain.');
        var c=p.composition,l=p.layer,n,i,j,k,v,dim;
        need(c&&number(c.width)&&c.width>0&&c.width<=8192&&number(c.height)&&c.height>0&&c.height<=8192,'Invalid stage size.');
        need(c.fps===30,'Set the After Effects composition to 30 fps before transfer.');
        need(c.pixelAspect===1&&number(c.duration)&&c.duration>0&&c.duration*c.fps<=18000,'Square pixels and a maximum of 18,000 frames are required.');
        need(c.rangeStart===0&&c.rangeEnd===c.duration,'The prototype exports the full composition.');
        need(c.displayStart===0,'Nonzero display-start time awaits the time-domain host fixture.');
        if(!sourceOnly||l.type!=='bitmap')Art.validate(l);
        need(number(l.inPoint)&&number(l.outPoint)&&l.outPoint>l.inPoint,'Invalid layer visibility range.');
        for(i=0;i<props.length;i++) {
            n=props[i];v=l.properties[n];dim=(n==='rotation'||n==='opacity')?1:2;
            need(v&&vector(v.value,dim)&&v.keys&&v.keys.length<=2000&&!v.expression,'Invalid or expression-driven '+n+'.');
            need(n!=='anchor'||v.keys.length===0,'Animated anchors are not supported yet.');
            for(j=0;j<v.keys.length;j++) {
                k=v.keys[j];need(number(k.time)&&vector(k.value,dim),'Invalid '+n+' key.');
                need(j===0||k.time>v.keys[j-1].time,'Key times must increase.');
                need(Math.abs(k.time*c.fps-M.frame(k.time,c.fps))<1e-6,'Subframe keys require a later time-conversion build.');
                need(/^(linear|hold|bezier)$/.test(k.inType)&&/^(linear|hold|bezier)$/.test(k.outType),'Unknown interpolation.');
                need(k.inEase&&k.outEase&&k.inEase.length>0&&k.outEase.length>0,'Missing temporal ease.');
                var e=k.inEase.concat(k.outEase),ei;
                for(ei=0;ei<e.length;ei++)need(number(e[ei].speed)&&number(e[ei].influence)&&e[ei].influence>=0.1&&e[ei].influence<=100,'Invalid temporal ease.');
                need(!k.roving&&!k.autoBezier,'Roving and temporal auto-Bezier keys await host probes.');
                if(v.spatial)need(k.spatialLinear,'Curved spatial paths require sampled native tweens (not enabled).');
            }
        }
        if(sourceOnly){
            var scale=l.properties.scale;need(supportedScale(scale.value),'Negative/zero scale requires the extended-transform fixture.');
            for(i=0;i<scale.keys.length;i++)need(supportedScale(scale.keys[i].value),'Negative/zero scale requires the extended-transform fixture.');
            return p;
        }
        need(p.reference&&p.reference.length===Math.ceil(c.duration*c.fps-1e-7),'Missing full-frame AE references.');
        for(i=0;i<p.reference.length;i++) {
            v=p.reference[i];need(v.frame===i&&number(v.time)&&Math.abs(v.time-i/c.fps)<1e-7&&typeof v.visible==='boolean','Invalid reference frame.');
            if(v.visible){need(vector(v.position,2)&&vector(v.scale,2)&&number(v.rotation)&&number(v.opacity),'Invalid reference transform.');need(supportedScale(v.scale),'Negative/zero scale requires the extended-transform fixture.');}
        }
        return p;
    }
    function create(p,build) {
        validate(p,build);
        var c=p.composition,l=p.layer,fps=c.fps,total=p.reference.length;
        var first=Math.max(0,M.firstVisible(l.inPoint,fps)),end=Math.min(total,M.firstVisible(l.outPoint,fps));
        need(end>first,'The layer has no visible destination frames.');
        var set={},frames=[],i,j,k,n,f,keys,poses=[],spans=[],from,to,r,curves,properties=l.properties;
        var animated=false;for(i=0;i<props.length;i++)if(properties[props[i]].keys.length)animated=true;
        set[first]=true;if(animated)set[end-1]=true;
        for(i=0;i<props.length;i++) {
            keys=properties[props[i]].keys;
            for(j=0;j<keys.length;j++) {
                f=M.frame(keys[j].time,fps);
                if(f>=first&&f<end)set[f]=true;
                if(j>0&&keys[j-1].outType==='hold'&&f-1>=first&&f-1<end)set[f-1]=true;
            }
        }
        for(k in set)if(Object.prototype.hasOwnProperty.call(set,k))frames.push(Number(k));
        frames.sort(function(a,b){return a-b;});
        for(i=0;i<frames.length;i++)poses.push(M.pose(properties,frames[i]/fps));
        for(i=0;i<frames.length-1;i++) {
            from=frames[i];to=frames[i+1];r=poses[i+1].rotation-poses[i].rotation;
            curves={};for(j=0;j<4;j++){n=props[j];curves[n]=M.spanCurve(properties[n],from/fps,to/fps);}
            spans.push({from:from,to:to,kind:to-from>1?'classic-tween':'boundary-key',curves:curves,rotationDelta:r});
        }
        // Check analytic conversion against independently evaluated AE properties before host mutation.
        var ref,calc,error=0,d,maxRotationStep=0;
        for(i=first;i<end;i++) {
            ref=p.reference[i];calc=M.pose(properties,i/fps);
            for(j=0;j<2;j++) {error=Math.max(error,Math.abs(calc.position[j]-ref.position[j]));need(Math.abs(calc.scale[j]-ref.scale[j])<=0.01,'Scale easing conversion disagrees with AE at frame '+(i+1)+'.');}
            need(Math.abs(calc.rotation-ref.rotation)<=0.01&&Math.abs(calc.opacity-ref.opacity)<=0.01,'Easing conversion disagrees with AE at frame '+(i+1)+'.');
            if(i>first)maxRotationStep=Math.max(maxRotationStep,Math.abs(ref.rotation-p.reference[i-1].rotation));
        }
        need(error<=0.05,'Position easing conversion disagrees with AE; sampled native support is pending.');
        need(maxRotationStep<180,'Rotation changes 180° or more in one frame; unwrapped verification would be ambiguous.');
        return {build:build,totalFrames:total,first:first,end:end,frames:frames,poses:poses,spans:spans,representation:animated?'classic-tween':'held-frame',artwork:l.artwork.representation,sampling:animated?'original-keys-with-boundary-splits':'one-key-held-for-layer-duration',status:'host-verification-required'};
    }
    return {validate:function(p,build){return validate(p,build,false);},validateSource:function(p,build){return validate(p,build,true);},create:create};
}());
if(typeof module!=='undefined')module.exports=KTPlan;

var KTVerify = (function () {
    var M=typeof KTMath!=='undefined'?KTMath:require('./math');
    function compare(p,actual) {
        var max={position:0,scale:0,rotation:0,opacity:0,corners:0},failures=[],firstFailure=null,geometryPass=true,opacityPass=true,prevAngle=null,i,j,a,e,m,angle,sx,sy,pa,pe,d;
        function fail(f,kind,error) { if(kind==='opacity percentage points')opacityPass=false;else geometryPass=false; if(!firstFailure)firstFailure={frame:f+1,kind:kind,error:error};if(failures.length<30)failures.push({frame:f+1,kind:kind,error:error}); }
        if(actual.length!==p.reference.length)return {pass:false,status:'incomplete-readback',expected:p.reference.length,received:actual.length};
        var anchor=p.layer.properties.anchor.value,size=p.layer.artwork.size,origin=p.layer.artwork.origin||[0,0],points=[origin,[origin[0]+size[0],origin[1]],[origin[0],origin[1]+size[1]],[origin[0]+size[0],origin[1]+size[1]],anchor];
        for(i=0;i<actual.length;i++) {
            a=actual[i];e=p.reference[i];
            if(a.frame!==i||a.visible!==e.visible){fail(i,'timing/visibility',null);continue;}
            if(!e.visible)continue;
            m=a.matrix;
            if(!m||!isFinite(m.a+m.b+m.c+m.d+m.tx+m.ty)||typeof a.opacity!=='number'||!isFinite(a.opacity)){fail(i,'missing tween readback',null);continue;}
            pa=M.transform(m,anchor);d=Math.max(Math.abs(pa[0]-e.position[0]),Math.abs(pa[1]-e.position[1]));max.position=Math.max(max.position,d);if(d>0.5)fail(i,'position',d);
            sx=Math.sqrt(m.a*m.a+m.b*m.b)*100;sy=Math.sqrt(m.c*m.c+m.d*m.d)*100;
            d=Math.max(Math.abs(sx-e.scale[0]),Math.abs(sy-e.scale[1]));max.scale=Math.max(max.scale,d);if(d>0.1)fail(i,'scale percentage points',d);
            angle=Math.atan2(m.b,m.a)*180/Math.PI;
            if(prevAngle===null)angle+=360*Math.round((e.rotation-angle)/360);
            else angle+=360*Math.round((prevAngle-angle)/360);
            prevAngle=angle;d=Math.abs(angle-e.rotation);max.rotation=Math.max(max.rotation,d);if(d>0.1)fail(i,'unwrapped rotation degrees',d);
            d=Math.abs(a.opacity-e.opacity);max.opacity=Math.max(max.opacity,d);if(d>0.5)fail(i,'opacity percentage points',d);
            var expected=M.matrix(e.position,e.scale,e.rotation,anchor);
            for(j=0;j<points.length;j++){pa=M.transform(m,points[j]);pe=M.transform(expected,points[j]);d=Math.max(Math.abs(pa[0]-pe[0]),Math.abs(pa[1]-pe[1]));max.corners=Math.max(max.corners,d);if(d>0.5)fail(i,'artwork corner/anchor pixels',d);}
        }
        return {pass:failures.length===0,geometryPass:geometryPass,opacityPass:opacityPass,status:failures.length?'failed':'passed',frameCount:actual.length,maxErrors:max,firstFailure:firstFailure,failures:failures,tolerances:{position:0.5,scale:0.1,rotation:0.1,opacity:0.5,corners:0.5}};
    }
    return {compare:compare};
}());
if(typeof module!=='undefined')module.exports=KTVerify;

var KTTree=(function(){function flatten(items){var out=[];function walk(list,depth){if(depth>8)throw Error('Precomp nesting exceeds eight levels.');for(var i=0;i<list.length;i++){if(out.length>=200)throw Error('Transfer exceeds 200 nested layers.');var item=list[i];out.push(item);if(item.children)walk(item.children,depth+1);}}walk(items,0);return out;}return {flatten:flatten};}());
if(typeof module!=='undefined')module.exports=KTTree;

/* Batch envelope; every layer retains the existing transform/artwork contract. */
var KTBatchJSON=typeof KTJSON!=='undefined'?KTJSON:JSON;
var KTBatch=(function(){
 function validate(p,build){
  if(!p||p.schemaVersion!==2||p.build!==build||!p.items||!p.items.length||p.items.length>50||!(/^[a-z0-9-]+$/.test(p.sourceKey))||!(/^[a-z0-9-]+$/.test(p.id)))throw Error('Invalid batch envelope or build.');
  if(p.scope!=='selection'&&p.scope!=='composition')throw Error('Invalid batch scope.');
  var plans=[],total=0,count=0;
  function check(items,composition,depth){
   if(depth>8||!items||!items.length||items.length>50)throw Error('Invalid or too-deep nested composition.');var seen={},previous=0;
   for(var i=0;i<items.length;i++){var item=items[i];if(++count>200)throw Error('Transfer exceeds 200 nested layers.');
    if(!item.layer||!(/^[0-9]+$/.test(item.layer.id))||seen['$'+item.layer.id])throw Error('Duplicate or invalid source layer identity.');seen['$'+item.layer.id]=true;
    if(item.source.identity!==p.sourceKey||item.layer.stackingIndex<=previous)throw Error('Batch identity or stacking order differs.');previous=item.layer.stackingIndex;
    if(KTBatchJSON.stringify(item.composition)!==KTBatchJSON.stringify(composition))throw Error('Batch composition settings differ.');
    var plan=KTPlan.create(item,build);if(depth===0)plans.push(plan);total+=plan.totalFrames;
    if(item.layer.type==='symbol'){
     var a=item.layer.artwork,c=item.children&&item.children[0]&&item.children[0].composition;
     if(typeof item.layer.startTime!=='number'||!isFinite(item.layer.startTime)||Math.abs(item.layer.startTime*composition.fps-Math.round(item.layer.startTime*composition.fps))>1e-6||item.layer.inPoint<item.layer.startTime-1e-6||item.layer.outPoint>item.layer.startTime+a.duration+1e-6)throw Error('Invalid nested playback interval.');
     if(!c||c.width!==a.size[0]||c.height!==a.size[1]||c.duration!==a.duration||c.fps!==a.fps||c.fps!==composition.fps)throw Error('Nested symbol composition differs.');check(item.children,c,depth+1);
    }else if(item.children&&item.children.length)throw Error('Only symbols may contain child layers.');
   }
  }
  check(p.items,p.composition,0);
  if(total>90000)throw Error('Batch frame budget exceeded.');return plans;
 }
 return {validate:validate};
}());
if(typeof module!=='undefined'&&module.exports){var KTPlan=require('./plan');module.exports=KTBatch;}

/* Graphic timelines synchronize child animation to the parent's frame clock. */
var KTANPrecomps=(function(){
 function check(item,args){
  if(KTJSON.stringify(args.payload)!==KTJSON.stringify(item))throw Error('Nested item differs from prepared package.');
  if(item.layer.type==='bitmap'&&!FLfile.exists(FLfile.platformPathToURI(args.assetPath)))throw Error('Missing nested bitmap: '+item.layer.name);
  if(item.layer.type==='shape'&&!FLfile.exists(FLfile.platformPathToURI(args.vectorPath)))throw Error('Missing nested vector: '+item.layer.name);
  if(item.layer.type==='text')KTANArtwork.resolveFont(item.layer.artwork.text);
  if(item.children){if(!args.children||args.children.length!==item.children.length)throw Error('Nested asset count differs.');for(var i=0;i<item.children.length;i++)check(item.children[i],args.children[i]);}
 }
 function create(doc,pkg,args,folder,author){
  var name=folder+'/Precomp contents',lib=doc.library,t,i,li,child,result,reports=[];
  if(!lib.addNewItem('graphic',name))throw Error('Could not create precomp content symbol.');
  for(i=pkg.children.length-1;i>=0;i--){
   lib.editItem(name);t=doc.getTimeline();t.currentFrame=0;t.currentLayer=0;
   li=i===pkg.children.length-1?0:t.addNewLayer(pkg.children[i].layer.name,'normal',true);if(typeof li!=='number')li=t.currentLayer;
   t.currentLayer=li;t.setSelectedLayers(li,true);
   child=args.children[i];result=author({payload:child.payload,assetPath:child.assetPath,vectorPath:child.vectorPath,children:child.children,document:doc,parentSymbol:name,layerIndex:li,folder:folder+'/child-'+i,owner:args.owner?args.owner+'/'+pkg.children[i].layer.id:null});
   reports.unshift(result);
   if(result.status==='failed'||result.status==='needs-attention')throw Error('Inside '+pkg.layer.name+' → '+pkg.children[i].layer.name+': '+(result.error||'Native timeline verification needs attention.'));
  }
  // Keep the editable children separate from the structural clipping mask.
  lib.editItem(name);t=doc.getTimeline();var total=Math.round(pkg.layer.artwork.duration*pkg.layer.artwork.fps);
  for(i=0;i<t.layers.length;i++){t.currentLayer=i;var more=total-t.layers[i].frames.length;if(more>0)t.insertFrames(more,false,0);t.layers[i].locked=false;t.layers[i].layerType='normal';}
  var clip=folder+'/Precomp canvas clip';if(!lib.addNewItem('graphic',clip))throw Error('Could not create precomp clipping wrapper.');
  lib.editItem(clip);t=doc.getTimeline();t.currentLayer=0;t.currentFrame=0;
  t.layers[0].name='Precomp contents — edit this symbol';var deficit=total-t.layers[0].frames.length;if(deficit>0)t.insertFrames(deficit,false,0);
  lib.addItemToDocument({x:0,y:0},name);var instance=t.layers[0].frames[0].elements[0];instance.matrix={a:1,b:0,c:0,d:1,tx:0,ty:0};instance.symbolType='graphic';instance.loop='play once';instance.firstFrame=0;
  li=t.addNewLayer('Canvas clipping mask — keep locked','mask',true);if(typeof li!=='number')li=t.currentLayer;t.currentLayer=li;t.setSelectedLayers(li,true);
  deficit=total-t.layers[li].frames.length;if(deficit>0)t.insertFrames(deficit,false,0);
  var prior=doc.getCustomFill(),fill=doc.getCustomFill();fill.style='solid';fill.color='#000000';doc.setCustomFill(fill);
  try{doc.addNewRectangle({left:0,top:0,right:pkg.layer.artwork.size[0],bottom:pkg.layer.artwork.size[1]},0,false,true);}finally{doc.setCustomFill(prior);}
  var mask=t.layers[li];mask.layerType='mask';mask.locked=true;
  for(i=0;i<t.layers.length;i++)if(i!==li){t.layers[i].parentLayer=mask;t.layers[i].layerType='masked';t.layers[i].locked=true;}
  for(i=0;i<t.layers.length;i++)if(i!==li&&(t.layers[i].parentLayer!==mask||t.layers[i].layerType!=='masked'))throw Error('Animate did not retain precomp canvas clipping.');
  return {name:clip,contents:name,reports:reports,frames:total,clipping:'separate-locked-mask-wrapper'};
 }
 function sync(el,pkg,frame){var first=Math.round((frame/pkg.composition.fps-pkg.layer.startTime)*pkg.layer.artwork.fps);if(first<0||first>=Math.round(pkg.layer.artwork.duration*pkg.layer.artwork.fps))throw Error('Precomp frame is outside its source timeline.');el.symbolType='graphic';el.loop='play once';el.firstFrame=first;if(el.symbolType!=='graphic'||el.loop!=='play once'||el.firstFrame!==first)throw Error('Animate did not retain precomp playback timing.');return first;}
 return {create:create,check:check,sync:sync};
}());

/* Native content authoring inside a fresh wrapper symbol. No raster conversion APIs. */
var KTANArtwork = (function () {
    function matrix(m){return {a:m.a,b:m.b,c:m.c,d:m.d,tx:m.tx,ty:m.ty};}
    function finite(n){return typeof n==='number'&&isFinite(n);}
    function translation(x,y){return {a:1,b:0,c:0,d:1,tx:x,ty:y};}
    function hex(c){var s='#',i,h;for(i=0;i<3;i++){h=Math.round(c[i]*255).toString(16);s+=h.length<2?'0'+h:h;}return s;}
    function colorEqual(a,b){if(typeof a==='number')a='#'+('000000'+a.toString(16)).slice(-6);return String(a).toLowerCase()===String(b).toLowerCase();}
    function resolveFont(t){
        if(fl.isFontInstalled(t.font))return {face:t.font,bold:t.bold,italic:t.italic,source:'PostScript name'};
        if(/^(Regular|Roman|Normal|Book|Bold|Italic|Oblique|Bold Italic|Bold Oblique)$/i.test(t.fontStyle)&&fl.isFontInstalled(t.fontFamily))return {face:t.fontFamily,bold:t.bold||/bold/i.test(t.fontStyle),italic:t.italic||/italic|oblique/i.test(t.fontStyle),source:'family plus source style'};
        throw Error('Font unavailable in Animate: '+t.font+' ('+t.fontFamily+', '+t.fontStyle+'). Choose an installed font in AE; no substitute or bitmap will be used.');
    }
    function loadVector(doc,filename){
        if(!filename||!FLfile.exists(FLfile.platformPathToURI(filename)))throw Error('Package vector file is missing.');
        var before={},items=doc.library.items,i,j,roots=[],referenced={},stats={shapes:0,edges:0,groups:0,symbols:0},budget=0;
        for(i=0;i<items.length;i++)before[items[i].name]=true;
        doc.importFile(FLfile.platformPathToURI(filename),true,false,false);items=doc.library.items;
        function inspect(elements,depth,seen){var k,e,t,f,li,next,c;if(depth>32)throw Error('Imported vector hierarchy is too deep.');
            for(k=0;k<elements.length;k++){if(++budget>20000)throw Error('Imported vector hierarchy is too large.');e=elements[k];
                if(e.elementType==='shape'){
                    if(e.isGroup){stats.groups++;if(!e.members||!e.members.length)throw Error('Could not inspect vector group members.');inspect(e.members,depth+1,seen);}
                    else {if(!e.edges||!e.edges.length)throw Error('Imported shape contains no readable vector edges.');stats.shapes++;stats.edges+=e.edges.length;
                        if(e.contours)for(c=0;c<e.contours.length;c++)if(e.contours[c].fill&&e.contours[c].fill.style==='bitmap')throw Error('SVG importer produced a bitmap fill instead of vectors.');}
                }else if(e.elementType==='instance'&&e.instanceType==='symbol'&&e.libraryItem&&e.libraryItem.timeline){
                    li=e.libraryItem;referenced[li.name]=true;if(seen['$'+li.name])throw Error('Imported vector hierarchy contains a cycle.');next={};for(c in seen)if(seen.hasOwnProperty(c))next[c]=true;next['$'+li.name]=true;stats.symbols++;inspectTimeline(li.timeline,depth+1,next);
                }else throw Error('SVG importer did not preserve editable vector artwork: '+e.elementType+'/'+e.instanceType+'.');
            }
        }
        function inspectTimeline(t,depth,seen){var k,frames;for(k=0;k<t.layers.length;k++){frames=t.layers[k].frames;if(frames.length>1)throw Error('Animate imported SVG paths on separate frames. The static vector import requires a single frame; this importer preference needs correction before the static vector test can pass. The failed document is retained for diagnosis.');if(frames.length)inspect(frames[0].elements,depth,seen);}}
        for(i=0;i<items.length;i++)if(!before[items[i].name]){if(items[i].itemType==='bitmap')throw Error('SVG import generated a bitmap; vector transfer stopped.');if(items[i].timeline){var seen={};seen['$'+items[i].name]=true;inspectTimeline(items[i].timeline,0,seen);roots.push(items[i]);}}
        var candidates=[];for(i=0;i<roots.length;i++)if(!referenced[roots[i].name])candidates.push(roots[i]);
        if(candidates.length!==1||stats.shapes===0)throw Error('Expected one native vector symbol from the SVG importer.');
        stats={shapes:0,edges:0,groups:0,symbols:0};budget=0;var checked={};checked['$'+candidates[0].name]=true;inspectTimeline(candidates[0].timeline,0,checked);
        return {name:candidates[0].name,readback:stats};
    }
    function assetLocation(pkg,filename){return pkg.layer.asset&&pkg.layer.asset.placement?'placed:'+String(filename).replace(/[^\/]+$/,''):'package';}
    function create(doc,pkg,bitmapName,font,vectorInfo){
        var a=pkg.layer.artwork,anchor=pkg.layer.properties.anchor.value,offset=translation(-anchor[0],-anchor[1]),el,sourceMap,report={representation:a.representation,nativeContent:false,rasterized:false},warnings=[];
        if(pkg.layer.type==='bitmap'){
            doc.library.addItemToDocument({x:0,y:0},bitmapName);el=doc.getTimeline().layers[0].frames[0].elements[0];if(!el)throw Error('The bitmap did not appear inside its symbol.');
            var pixels=pkg.layer.asset.pixelSize||a.size,scale={a:a.size[0]/pixels[0],b:0,c:0,d:a.size[1]/pixels[1],tx:0,ty:0};
            if(pkg.layer.asset.pixelSize&&(typeof el.width!=='number'||typeof el.height!=='number'||Math.abs(el.width-pixels[0])>.1||Math.abs(el.height-pixels[1])>.1))throw Error('Imported bitmap pixel dimensions differ from the prepared image.');
            el.matrix=KTMath.compose(offset,scale);var actual=matrix(el.matrix);
            return {matrix:KTMath.compose(actual,KTMath.inverse(scale)),bitmapMatrix:actual,report:{representation:'raster-artwork',nativeContent:false,rasterized:false,sourceSize:a.size,pixelSize:pixels,pixelToSource:scale,processing:pkg.layer.asset.processing||{operation:'unchanged'}},warnings:warnings};
        }
        if(pkg.layer.type==='symbol'){
            doc.library.addItemToDocument({x:0,y:0},vectorInfo.name);el=doc.getTimeline().layers[0].frames[0].elements[0];
            if(!el||el.instanceType!=='symbol')throw Error('Precomp content symbol is missing.');el.matrix=offset;el.symbolType='graphic';el.loop='play once';el.firstFrame=0;
            var timeline=doc.getTimeline();if(vectorInfo.frames>1)timeline.insertFrames(vectorInfo.frames-1,false,0);
            return {matrix:matrix(el.matrix),report:{representation:'editable-symbol',nativeContent:true,rasterized:false,children:vectorInfo.reports.length,frames:vectorInfo.frames,clipping:vectorInfo.clipping,playback:'synchronized-graphic',layoutVerification:'visual-check-required'},warnings:['Child layers and native tweens remain editable inside the precomp symbol. Check nested playback and canvas clipping in Animate.']};
        }
        if(pkg.layer.type==='shape'){
            doc.library.addItemToDocument({x:0,y:0},vectorInfo.name);el=doc.getTimeline().layers[0].frames[0].elements[0];
            if(!el||el.elementType!=='instance'||el.instanceType!=='symbol')throw Error('The native vector symbol did not appear in its tween wrapper.');
            if(!finite(el.width)||!finite(el.height)||!finite(el.left)||!finite(el.top)||el.width<=0||el.height<=0)throw Error('Native vector bounds could not be measured.');
            report.nativeContent=true;report.vectorReadback=vectorInfo.readback;report.sourceGeometry=KTVector.validate(a.vector);report.nativeBounds={left:el.left,top:el.top,width:el.width,height:el.height};report.sourceBounds={origin:a.origin,size:a.size};
            report.boundsError=Math.max(Math.abs(el.width-a.size[0]),Math.abs(el.height-a.size[1]));report.boundsPass=report.boundsError<=0.5;report.layoutVerification='visual-check-required';
            sourceMap=KTMath.compose(translation(a.origin[0]-el.left,a.origin[1]-el.top),matrix(el.matrix));el.matrix=KTMath.compose(offset,sourceMap);
            warnings.push('Native vector types were checked. Compare curves, holes, strokes and overlapping fills visually. Imported bounds error: '+report.boundsError+' px.');
        }else{
            var t=a.text;doc.addNewText({left:0,top:0,right:Math.max(a.size[0]+40,100),bottom:Math.max(t.fontSize*2,40)},t.content);
            el=doc.getTimeline().layers[0].frames[0].elements[0];if(!el||el.elementType!=='text')throw Error('Animate did not create an editable text field.');
            el.textType='static';el.autoExpand=true;
            el.setTextAttr('face',font.face);el.setTextAttr('size',t.fontSize);el.setTextAttr('bold',font.bold);el.setTextAttr('italic',font.italic);el.setTextAttr('fillColor',hex(t.fill));el.setTextAttr('alignment',t.alignment);
            el.setTextAttr('letterSpacing',0);el.setTextAttr('leftMargin',0);el.setTextAttr('rightMargin',0);el.setTextAttr('indent',0);
            var content=el.getTextString(),face=el.getTextAttr('face'),size=el.getTextAttr('size');
            if(content!==t.content)throw Error('Animate text content readback differs from the source.');
            var expected={face:font.face,size:t.fontSize,bold:font.bold,italic:font.italic,fillColor:hex(t.fill),alignment:t.alignment};
            var actual={face:String(face),size:size,bold:el.getTextAttr('bold'),italic:el.getTextAttr('italic'),fillColor:el.getTextAttr('fillColor'),alignment:el.getTextAttr('alignment')},mismatches=[],attr;
            // Animate may canonicalize a PostScript font to its family name. Retain both values.
            for(attr in expected)if(expected.hasOwnProperty(attr)){
                var same=actual[attr]===expected[attr];
                if(attr==='face')same=String(face)===font.face||(String(face)===t.fontFamily&&/^(Regular|Roman|Normal|Book|Bold|Italic|Oblique|Bold Italic|Bold Oblique)$/i.test(t.fontStyle));
                if(attr==='fillColor')same=colorEqual(actual[attr],expected[attr]);
                if(attr==='size')same=finite(size)&&Math.abs(size-t.fontSize)<=.01;
                if(!same)mismatches.push(attr);
            }
            report.styleReadback={expected:expected,actual:actual,mismatches:mismatches,pass:mismatches.length===0,contentMatches:true};
            if(mismatches.length)warnings.push('Text style requires review: '+mismatches.join(', ')+'. Actual/requested attributes are recorded; native tween authoring continues.');
            var width=el.width,height=el.height;
            if(!finite(size)||!finite(width)||!finite(height)||!finite(el.left)||!finite(el.top)||width<=0||height<=0)throw Error('Animate text bounds or font size could not be measured.');
            // Keep font size and native glyph geometry: never stretch text to fake AE metrics.
            var targetLeft=a.origin[0];if(t.alignment==='center')targetLeft+=(a.size[0]-width)/2;else if(t.alignment==='right')targetLeft+=a.size[0]-width;
            var placement=translation(targetLeft-el.left,a.origin[1]-el.top);
            sourceMap=KTMath.compose(placement,matrix(el.matrix));el.matrix=KTMath.compose(offset,sourceMap);
            report.nativeContent=true;report.textType=el.textType;report.characterCount=content.length;report.fontRequested=t.font;report.fontApplied=face;report.fontResolution=font.source;report.fontSize=size;report.nativeBounds={width:width,height:height};report.sourceBounds={origin:a.origin,size:a.size};report.layoutVerification='visual-check-required';
            warnings.push('Text stays editable at its native font size. Check baseline, spacing and alignment visually; matching wrapper transforms do not prove identical typography.');
        }
        report.elementType=el.elementType;report.elementMatrix=matrix(el.matrix);
        return {matrix:KTMath.compose(matrix(el.matrix),KTMath.inverse(sourceMap)),report:report,warnings:warnings};
    }
    return {create:create,resolveFont:resolveFont,loadVector:loadVector,assetLocation:assetLocation};
}());

var KeyTweenAN = (function () {
    var BUILD='0.1.0-dev.20';
    function info() {return {build:BUILD,host:'Animate',version:fl.version,documents:fl.documents.length};}
    function read(path) {var text=FLfile.read(FLfile.platformPathToURI(path));if(text===null)throw Error('Could not read the transfer.');return KTJSON.parse(text);}
    function copyMatrix(m) {return {a:m.a,b:m.b,c:m.c,d:m.d,tx:m.tx,ty:m.ty};}
    // Map original bitmap pixels through its anchor-offset symbol and then onto the Stage.
    var compose=KTMath.compose;
    function oneBased(values) {var out=[],i;for(i=0;i<values.length;i++)out.push(values[i]+1);return out;}
    function importPackage(args) {
        var pkg=args.payload||read(args.manifest),plan=KTPlan.create(pkg,BUILD),assetPath=args.assetPath;
        if(pkg.layer.type==='bitmap'&&!FLfile.exists(FLfile.platformPathToURI(assetPath)))throw Error('Package bitmap is missing.');
        // A batch may supply its checked destination. Keep failed candidates open for inspection.
        var doc=null,result={build:BUILD,transferId:pkg.id,host:info(),artwork:pkg.layer.artwork.representation,motion:plan.representation,verification:{status:'not-run',pass:false},publish:'not-run',warnings:pkg.warnings||[]};
        result.progress={phase:'create-document',keysWritten:0,spansWritten:0,plannedSpans:plan.spans.length,frame:null};
        try {
            result.progress.phase='preflight-font';var font=null;if(pkg.layer.type==='text')font=KTANArtwork.resolveFont(pkg.layer.artwork.text);
            result.progress.phase='create-document';
            doc=args.document||fl.createDocument('htmlcanvas');if(!doc)throw Error('Animate could not create an HTML5 Canvas document.');
            if(!args.document){doc.width=pkg.composition.width;doc.height=pkg.composition.height;doc.frameRate=pkg.composition.fps;}
            var oldBackground=doc.backgroundColor;var bg=pkg.composition.background||[1,1,1],hex='#',h,bi;
            for(bi=0;bi<3;bi++){h=Math.round(bg[bi]*255).toString(16);hex+=h.length<2?'0'+h:h;}doc.backgroundColor=args.document?oldBackground:hex;
            result.progress.phase='import-artwork';
            var lib=doc.library,timeline=doc.getTimeline(),i,j,k,frame,el,bitmaps=[],folder=args.folder||'KeyTween/'+pkg.composition.name.replace(/[\\/:]/g,'_');
            lib.newFolder('KeyTween');lib.newFolder(folder);
            var bitmapName=args.bitmapName||null,symbolName=folder+'/'+pkg.layer.type+' artwork';
            if(pkg.layer.type==='bitmap'&&!bitmapName){
                var beforeNames={};for(i=0;i<lib.items.length;i++)beforeNames['$'+lib.items[i].name]=true;
                doc.importFile(FLfile.platformPathToURI(assetPath),true,false,false);
                for(i=0;i<lib.items.length;i++)if(lib.items[i].itemType==='bitmap'&&!beforeNames['$'+lib.items[i].name])bitmaps.push(lib.items[i]);
                if(bitmaps.length!==1)throw Error('Expected exactly one imported bitmap.');
                var bitmap=bitmaps[0];bitmap.allowSmoothing=true;bitmap.compressionType='lossless';
                lib.selectItem(bitmap.name);lib.moveToFolder(folder,bitmap.name,false);bitmapName=bitmap.name;
            }
            var vectorInfo=null;if(pkg.layer.type==='shape'){result.progress.phase='import-vector-library';var stageWidth=doc.width,stageHeight=doc.height,stageFPS=doc.frameRate;vectorInfo=KTANArtwork.loadVector(doc,args.vectorPath);doc.width=stageWidth;doc.height=stageHeight;doc.frameRate=stageFPS;}
            if(pkg.layer.type==='symbol'){result.progress.phase='nested-layers';vectorInfo=KTANPrecomps.create(doc,pkg,args,folder,importPackage);result.children=vectorInfo.reports;}
            if(!lib.addNewItem(pkg.layer.type==='symbol'?'graphic':'movie clip',symbolName))throw Error('Could not create the artwork wrapper symbol.');
            lib.editItem(symbolName);
            var content=KTANArtwork.create(doc,pkg,bitmapName,font,vectorInfo),anchor=pkg.layer.properties.anchor.value,artworkMatrix=content.matrix;
            result.artworkVerification=content.report;result.warnings=result.warnings.concat(content.warnings);
            result.anchor={source:anchor,symbolRegistration:[0,0],artworkMatrix:artworkMatrix,keyPivots:[]};
            if(Math.abs(artworkMatrix.tx+anchor[0])>0.1||Math.abs(artworkMatrix.ty+anchor[1])>0.1||Math.abs(artworkMatrix.a-1)>0.0001||Math.abs(artworkMatrix.d-1)>0.0001||Math.abs(artworkMatrix.b)>0.0001||Math.abs(artworkMatrix.c)>0.0001)throw Error('Animate did not retain artwork registration.');
            doc.exitEditMode();if(args.parentSymbol)lib.editItem(args.parentSymbol);timeline=doc.getTimeline();
            var layerIndex=typeof args.layerIndex==='number'?args.layerIndex:0;timeline.currentLayer=layerIndex;
            if(args.document)timeline.setSelectedLayers(layerIndex,true);
            timeline.layers[layerIndex].name=pkg.layer.name;
            var frameDeficit=plan.totalFrames-timeline.layers[layerIndex].frames.length;if(frameDeficit>0)timeline.insertFrames(frameDeficit,false,0);
            timeline.currentFrame=plan.first;
            if(plan.first>0)timeline.insertBlankKeyframe(plan.first);
            lib.addItemToDocument({x:0,y:0},symbolName);
            result.progress.phase='write-keys';
            for(i=0;i<plan.frames.length;i++) {
                k=plan.frames[i];result.progress.frame=k+1;timeline.currentFrame=k;
                if(i>0)timeline.insertKeyframe(k);
                frame=timeline.layers[layerIndex].frames[k];el=frame.elements[0];if(!el)throw Error('Missing instance at frame '+(k+1)+'.');
                var pose=plan.poses[i],outer=copyMatrix(pose.matrix);
                outer.tx=pose.position[0];outer.ty=pose.position[1];
                el.matrix=outer;
                if(pkg.layer.type==='symbol')KTANPrecomps.sync(el,pkg,k);
                el.setTransformationPoint({x:0,y:0});el.colorMode='alpha';el.colorAlphaPercent=plan.poses[i].opacity;
                el.setPersistentData('keytween.transfer','string',pkg.id);if(args.owner)el.setPersistentData('keytween.owner','string',args.owner);result.progress.keysWritten++;
            }
            if(plan.end<timeline.layers[layerIndex].frames.length)timeline.insertBlankKeyframe(plan.end);
            result.progress.phase='write-tweens';
            for(i=0;i<plan.spans.length;i++) {
                var span=plan.spans[i];result.progress.frame=span.from+1;frame=timeline.layers[layerIndex].frames[span.from];
                if(span.kind==='boundary-key'){frame.tweenType='none';result.progress.spansWritten++;continue;}
                timeline.currentFrame=span.from;timeline.setSelectedFrames(span.from,span.to,true);
                timeline.createMotionTween(span.from,span.to);
                frame=timeline.layers[layerIndex].frames[span.from];
                // Canvas fixes Scale to true; writing motionTweenScale throws in Animate 24.
                // Canvas also rejects rotation 'none'; 'auto' keeps an unchanged angle.
                frame.motionTweenOrientToPath=false;
                frame.motionTweenRotate='auto';
                if(span.rotationDelta>1e-7)frame.motionTweenRotate='clockwise';
                else if(span.rotationDelta< -1e-7)frame.motionTweenRotate='counter-clockwise';
                frame.motionTweenRotateTimes=Math.floor((Math.abs(span.rotationDelta)+1e-7)/360);
                frame.useSingleEaseCurve=false;frame.hasCustomEase=true;
                var easeNames=['position','scale','rotation','opacity'],en,ec;
                for(en=0;en<easeNames.length;en++){ec=span.curves[easeNames[en]];ec[0]={x:0,y:0};ec[ec.length-1]={x:1,y:1};}
                frame.setCustomEase('position',span.curves.position);frame.setCustomEase('scale',span.curves.scale);
                frame.setCustomEase('rotation',span.curves.rotation);frame.setCustomEase('color',span.curves.opacity);
                frame.hasCustomEase=true;
                if(frame.tweenType!=='motion'||frame.isMotionObject())throw Error('Unexpected tween representation. Expected classic native tween.');
                result.progress.spansWritten++;
            }
            timeline.currentFrame=plan.first;timeline.setSelectedFrames(plan.first,plan.first+1,true);doc.selectNone();
            result.progress.phase='read-timeline';result.progress.frame=null;
            var actualKeys=[],actualSpans=[],expectedNative=0,timelineOK=true,pivotsOK=true;
            var sourceKeys={},names=['position','scale','rotation','opacity'],n,propertyKeys,sourceFrames;
            for(i=0;i<names.length;i++){n=names[i];propertyKeys=pkg.layer.properties[n].keys;sourceFrames=[];for(j=0;j<propertyKeys.length;j++)sourceFrames.push(KTMath.frame(propertyKeys[j].time,pkg.composition.fps)+1);sourceKeys[n]=sourceFrames;}
            result.timeline={frameNumbering:'one-based Animate timeline',sourcePropertyKeys:sourceKeys,expectedVisibleKeys:oneBased(plan.frames),actualVisibleKeys:actualKeys,spans:actualSpans,totalFrames:timeline.layers[layerIndex].frames.length,firstVisible:plan.first+1,lastVisible:plan.end};
            for(i=0;i<plan.spans.length;i++) {
                span=plan.spans[i];frame=timeline.layers[layerIndex].frames[span.from];
                var nativeSpan=frame.tweenType==='motion'&&!frame.isMotionObject();
                actualSpans.push({from:span.from+1,to:span.to+1,startFrame:frame.startFrame+1,duration:frame.duration,tweenType:frame.tweenType,customEase:frame.hasCustomEase,singleEase:frame.useSingleEaseCurve,curves:span.kind==='classic-tween'?{position:frame.getCustomEase('position'),scale:frame.getCustomEase('scale'),rotation:frame.getCustomEase('rotation'),opacity:frame.getCustomEase('color')}:null});
                if(span.kind==='classic-tween'){expectedNative++;if(!nativeSpan||!frame.hasCustomEase||frame.useSingleEaseCurve)timelineOK=false;}
                else if(frame.tweenType!=='none')timelineOK=false;
                if(frame.startFrame!==span.from||frame.duration!==span.to-span.from)timelineOK=false;
            }
            var samples=[],nativeCount=0,modernCount=0,boundaryCount=0;
            for(i=0;i<plan.totalFrames;i++) {
                result.progress.frame=i+1;frame=timeline.layers[layerIndex].frames[i];
                var sample={frame:i,visible:frame.elements.length>0};
                if(sample.visible) {
                    el=frame.elements[0];var offset=i-frame.startFrame;
                    if(pkg.layer.type==='symbol'){sample.precomp={firstFrame:el.firstFrame,sourceFrame:el.firstFrame+offset,loop:el.loop,symbolType:el.symbolType};if(el.symbolType!=='graphic'||el.loop!=='play once'||el.firstFrame!==Math.round((frame.startFrame/pkg.composition.fps-pkg.layer.startTime)*pkg.layer.artwork.fps))timelineOK=false;}
                    if(offset>0&&frame.tweenType==='motion') {
                        var tween=frame.tweenObj;sample.rawTweenMatrix=copyMatrix(tween.getGeometricTransform(offset));
                        sample.spanStartMatrix=copyMatrix(el.matrix);
                        // Animate 24 returns the world-space DELTA from the span's first key.
                        // Compose on the left; applying the bitmap anchor first would lose that key.
                        sample.matrix=compose(sample.rawTweenMatrix,sample.spanStartMatrix);
                        sample.rawColor=tween.getColorTransform(offset);sample.opacity=sample.rawColor.colorAlphaPercent;
                        sample.readback='Tween delta composed with span-start element';
                    } else {sample.matrix=copyMatrix(el.matrix);sample.opacity=el.colorAlphaPercent;sample.readback='key/static element';}
                    sample.matrix=compose(sample.matrix,artworkMatrix);
                    if(i===frame.startFrame){
                        actualKeys.push(i+1);var pivot=el.getTransformationPoint();
                        result.anchor.keyPivots.push({frame:i+1,x:pivot.x,y:pivot.y});
                        if(!isFinite(pivot.x)||!isFinite(pivot.y)||Math.abs(pivot.x)>0.05||Math.abs(pivot.y)>0.05)pivotsOK=false;
                        if(frame.isMotionObject())modernCount++;else if(frame.tweenType==='motion')nativeCount++;else boundaryCount++;
                    }
                }
                samples.push(sample);
            }
            if(actualKeys.join(',')!==oneBased(plan.frames).join(',')||(args.document?timeline.layers[layerIndex].frames.length<plan.totalFrames:timeline.layers[layerIndex].frames.length!==plan.totalFrames)||nativeCount!==expectedNative||modernCount!==0)timelineOK=false;
            result.timeline.pass=timelineOK;result.anchor.pass=pivotsOK;
            result.verification=KTVerify.compare(pkg,samples);
            result.verification.timelinePass=timelineOK;result.verification.anchorPivotPass=pivotsOK;
            if(!timelineOK||!pivotsOK){result.verification.pass=false;result.verification.status='timeline-or-anchor-mismatch';}
            result.representation={classicTweenSpans:nativeCount,modernMotionSpans:modernCount,staticOrBoundaryKeys:boundaryCount,artwork:pkg.layer.artwork.representation,frameKeyFallback:false};
            if(nativeCount===0&&expectedNative>0){result.verification.pass=false;result.verification.status='no-native-tweens';}
            result.readback=samples;result.documentId=doc.id;result.documentType=doc.type;result.plan={first:plan.first,end:plan.end,totalFrames:plan.totalFrames,authoredKeys:plan.frames.length};
            timeline.currentFrame=Math.min(plan.first+30,plan.end-1);
            result.managed={symbolName:symbolName,bitmapName:bitmapName,artworkMatrix:artworkMatrix,bitmapMatrix:content.bitmapMatrix||null,anchor:anchor,size:pkg.layer.artwork.size,type:pkg.layer.type,assetHash:pkg.layer.asset?pkg.layer.asset.hash:null,assetLocation:KTANArtwork.assetLocation(pkg,args.assetPath)};
            result.progress.phase='save-document';result.progress.frame=null;
            if(!args.document){
            var saveURI=FLfile.platformPathToURI(args.outputPath);
            if(FLfile.exists(saveURI))throw Error('The test output already exists. A new attempt path is required.');
            if(!fl.saveDocument(doc,saveURI))throw Error('Could not save the generated test FLA.');
            }
            result.progress.phase='complete';result.saved=!args.document;result.authored=true;result.status='needs-attention';
            if(result.verification.pass)result.status='verified-transform-candidate';
            else if(result.verification.geometryPass&&timelineOK&&pivotsOK){
                result.status='imported-review-required';
                result.verification.status='opacity-readback-needs-review';
                result.warnings.push('Import completed. Geometry and timing pass; opacity readback exceeds the 0.5 percentage-point target. Animate 24 returned whole-percent Tween API values in the recorded proof. Rendering/publishing must resolve the remaining precision question; the tolerance has not been relaxed.');
            }
            if(pkg.layer.type!=='bitmap'&&result.verification.geometryPass&&timelineOK&&pivotsOK)result.status='imported-artwork-review';
            if(pkg.layer.type==='shape'&&!result.artworkVerification.boundsPass){result.status='needs-attention';result.verification.pass=false;result.verification.artworkBoundsPass=false;result.error='Native vectors imported, but their bounds differ from AE. Inspect the saved artwork and automatic report.';}
            result.warnings.push('Save/reopen, visual appearance, and browser publishing still need real-host checks. This result alone does not pass the complete milestone.');
            return result;
        } catch(e) {
            result.verification.measurementStatus=result.verification.status;result.verification.pass=false;result.verification.status='host-operation-failed';
            result.status='failed';result.error=String(e.message||e);result.line=e.line||null;
            result.recovery='No destination document was created.';if(doc)result.recovery='The new test document is left open for inspection. Existing documents were not modified.';if(args.document)result.recovery='Batch stopped. Inspect the destination and its pre-update recovery copy.';
            return result;
        }
    }
    function dispatch(action,args) {
        try {args=args||{};if(args.build&&args.build!==BUILD)throw Error('Animate host script build mismatch. Reopen the panel.');var data=null;if(action==='info')data=info();else if(action==='import'){args.recoveryOnly=false;data=args.batch?KTANBatch.run(args,importPackage,BUILD):importPackage(args);}else if(action==='prepare-import'){args.recoveryOnly=true;data=KTANBatch.run(args,importPackage,BUILD);}else if(action==='target')data=KTANBatch.target();if(action==='choose-folder'){var folder=fl.browseForFolderURL('Choose an empty KeyTween working folder');data={path:folder?FLfile.uriToPlatformPath(folder):null};}if(!data)throw Error('Unknown Animate action.');return KTJSON.stringify({ok:true,build:BUILD,data:data});}
        catch(e){return KTJSON.stringify({ok:false,build:BUILD,error:String(e.message||e),line:e.line||null});}
    }
    return {dispatch:dispatch};
}());
function KeyTweenANDispatch(action,argsJSON){return KeyTweenAN.dispatch(action,KTJSON.parse(argsJSON));}

/* Local batch destination binding and ownership-safe bitmap revision updates. */
var KTANBatch=(function(){
 var DATA='keytween.binding.v1';
 function binding(doc){if(!doc.documentHasData(DATA))return null;return KTJSON.parse(doc.getDataFromDocument(DATA));}
 function target(){var d=fl.getDocumentDOM();return d?{id:d.id,type:d.type,width:d.width,height:d.height,fps:d.frameRate}: {id:null};}
 function copy(v){return KTJSON.parse(KTJSON.stringify(v));}
 function selected(doc,index){var t=doc.getTimeline();t.currentLayer=index;t.setSelectedLayers(index,true);return t;}
 function ownerKey(source,layer){return source+':'+layer;}
 function owned(doc,source){
  var t=doc.getTimeline(),map={},i,j,k,f,e,owner,key,entry;
  for(i=0;i<t.layers.length;i++)for(j=0;j<t.layers[i].frames.length;j++){
   f=t.layers[i].frames[j];if(f.startFrame!==j)continue;
   for(k=0;k<f.elements.length;k++){
    e=f.elements[k];if(!e.getPersistentData)continue;owner=e.getPersistentData('keytween.owner');
    if(typeof owner!=='string'||owner.indexOf(source+':')!==0)continue;
    key=owner.slice(source.length+1);entry=map['$'+key];
    if(!entry)entry=map['$'+key]={layerIndex:i,elements:[],frames:[],owner:owner};
    if(entry.layerIndex!==i||f.elements.length!==1)throw Error('Conflicting or duplicated managed instances for AE layer '+key+'. Use a new file to inspect this transfer.');
    entry.elements.push(e);entry.frames.push(j);
   }
  }
  return map;
 }
 function writeBinding(doc,b){doc.addDataToDocument(DATA,'string',KTJSON.stringify(b));if(KTJSON.stringify(binding(doc))!==KTJSON.stringify(b))throw Error('Animate did not retain the source binding.');}
 function fresh(doc,p){doc.width=p.composition.width;doc.height=p.composition.height;doc.frameRate=p.composition.fps;var bg=p.composition.background||[1,1,1],hex='#',h,i;for(i=0;i<3;i++){h=Math.round(bg[i]*255).toString(16);hex+=h.length<2?'0'+h:h;}doc.backgroundColor=hex;}
 function stamp(doc){
  var parts=[doc.id,doc.width,doc.height,doc.frameRate,doc.backgroundColor,doc.pathURI||'',KTJSON.stringify(binding(doc))],t=doc.getTimeline(),i,j,k,f,e,lib=doc.library.items;
  for(i=0;i<lib.length;i++)parts.push(lib[i].name,lib[i].itemType);
  for(i=0;i<t.layers.length;i++){parts.push(t.layers[i].name,t.layers[i].frames.length);for(j=0;j<t.layers[i].frames.length;j++){f=t.layers[i].frames[j];if(f.startFrame!==j)continue;parts.push(j,f.tweenType,f.duration,f.hasCustomEase);for(k=0;k<f.elements.length;k++){e=f.elements[k];parts.push(e.elementType,e.libraryItem?e.libraryItem.name:'',KTJSON.stringify(e.matrix),e.colorAlphaPercent);}}}
  var s=parts.join('|'),h=0;for(i=0;i<s.length;i++)h=((h*31)+s.charCodeAt(i))|0;return String(h)+':'+s.length;
 }
 function empty(doc){var t=doc.getTimeline(),i,j;for(i=0;i<t.layers.length;i++){if(t.layers[i].frames.length>1)return false;for(j=0;j<t.layers[i].frames.length;j++)if(t.layers[i].frames[j].elements.length)return false;}return !doc.library.items.length;}
 function run(args,author,build){
  var p=KTJSON.parse(FLfile.read(FLfile.platformPathToURI(args.manifest))),plans=KTBatch.validate(p,build),doc=null,created=args.createNew&&args.mode!=='update',prior=null,registry=null,map=null;
  var result={build:build,transferId:p.id,host:{host:'Animate',version:fl.version},batch:true,mode:args.mode,layers:[],counts:{added:0,updated:0,unchanged:0},warnings:p.warnings||[],status:'failed',verification:{pass:false,status:'not-run'},saved:false,publish:'not-run',progress:{phase:'preflight'}};
  try{
   if(args.mode!=='pull'&&args.mode!=='update')throw Error('Invalid destination action.');
   if(args.items.length!==p.items.length)throw Error('Batch asset count differs.');
   var bitmapCache={},i,j,item,entry,old,action,actions=[],source=p.sourceKey,t,li,layerResult;
   if(!created){
    doc=fl.getDocumentDOM();if(!doc||doc.id!==args.targetId)throw Error('The Animate destination changed or closed while AE was exporting. Activate the intended document and try again.');
    if(doc.type!=='htmlcanvas'||doc.timelines.length!==1||doc.getTimeline().libraryItem!=null)throw Error('Use an HTML5 Canvas document at its main Scene timeline.');
    prior=binding(doc);if(prior&&prior.source!==source)throw Error('This document belongs to another AE composition. Pull into a new file.');
    if(args.mode==='update'&&!prior)throw Error('Pull this composition into the document first to establish its layer identities.');
    map=owned(doc,source);
   }
   registry=prior||{schema:1,source:source,layers:{}};
   for(i=0;i<p.items.length;i++){
    item=p.items[i];entry=map&&map['$'+item.layer.id];old=registry.layers['$'+item.layer.id];action='add';
    if(KTJSON.stringify(args.items[i].payload)!==KTJSON.stringify(item))throw Error('Batch item differs from prepared package.');
    if(item.layer.type==='bitmap'&&!FLfile.exists(FLfile.platformPathToURI(args.items[i].assetPath)))throw Error('Missing bitmap.');
    if(item.layer.type==='shape'&&!FLfile.exists(FLfile.platformPathToURI(args.items[i].vectorPath)))throw Error('Missing vector.');
    if(entry){
     if(!old)throw Error('Managed instance has no ownership record.');
     if(old.type!==item.layer.type)throw Error('Layer '+item.layer.name+' changed artwork type. Use a new file.');
     for(j=0;j<entry.elements.length;j++)if(!entry.elements[j].libraryItem||entry.elements[j].libraryItem.name!==old.symbolName)throw Error('Layer '+item.layer.name+' uses a changed Library symbol. Use a new file to preserve that edit.');
     action='keep';
     if(args.mode==='update'&&item.layer.type==='bitmap'&&(old.assetHash!==item.layer.asset.hash||(old.assetLocation||'package')!==KTANArtwork.assetLocation(item,args.items[i].assetPath))){
      if(KTJSON.stringify(old.size)!==KTJSON.stringify(item.layer.artwork.size)||KTJSON.stringify(old.anchor)!==KTJSON.stringify(item.layer.properties.anchor.value))throw Error('Bitmap dimensions or AE anchor changed for '+item.layer.name+'. Pull into a new file to test its new registration.');
      var wrapper=null;for(j=0;j<doc.library.items.length;j++)if(doc.library.items[j].name===old.symbolName)wrapper=doc.library.items[j];
      var wt=wrapper&&wrapper.timeline,inside=wt&&wt.layers.length===1&&wt.layers[0].frames.length===1&&wt.layers[0].frames[0].elements;
      if(!inside||inside.length!==1||!inside[0].libraryItem||inside[0].libraryItem.name!==old.bitmapName||KTJSON.stringify(inside[0].matrix)!==KTJSON.stringify(old.bitmapMatrix||old.artworkMatrix))throw Error('Bitmap wrapper was edited locally. Pull into a new file to preserve that edit.');
      action='update';
     }
    }
    if(action!=='keep')KTANPrecomps.check(item,args.items[i]);
    actions.push(action);
   }
   var changed=!!actions.join(',').replace(/keep,?/g,'').length;
   var resize=!created&&args.matchCanvas!==false&&(doc.width!==p.composition.width||doc.height!==p.composition.height),retime=!created&&Math.abs(doc.frameRate-p.composition.fps)>.00001;
   if(args.recoveryOnly){
    if(created)throw Error('New documents do not need a recovery phase.');
    result.progress.phase='recovery-copy';result.recoveryNeeded=changed||resize||retime;result.documentStamp=stamp(doc);result.documentId=doc.id;result.recoveryFile=args.recoveryPath;
    if(result.recoveryNeeded){
     var recoveryURI=FLfile.platformPathToURI(args.recoveryPath);if(FLfile.exists(recoveryURI))throw Error('Recovery filename already exists. Request a fresh transfer.');
     var originalPath=doc.pathURI,returned=doc.saveAsCopy(recoveryURI,false);
     result.recoveryChecks={returnType:typeof returned,returned:typeof returned==='undefined'?null:returned,fileExists:FLfile.exists(recoveryURI),sameDocument:fl.getDocumentDOM()&&fl.getDocumentDOM().id===doc.id,samePath:doc.pathURI===originalPath,sameContent:stamp(doc)===result.documentStamp};
     if(!result.recoveryChecks.fileExists||!result.recoveryChecks.sameDocument||!result.recoveryChecks.samePath||!result.recoveryChecks.sameContent)throw Error('Recovery copy failed its file/document checks. No layers were changed.');
    }
    result.status='recovery-prepared';return result;
   }
   if(created){doc=fl.createDocument('htmlcanvas');if(!doc)throw Error('Could not create Canvas document.');fresh(doc,p);}
   else if(changed||resize||retime){
    result.progress.phase='verify-recovery';var proof=args.recoveryProof;
    if(!proof||proof.transferId!==p.id||proof.documentId!==doc.id||proof.documentStamp!==stamp(doc)||proof.path!==args.recoveryPath||!proof.sha256||!FLfile.exists(FLfile.platformPathToURI(args.recoveryPath)))throw Error('Verified recovery copy is missing or the destination changed. No layers were changed; request a fresh transfer.');
    result.recoveryFile=args.recoveryPath;result.recoveryVerification=proof;result.recovery='Checked pre-update FLA copy retained. Original file is not auto-saved.';
    if(resize){doc.width=p.composition.width;doc.height=p.composition.height;}if(retime){var oldFPS=doc.frameRate;doc.frameRate=30;if(doc.frameRate!==30)throw Error('Animate did not retain 30 fps.');result.warnings.push('Canvas frame rate changed from '+oldFPS+' to 30 fps. Existing frame positions remain unchanged; their playback duration changes. The pre-transfer FLA copy retains the previous FPS.');}
   }
   if(created||actions.join(',').replace(/keep,?/g,'').length){doc.library.newFolder('KeyTween');doc.library.newFolder('KeyTween/'+p.id);}
   // Add in AE bottom-to-top order. Existing user layers stay in place.
   for(i=p.items.length-1;i>=0;i--){
    item=p.items[i];action=actions[i];result.progress={phase:action,layerId:item.layer.id,layerName:item.layer.name};
    if(action==='keep'){result.counts.unchanged++;result.layers.unshift({layerId:item.layer.id,name:item.layer.name,status:'unchanged',note:'Existing Animate content and tweens retained.'});continue;}
    t=doc.getTimeline();map=owned(doc,source);entry=map['$'+item.layer.id];
    var insertion=0,above=true,nearest=null;
    for(j=i+1;j<p.items.length;j++)if(map['$'+p.items[j].layer.id]){nearest=map['$'+p.items[j].layer.id];break;}
    if(nearest)insertion=nearest.layerIndex;
    else {for(j=i-1;j>=0;j--)if(map['$'+p.items[j].layer.id]){insertion=map['$'+p.items[j].layer.id].layerIndex;above=false;break;}}
    if(created&&i===p.items.length-1){li=0;selected(doc,0);}
    else {selected(doc,insertion);li=t.addNewLayer(item.layer.name,'normal',above);if(typeof li!=='number')li=t.currentLayer;}
    selected(doc,li);
    var layerArgs=copy(args.items[i]);layerArgs.document=doc;layerArgs.layerIndex=li;layerArgs.folder='KeyTween/'+p.id+'/'+item.layer.id;layerArgs.owner=ownerKey(source,action==='update'?'staging-'+item.layer.id:item.layer.id);layerArgs.build=build;
    if(item.layer.type==='bitmap')layerArgs.bitmapName=bitmapCache[item.layer.asset.hash]||null;
    layerResult=author(layerArgs);layerResult.layerId=item.layer.id;layerResult.name=item.layer.name;
    result.layers.unshift(layerResult);
    if(layerResult.status==='failed'||layerResult.status==='needs-attention')throw Error('Layer '+item.layer.name+': '+(layerResult.error||'Host verification needs attention.'));
    if(item.layer.type==='bitmap')bitmapCache[item.layer.asset.hash]=layerResult.managed.bitmapName;
    if(action==='update'){
     // Retarget only the original owned keys; old Library items and unrelated users remain intact.
     entry=owned(doc,source)['$'+item.layer.id];if(!entry)throw Error('Original owned layer disappeared during staging.');
     var newItem=null;for(j=0;j<doc.library.items.length;j++)if(doc.library.items[j].name===layerResult.managed.symbolName)newItem=doc.library.items[j];
     if(!newItem)throw Error('Updated Library wrapper is missing.');
     for(j=0;j<entry.elements.length;j++){
      var el=entry.elements[j],m=copy(el.matrix),pivot=el.getTransformationPoint(),alpha=el.colorAlphaPercent,colorMode=el.colorMode;
      el.libraryItem=newItem;el.matrix=m;el.setTransformationPoint(pivot);el.colorMode=colorMode;el.colorAlphaPercent=alpha;
      if(el.libraryItem.name!==newItem.name||KTJSON.stringify(el.matrix)!==KTJSON.stringify(m)||el.colorAlphaPercent!==alpha)throw Error('Bitmap replacement did not preserve instance transforms.');
     }
     t=doc.getTimeline();t.deleteLayer(li);result.counts.updated++;layerResult.status='image-updated';layerResult.verification={status:'existing-tweens-preserved',pass:false,sourceMotionComparison:'not-run: Animate edits retained'};delete layerResult.readback;delete layerResult.timeline;delete layerResult.anchor;
    }else result.counts.added++;
    registry.layers['$'+item.layer.id]=layerResult.managed;writeBinding(doc,registry);
   }
   if(created||result.counts.added||result.counts.updated)writeBinding(doc,registry);result.documentId=doc.id;result.documentType=doc.type;
   if(created){result.progress.phase='save-document';var out=FLfile.platformPathToURI(args.outputPath);if(FLfile.exists(out)||!fl.saveDocument(doc,out))throw Error('Could not save the new batch FLA.');result.saved=true;}
   result.completed=true;result.status='batch-complete-review';result.verification={pass:false,status:'per-layer-results',note:'Review each layer and native text/vector appearance. Existing tweens are preserved on update.'};result.progress.phase='complete';
   if(!created)result.warnings.push('Changes are in the open document. Save when satisfied. Existing text/shape edits and animation were retained; Update Layers only refreshes bitmap bytes and adds missing layers.');
   return result;
  }catch(e){result.error=String(e.message||e);result.line=e.line||null;result.status=(result.counts.added||result.counts.updated)?'partial':'failed';result.verification={pass:false,status:'batch-stopped'};result.recovery=result.recovery||'Candidate document retained for inspection. No automatic retry or rollback.';return result;}
 }
 return {run:run,target:target};
}());
