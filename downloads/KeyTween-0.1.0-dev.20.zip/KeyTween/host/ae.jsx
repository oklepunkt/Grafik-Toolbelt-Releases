/* Small ES3 JSON codec for Adobe hosts. No eval of package contents. */
var KTJSON = (function () {
    function quote(s) {
        return '"' + String(s).replace(/["\\\x00-\x1f\u2028\u2029]/g, function (c) {
            var n = c.charCodeAt(0).toString(16);
            if (c === '"') return '\\"';
            if (c === '\\') return '\\\\';
            return '\\u' + ('0000' + n).slice(-4);
        }) + '"';
    }
    function stringify(v) {
        var a = [], k, i;
        if (v === null || v === undefined) return 'null';
        if (typeof v === 'string') return quote(v);
        if (typeof v === 'number') { if (!isFinite(v)) throw Error('Non-finite JSON number'); return String(v); }
        if (typeof v === 'boolean') return String(v);
        if (Object.prototype.toString.call(v) === '[object Array]') {
            for (i = 0; i < v.length; i++) a.push(stringify(v[i]));
            return '[' + a.join(',') + ']';
        }
        for (k in v) if (Object.prototype.hasOwnProperty.call(v, k) && typeof v[k] !== 'function' && v[k] !== undefined) a.push(quote(k) + ':' + stringify(v[k]));
        return '{' + a.join(',') + '}';
    }
    function parse(s) {
        var p = 0, depth = 0;
        function fail() { throw Error('Invalid JSON at character ' + p); }
        function ws() { while (/\s/.test(s.charAt(p)) && p < s.length) p++; }
        function str() {
            var out = '', c, e, hex;
            if (s.charAt(p++) !== '"') fail();
            while (p < s.length) {
                c = s.charAt(p++);
                if (c === '"') return out;
                if (c === '\\') {
                    e = s.charAt(p++);
                    if (e === 'u') { hex = s.substr(p, 4); if (!/^[0-9a-fA-F]{4}$/.test(hex)) fail(); out += String.fromCharCode(parseInt(hex, 16)); p += 4; }
                    else if (e === '"' || e === '\\' || e === '/') out += e;
                    else if (e === 'b') out += '\b'; else if (e === 'f') out += '\f';
                    else if (e === 'n') out += '\n'; else if (e === 'r') out += '\r'; else if (e === 't') out += '\t'; else fail();
                } else { if (c.charCodeAt(0) < 32) fail(); out += c; }
            }
            fail();
        }
        function value() {
            ws(); if (++depth > 80) fail();
            var c = s.charAt(p), v, k, m;
            if (c === '"') v = str();
            else if (c === '[') {
                p++; v = []; ws();
                if (s.charAt(p) !== ']') { while (true) { v.push(value()); ws(); if (s.charAt(p) !== ',') break; p++; } }
                if (s.charAt(p++) !== ']') fail();
            } else if (c === '{') {
                p++; v = {}; ws();
                if (s.charAt(p) !== '}') { while (true) {
                    ws(); k = str(); if (k === '__proto__' || k === 'prototype' || k === 'constructor' || Object.prototype.hasOwnProperty.call(v, k)) fail();
                    ws(); if (s.charAt(p++) !== ':') fail(); v[k] = value(); ws(); if (s.charAt(p) !== ',') break; p++;
                } }
                if (s.charAt(p++) !== '}') fail();
            } else if (s.substr(p, 4) === 'true') { p += 4; v = true; }
            else if (s.substr(p, 5) === 'false') { p += 5; v = false; }
            else if (s.substr(p, 4) === 'null') { p += 4; v = null; }
            else { m = /^-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?/.exec(s.slice(p)); if (!m) fail(); p += m[0].length; v = Number(m[0]); if (!isFinite(v)) fail(); }
            depth--; return v;
        }
        var v = value(); ws(); if (p !== s.length) fail(); return v;
    }
    return { stringify: stringify, parse: parse };
}());
if (typeof module !== 'undefined') module.exports = KTJSON;

/* ES3-compatible conversion math, shared by Node tests and both host engines. */
var KTMath = (function () {
    var EPS = 1e-7, LINEAR = [{x:0,y:0},{x:1/3,y:1/3},{x:2/3,y:2/3},{x:1,y:1}];
    function arr(v) { return typeof v === 'number' ? [v] : v; }
    function lerp(a,b,t) { return a+(b-a)*t; }
    function point(a,b,t) { return {x:lerp(a.x,b.x,t),y:lerp(a.y,b.y,t)}; }
    function split(c,t) { var a=point(c[0],c[1],t), b=point(c[1],c[2],t), d=point(c[2],c[3],t), e=point(a,b,t), f=point(b,d,t), g=point(e,f,t); return [[c[0],a,e,g],[g,f,d,c[3]]]; }
    function at(c,t) { return split(c,t)[0][3]; }
    function solve(c,x) { var lo=0,hi=1,m,i; for(i=0;i<55;i++){m=(lo+hi)/2;if(at(c,m).x<x)lo=m;else hi=m;}return (lo+hi)/2; }
    function sliceCurve(c,x0,x1) {
        if(x1-x0<EPS) return LINEAR;
        var t0=solve(c,x0),t1=solve(c,x1), sub=split(c,t1)[0];
        if(t0>EPS) sub=split(sub,t0/t1)[1];
        var dx=sub[3].x-sub[0].x,dy=sub[3].y-sub[0].y,out=[],i;
        if(Math.abs(dy)<EPS) { if(Math.abs(sub[1].y-sub[0].y)>EPS || Math.abs(sub[2].y-sub[0].y)>EPS) throw Error('Zero-change endpoints with overshoot need a later sampled-tween build.'); return LINEAR; }
        for(i=0;i<4;i++)out.push({x:(sub[i].x-sub[0].x)/dx,y:(sub[i].y-sub[0].y)/dy});
        return out;
    }
    function frame(t,fps) { return Math.floor(t*fps+0.5+EPS); }
    function firstVisible(t,fps) { return Math.ceil(t*fps-EPS); }
    function matrix(p,s,r,a) { var rad=r*Math.PI/180,c=Math.cos(rad),n=Math.sin(rad),sx=s[0]/100,sy=s[1]/100;
        var m={a:c*sx,b:n*sx,c:-n*sy,d:c*sy,tx:0,ty:0}; m.tx=p[0]-m.a*a[0]-m.c*a[1];m.ty=p[1]-m.b*a[0]-m.d*a[1];return m; }
    function transform(m,p) { return [m.a*p[0]+m.c*p[1]+m.tx,m.b*p[0]+m.d*p[1]+m.ty]; }
    function curve(prop,left,right) {
        if(left.outType==='hold') return null;
        var a=arr(left.value),b=arr(right.value), dt=right.time-left.time, curves=[],i,d,out,inc,x1,x2,y1,y2;
        if(left.outType==='linear' && right.inType==='linear')return LINEAR;
        for(i=0;i<(prop.spatial?1:a.length);i++) {
            d=prop.spatial?Math.sqrt(Math.pow(b[0]-a[0],2)+Math.pow(b[1]-a[1],2)):b[i]-a[i];
            out=left.outEase[i]||left.outEase[0];inc=right.inEase[i]||right.inEase[0];
            x1=left.outType==='linear'?1/3:out.influence/100;
            x2=right.inType==='linear'?2/3:1-inc.influence/100;
            if(Math.abs(d)<EPS) { if((left.outType!=='linear'&&Math.abs(out.speed)>EPS)||(right.inType!=='linear'&&Math.abs(inc.speed)>EPS))throw Error('Zero-change endpoints with temporal overshoot are unsupported in this prototype.'); continue; }
            y1=left.outType==='linear'?x1:out.speed*dt*x1/d;
            y2=right.inType==='linear'?x2:1-inc.speed*dt*(1-x2)/d;
            if(x1>x2+EPS)throw Error('Overlapping temporal handles need a host-verified sampled-tween converter.');
            curves.push([{x:0,y:0},{x:x1,y:y1},{x:x2,y:y2},{x:1,y:1}]);
        }
        if(!curves.length)return LINEAR;
        for(i=1;i<curves.length;i++)for(d=1;d<3;d++)if(Math.abs(curves[i][d].x-curves[0][d].x)>EPS || Math.abs(curves[i][d].y-curves[0][d].y)>EPS)throw Error('Different easing per axis needs sampled native tweens (not enabled yet).');
        return curves[0];
    }
    function segment(prop,t) { var k=prop.keys,i;for(i=0;i<k.length-1;i++)if(t>=k[i].time-EPS&&t<k[i+1].time-EPS)return i;return -1; }
    function evaluate(prop,t) {
        var k=prop.keys,i=segment(prop,t),a,b,c,u,v=[],j;
        if(!k.length)return prop.value;
        if(i<0)return t<k[0].time?k[0].value:k[k.length-1].value;
        a=arr(k[i].value);b=arr(k[i+1].value);c=curve(prop,k[i],k[i+1]);
        u=c?at(c,solve(c,(t-k[i].time)/(k[i+1].time-k[i].time))).y:0;
        for(j=0;j<a.length;j++)v.push(lerp(a[j],b[j],u));
        return typeof k[i].value==='number'?v[0]:v;
    }
    function spanCurve(prop,t0,t1) {
        var i=segment(prop,(t0+t1)/2),k=prop.keys,c;
        if(i<0)return LINEAR;
        c=curve(prop,k[i],k[i+1]); if(!c)return LINEAR;
        return sliceCurve(c,(t0-k[i].time)/(k[i+1].time-k[i].time),(t1-k[i].time)/(k[i+1].time-k[i].time));
    }
    function pose(props,t) { var p=evaluate(props.position,t),s=evaluate(props.scale,t),r=evaluate(props.rotation,t),a=evaluate(props.anchor,t),o=evaluate(props.opacity,t);
        return {position:p,scale:s,rotation:r,anchor:a,opacity:o,matrix:matrix(p,s,r,a)}; }
    function compose(outer,inner) {return {a:outer.a*inner.a+outer.c*inner.b,b:outer.b*inner.a+outer.d*inner.b,c:outer.a*inner.c+outer.c*inner.d,d:outer.b*inner.c+outer.d*inner.d,tx:outer.a*inner.tx+outer.c*inner.ty+outer.tx,ty:outer.b*inner.tx+outer.d*inner.ty+outer.ty};}
    function inverse(m) {var q=m.a*m.d-m.b*m.c;if(!isFinite(q)||Math.abs(q)<1e-8)throw Error('Artwork transform is not invertible.');return {a:m.d/q,b:-m.b/q,c:-m.c/q,d:m.a/q,tx:(m.c*m.ty-m.d*m.tx)/q,ty:(m.b*m.tx-m.a*m.ty)/q};}
    return {inverse:inverse,compose:compose,EPS:EPS,LINEAR:LINEAR,arr:arr,frame:frame,firstVisible:firstVisible,matrix:matrix,transform:transform,curve:curve,evaluate:evaluate,spanCurve:spanCurve,pose:pose,at:at,solve:solve,sliceCurve:sliceCurve};
}());
if (typeof module !== 'undefined') module.exports = KTMath;

/* Typed vector geometry and a self-contained SVG interchange, never raster content. */
var KTVector = (function () {
    function need(ok,message){if(!ok)throw Error('Vector artwork: '+message);}
    function finite(n){return typeof n==='number'&&isFinite(n)&&Math.abs(n)<=10000000;}
    function pair(p){return p&&p.length===2&&finite(p[0])&&finite(p[1]);}
    function identity(){return {a:1,b:0,c:0,d:1,tx:0,ty:0};}
    function path(v,inside,outside,closed){var z=[],i;for(i=0;i<v.length;i++)z.push([0,0]);return {vertices:v,inTangents:inside||z,outTangents:outside||z,closed:!!closed};}
    function reverse(p){var v=[],a=[],b=[],i;for(i=p.vertices.length-1;i>=0;i--){v.push(p.vertices[i]);a.push(p.outTangents[i]);b.push(p.inTangents[i]);}return path(v,a,b,p.closed);}
    function transformed(p,m){if(p.operation==='merge'){var operands=[],oi;for(oi=0;oi<p.paths.length;oi++)operands.push(transformed(p.paths[oi],m));return {operation:'merge',mode:p.mode,paths:operands};}var v=[],a=[],b=[],i,q;for(i=0;i<p.vertices.length;i++){q=p.vertices[i];v.push([m.a*q[0]+m.c*q[1]+m.tx,m.b*q[0]+m.d*q[1]+m.ty]);q=p.inTangents[i];a.push([m.a*q[0]+m.c*q[1],m.b*q[0]+m.d*q[1]]);q=p.outTangents[i];b.push([m.a*q[0]+m.c*q[1],m.b*q[0]+m.d*q[1]]);}return path(v,a,b,p.closed);}
    function rectangle(size,pos,r){var x=pos[0],y=pos[1],w=size[0]/2,h=size[1]/2,k=.5522847498307936;r=Math.min(Math.max(0,r),w,h);if(!r)return path([[x-w,y-h],[x+w,y-h],[x+w,y+h],[x-w,y+h]],null,null,true);
        return path([[x-w+r,y-h],[x+w-r,y-h],[x+w,y-h+r],[x+w,y+h-r],[x+w-r,y+h],[x-w+r,y+h],[x-w,y+h-r],[x-w,y-h+r]],[[ -k*r,0],[0,0],[0,-k*r],[0,0],[k*r,0],[0,0],[0,k*r],[0,0]],[[0,0],[k*r,0],[0,0],[0,k*r],[0,0],[-k*r,0],[0,0],[0,-k*r]],true);}
    function ellipse(size,pos){var x=pos[0],y=pos[1],w=size[0]/2,h=size[1]/2,k=.5522847498307936;return path([[x,y-h],[x+w,y],[x,y+h],[x-w,y]],[[-k*w,0],[0,-k*h],[k*w,0],[0,k*h]],[[k*w,0],[0,k*h],[-k*w,0],[0,-k*h]],true);}
    function star(count,outer,inner,pos,rotation,isStar){need(count===Math.floor(count)&&count>=3&&count<=1000,'fractional or invalid polystar point count.');var n=isStar?count*2:count,v=[],i,a,r;for(i=0;i<n;i++){a=(rotation-90+i*360/n)*Math.PI/180;r=isStar&&i%2?inner:outer;v.push([pos[0]+Math.cos(a)*r,pos[1]+Math.sin(a)*r]);}return path(v,null,null,true);}
    function validate(root){var nodes=0,paths=0,points=0,paints=0;
        function unit(n){return finite(n)&&n>=0&&n<=1;}
        function color(c){return c&&c.length===3&&unit(c[0])&&unit(c[1])&&unit(c[2]);}
        function checkPath(p,depth){need(depth<=16,'path operations are nested too deeply.');var j;if(p&&p.operation){need(p.operation==='merge'&&p.mode>=1&&p.mode<=5&&p.mode===Math.floor(p.mode)&&p.paths&&p.paths.length>0&&p.paths.length<=4000,'invalid Merge Paths operation.');for(j=0;j<p.paths.length;j++)checkPath(p.paths[j],depth+1);return;}need(p&&p.vertices&&p.vertices.length>=2&&typeof p.closed==='boolean','invalid path vertices.');need(p.inTangents&&p.outTangents&&p.vertices.length===p.inTangents.length&&p.vertices.length===p.outTangents.length,'path tangent count differs.');need(++paths<=4000,'too many contours.');for(j=0;j<p.vertices.length;j++){need(++points<=100000,'too many points.');need(pair(p.vertices[j])&&pair(p.inTangents[j])&&pair(p.outTangents[j]),'non-finite vertex or tangent.');}}
        function walk(n,depth){need(n&&++nodes<=4096&&depth<=16,'too many or deeply nested groups.');var i,j,p,m,fields;
            if(n.kind==='group'){m=n.matrix;need(m,'missing group matrix.');fields=['a','b','c','d','tx','ty'];for(i=0;i<fields.length;i++)need(finite(m[fields[i]]),'invalid group matrix '+fields[i]+'.');need(Math.abs(m.a*m.d-m.b*m.c)>1e-8,'collapsed group transform.');need(unit(n.opacity),'invalid group opacity.');need(n.children&&n.children.length<=4096,'invalid group children.');for(i=0;i<n.children.length;i++)walk(n.children[i],depth+1);}
            else {need(n.kind==='paint','unknown vector node.');paints++;need(n.paths&&n.paths.length>0,'paint needs paths.');need(n.fill||n.stroke,'path has no paint.');for(i=0;i<n.paths.length;i++)checkPath(n.paths[i],0);
                if(n.fill)need(color(n.fill.color)&&unit(n.fill.opacity)&&/^(nonzero|evenodd)$/.test(n.fill.rule),'invalid fill color, alpha or winding rule.');
                if(n.stroke){p=n.stroke;need(color(p.color)&&unit(p.opacity)&&finite(p.width)&&p.width>0&&/^(butt|round|square)$/.test(p.cap)&&/^(miter|round|bevel)$/.test(p.join)&&finite(p.miter)&&p.miter>=1,'invalid stroke.');need(p.dashes&&p.dashes.length<=6&&finite(p.offset),'invalid dashes.');for(j=0;j<p.dashes.length;j++)need(finite(p.dashes[j])&&p.dashes[j]>=0,'invalid dash length.');}
            }
        }walk(root,0);need(paths>0,'no painted vector paths.');return {nodes:nodes,paths:paths,points:points,paints:paints};}
    function svg(artwork){validate(artwork.vector);var o=artwork.origin,s=artwork.size;need(pair(o)&&pair(s)&&s[0]>0&&s[1]>0,'invalid SVG viewport.');
        function num(v){return String(Math.round(v*1000000)/1000000);}
        function rgb(c){return 'rgb('+Math.round(c[0]*255)+','+Math.round(c[1]*255)+','+Math.round(c[2]*255)+')';}
        function data(p){need(!p.operation,'path operations must be converted before SVG output.');var d='M'+num(p.vertices[0][0])+' '+num(p.vertices[0][1]),n=p.vertices.length,i,j,a,b,c,e;for(i=0;i<(p.closed?n:n-1);i++){j=(i+1)%n;a=p.vertices[i];e=p.vertices[j];b=p.outTangents[i];c=p.inTangents[j];if(b[0]===0&&b[1]===0&&c[0]===0&&c[1]===0)d+='L'+num(e[0])+' '+num(e[1]);else d+='C'+num(a[0]+b[0])+' '+num(a[1]+b[1])+' '+num(e[0]+c[0])+' '+num(e[1]+c[1])+' '+num(e[0])+' '+num(e[1]);}if(p.closed)d+='Z';return d;}
        function walk(n){var i,d='',m=n.matrix,f=n.fill,t=n.stroke;if(n.kind==='group'){d='<g opacity="'+num(n.opacity)+'" transform="matrix('+[num(m.a),num(m.b),num(m.c),num(m.d),num(m.tx),num(m.ty)].join(' ')+')">';for(i=0;i<n.children.length;i++)d+=walk(n.children[i]);return d+'</g>';}
            for(i=0;i<n.paths.length;i++)d+=data(n.paths[i]);d='<path d="'+d+'" fill="'+(f?rgb(f.color):'none')+'"';if(f)d+=' fill-opacity="'+num(f.opacity)+'" fill-rule="'+f.rule+'"';if(t){d+=' stroke="'+rgb(t.color)+'" stroke-opacity="'+num(t.opacity)+'" stroke-width="'+num(t.width)+'" stroke-linecap="'+t.cap+'" stroke-linejoin="'+t.join+'" stroke-miterlimit="'+num(t.miter)+'"';if(t.dashes.length)d+=' stroke-dasharray="'+t.dashes.join(' ')+'" stroke-dashoffset="'+num(t.offset)+'"';}return d+'/>';}
        return '<svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="'+num(s[0])+'px" height="'+num(s[1])+'px" viewBox="'+[num(o[0]),num(o[1]),num(s[0]),num(s[1])].join(' ')+'">'+walk(artwork.vector)+'</svg>\n';}
    return {identity:identity,path:path,reverse:reverse,transformed:transformed,rectangle:rectangle,ellipse:ellipse,star:star,validate:validate,svg:svg};
}());
if(typeof module!=='undefined')module.exports=KTVector;

var KTArtwork = (function () {
    var V=typeof module!=='undefined'?require('./vectors'):KTVector;
    function need(ok,msg){if(!ok)throw Error(msg);}
    function number(n){return typeof n==='number'&&isFinite(n);}
    function vector(v,n){if(!v||v.length!==n)return false;for(var i=0;i<n;i++)if(!number(v[i]))return false;return true;}
    function color(c){return vector(c,3)&&c[0]>=0&&c[0]<=1&&c[1]>=0&&c[1]<=1&&c[2]>=0&&c[2]<=1;}
    function validate(l){
        if(l&&l.type==='symbol'){var sym=l.artwork;need(sym&&sym.representation==='editable-symbol'&&sym['static']===false&&vector(sym.size,2)&&sym.size[0]>0&&sym.size[1]>0&&sym.size[0]<=8192&&sym.size[1]<=8192&&vector(sym.origin,2)&&sym.origin[0]===0&&sym.origin[1]===0&&number(sym.duration)&&sym.duration>0&&number(sym.fps),'Invalid nested symbol artwork.');return;}
        need(l&&l.artwork&&l.artwork['static']===true,'Static bitmap, text or vector artwork is required.');var a=l.artwork,s,t,m,i;
        need(vector(a.size,2)&&a.size[0]>0&&a.size[1]>0&&a.size[0]<=32768&&a.size[1]<=32768,'Invalid artwork dimensions.');
        if(l.type==='bitmap'){
            need(a.representation==='raster-artwork'&&l.asset&&/^assets\/([a-z0-9-]{8,80}-)?[a-f0-9]{64}\.(png|jpg|jpeg)$/.test(l.asset.path)&&/^[a-f0-9]{64}$/.test(l.asset.hash),'Invalid bitmap path or SHA-256.');
            if(l.asset.pixelSize){var px=l.asset.pixelSize;need(vector(px,2)&&px[0]>=1&&px[1]>=1&&px[0]<=32768&&px[1]<=32768&&px[0]===Math.floor(px[0])&&px[1]===Math.floor(px[1]),'Invalid processed bitmap dimensions.');}
            return;
        }
        need(vector(a.origin,2),'Native artwork needs its source origin.');need(!l.asset,'Native artwork must not carry a raster asset.');
        if(l.type==='shape'){
            need(a.representation==='editable-vector','Shape must be native vector artwork.');V.validate(a.vector);
            if(l.vectorAsset)need((/^vectors\/(artwork|[0-9]+-[a-f0-9]{64})\.svg$/.test(l.vectorAsset.path))&&/^[a-f0-9]{64}$/.test(l.vectorAsset.hash),'Invalid vector asset path or SHA-256.');
        }else if(l.type==='text'){
            need(a.representation==='editable-text','Text must remain editable.');t=a.text;need(t&&typeof t.content==='string'&&t.content.length>0&&t.content.length<=1000&&!/[\r\n\t]/.test(t.content),'Use single-line point text.');
            need(typeof t.font==='string'&&t.font.length>0&&t.font.length<=256&&typeof t.fontFamily==='string'&&t.fontFamily.length>0&&t.fontFamily.length<=256&&typeof t.fontStyle==='string'&&t.fontStyle.length<=128,'Invalid font description.');
            need(number(t.fontSize)&&t.fontSize>=1&&t.fontSize<=1000&&color(t.fill)&&typeof t.bold==='boolean'&&typeof t.italic==='boolean'&&/^(left|center|right)$/.test(t.alignment),'Invalid text styling.');
        }else throw Error('Each layer must contain a bitmap, single-style point text, or static vector artwork.');
    }
    return {validate:validate};
}());
if(typeof module!=='undefined')module.exports=KTArtwork;

var KTPlan = (function () {
    var M = typeof KTMath !== 'undefined' ? KTMath : require('./math');
    var Art=typeof KTArtwork!=='undefined'?KTArtwork:require('./artwork');
    var props=['position','scale','rotation','opacity','anchor'];
    function need(ok,msg) { if(!ok)throw Error(msg); }
    function number(v) { return typeof v==='number'&&isFinite(v); }
    function vector(v,n) { if(n===1)return number(v);if(!v||v.length!==n)return false;for(var i=0;i<n;i++)if(!number(v[i]))return false;return true; }
    function supportedScale(v){return v&&v[0]>0&&v[1]>0;}
    function validate(p,build,sourceOnly) {
        need(p&&p.schemaVersion===1,'Unsupported package schema.');
        need(p.build===build,'Build mismatch: reinstall and reopen both KeyTween panels.');
        if(!sourceOnly)need(typeof p.id==='string'&&/^[a-zA-Z0-9_-]{8,100}$/.test(p.id),'Invalid transfer ID.');
        need(p.target&&p.target.kind==='new-matching','This proof only creates New Matching Documents.');
        need(p.timeDomain==='composition-relative-seconds','Unsupported time domain.');
        var c=p.composition,l=p.layer,n,i,j,k,v,dim;
        need(c&&number(c.width)&&c.width>0&&c.width<=8192&&number(c.height)&&c.height>0&&c.height<=8192,'Invalid stage size.');
        need(c.fps===30,'Set the After Effects composition to 30 fps before transfer.');
        need(c.pixelAspect===1&&number(c.duration)&&c.duration>0&&c.duration*c.fps<=18000,'Square pixels and a maximum of 18,000 frames are required.');
        need(c.rangeStart===0&&c.rangeEnd===c.duration,'The prototype exports the full composition.');
        need(c.displayStart===0,'Nonzero display-start time awaits the time-domain host fixture.');
        if(!sourceOnly||l.type!=='bitmap')Art.validate(l);
        need(number(l.inPoint)&&number(l.outPoint)&&l.outPoint>l.inPoint,'Invalid layer visibility range.');
        for(i=0;i<props.length;i++) {
            n=props[i];v=l.properties[n];dim=(n==='rotation'||n==='opacity')?1:2;
            need(v&&vector(v.value,dim)&&v.keys&&v.keys.length<=2000&&!v.expression,'Invalid or expression-driven '+n+'.');
            need(n!=='anchor'||v.keys.length===0,'Animated anchors are not supported yet.');
            for(j=0;j<v.keys.length;j++) {
                k=v.keys[j];need(number(k.time)&&vector(k.value,dim),'Invalid '+n+' key.');
                need(j===0||k.time>v.keys[j-1].time,'Key times must increase.');
                need(Math.abs(k.time*c.fps-M.frame(k.time,c.fps))<1e-6,'Subframe keys require a later time-conversion build.');
                need(/^(linear|hold|bezier)$/.test(k.inType)&&/^(linear|hold|bezier)$/.test(k.outType),'Unknown interpolation.');
                need(k.inEase&&k.outEase&&k.inEase.length>0&&k.outEase.length>0,'Missing temporal ease.');
                var e=k.inEase.concat(k.outEase),ei;
                for(ei=0;ei<e.length;ei++)need(number(e[ei].speed)&&number(e[ei].influence)&&e[ei].influence>=0.1&&e[ei].influence<=100,'Invalid temporal ease.');
                need(!k.roving&&!k.autoBezier,'Roving and temporal auto-Bezier keys await host probes.');
                if(v.spatial)need(k.spatialLinear,'Curved spatial paths require sampled native tweens (not enabled).');
            }
        }
        if(sourceOnly){
            var scale=l.properties.scale;need(supportedScale(scale.value),'Negative/zero scale requires the extended-transform fixture.');
            for(i=0;i<scale.keys.length;i++)need(supportedScale(scale.keys[i].value),'Negative/zero scale requires the extended-transform fixture.');
            return p;
        }
        need(p.reference&&p.reference.length===Math.ceil(c.duration*c.fps-1e-7),'Missing full-frame AE references.');
        for(i=0;i<p.reference.length;i++) {
            v=p.reference[i];need(v.frame===i&&number(v.time)&&Math.abs(v.time-i/c.fps)<1e-7&&typeof v.visible==='boolean','Invalid reference frame.');
            if(v.visible){need(vector(v.position,2)&&vector(v.scale,2)&&number(v.rotation)&&number(v.opacity),'Invalid reference transform.');need(supportedScale(v.scale),'Negative/zero scale requires the extended-transform fixture.');}
        }
        return p;
    }
    function create(p,build) {
        validate(p,build);
        var c=p.composition,l=p.layer,fps=c.fps,total=p.reference.length;
        var first=Math.max(0,M.firstVisible(l.inPoint,fps)),end=Math.min(total,M.firstVisible(l.outPoint,fps));
        need(end>first,'The layer has no visible destination frames.');
        var set={},frames=[],i,j,k,n,f,keys,poses=[],spans=[],from,to,r,curves,properties=l.properties;
        var animated=false;for(i=0;i<props.length;i++)if(properties[props[i]].keys.length)animated=true;
        set[first]=true;if(animated)set[end-1]=true;
        for(i=0;i<props.length;i++) {
            keys=properties[props[i]].keys;
            for(j=0;j<keys.length;j++) {
                f=M.frame(keys[j].time,fps);
                if(f>=first&&f<end)set[f]=true;
                if(j>0&&keys[j-1].outType==='hold'&&f-1>=first&&f-1<end)set[f-1]=true;
            }
        }
        for(k in set)if(Object.prototype.hasOwnProperty.call(set,k))frames.push(Number(k));
        frames.sort(function(a,b){return a-b;});
        for(i=0;i<frames.length;i++)poses.push(M.pose(properties,frames[i]/fps));
        for(i=0;i<frames.length-1;i++) {
            from=frames[i];to=frames[i+1];r=poses[i+1].rotation-poses[i].rotation;
            curves={};for(j=0;j<4;j++){n=props[j];curves[n]=M.spanCurve(properties[n],from/fps,to/fps);}
            spans.push({from:from,to:to,kind:to-from>1?'classic-tween':'boundary-key',curves:curves,rotationDelta:r});
        }
        // Check analytic conversion against independently evaluated AE properties before host mutation.
        var ref,calc,error=0,d,maxRotationStep=0;
        for(i=first;i<end;i++) {
            ref=p.reference[i];calc=M.pose(properties,i/fps);
            for(j=0;j<2;j++) {error=Math.max(error,Math.abs(calc.position[j]-ref.position[j]));need(Math.abs(calc.scale[j]-ref.scale[j])<=0.01,'Scale easing conversion disagrees with AE at frame '+(i+1)+'.');}
            need(Math.abs(calc.rotation-ref.rotation)<=0.01&&Math.abs(calc.opacity-ref.opacity)<=0.01,'Easing conversion disagrees with AE at frame '+(i+1)+'.');
            if(i>first)maxRotationStep=Math.max(maxRotationStep,Math.abs(ref.rotation-p.reference[i-1].rotation));
        }
        need(error<=0.05,'Position easing conversion disagrees with AE; sampled native support is pending.');
        need(maxRotationStep<180,'Rotation changes 180° or more in one frame; unwrapped verification would be ambiguous.');
        return {build:build,totalFrames:total,first:first,end:end,frames:frames,poses:poses,spans:spans,representation:animated?'classic-tween':'held-frame',artwork:l.artwork.representation,sampling:animated?'original-keys-with-boundary-splits':'one-key-held-for-layer-duration',status:'host-verification-required'};
    }
    return {validate:function(p,build){return validate(p,build,false);},validateSource:function(p,build){return validate(p,build,true);},create:create};
}());
if(typeof module!=='undefined')module.exports=KTPlan;

var KTVerify = (function () {
    var M=typeof KTMath!=='undefined'?KTMath:require('./math');
    function compare(p,actual) {
        var max={position:0,scale:0,rotation:0,opacity:0,corners:0},failures=[],firstFailure=null,geometryPass=true,opacityPass=true,prevAngle=null,i,j,a,e,m,angle,sx,sy,pa,pe,d;
        function fail(f,kind,error) { if(kind==='opacity percentage points')opacityPass=false;else geometryPass=false; if(!firstFailure)firstFailure={frame:f+1,kind:kind,error:error};if(failures.length<30)failures.push({frame:f+1,kind:kind,error:error}); }
        if(actual.length!==p.reference.length)return {pass:false,status:'incomplete-readback',expected:p.reference.length,received:actual.length};
        var anchor=p.layer.properties.anchor.value,size=p.layer.artwork.size,origin=p.layer.artwork.origin||[0,0],points=[origin,[origin[0]+size[0],origin[1]],[origin[0],origin[1]+size[1]],[origin[0]+size[0],origin[1]+size[1]],anchor];
        for(i=0;i<actual.length;i++) {
            a=actual[i];e=p.reference[i];
            if(a.frame!==i||a.visible!==e.visible){fail(i,'timing/visibility',null);continue;}
            if(!e.visible)continue;
            m=a.matrix;
            if(!m||!isFinite(m.a+m.b+m.c+m.d+m.tx+m.ty)||typeof a.opacity!=='number'||!isFinite(a.opacity)){fail(i,'missing tween readback',null);continue;}
            pa=M.transform(m,anchor);d=Math.max(Math.abs(pa[0]-e.position[0]),Math.abs(pa[1]-e.position[1]));max.position=Math.max(max.position,d);if(d>0.5)fail(i,'position',d);
            sx=Math.sqrt(m.a*m.a+m.b*m.b)*100;sy=Math.sqrt(m.c*m.c+m.d*m.d)*100;
            d=Math.max(Math.abs(sx-e.scale[0]),Math.abs(sy-e.scale[1]));max.scale=Math.max(max.scale,d);if(d>0.1)fail(i,'scale percentage points',d);
            angle=Math.atan2(m.b,m.a)*180/Math.PI;
            if(prevAngle===null)angle+=360*Math.round((e.rotation-angle)/360);
            else angle+=360*Math.round((prevAngle-angle)/360);
            prevAngle=angle;d=Math.abs(angle-e.rotation);max.rotation=Math.max(max.rotation,d);if(d>0.1)fail(i,'unwrapped rotation degrees',d);
            d=Math.abs(a.opacity-e.opacity);max.opacity=Math.max(max.opacity,d);if(d>0.5)fail(i,'opacity percentage points',d);
            var expected=M.matrix(e.position,e.scale,e.rotation,anchor);
            for(j=0;j<points.length;j++){pa=M.transform(m,points[j]);pe=M.transform(expected,points[j]);d=Math.max(Math.abs(pa[0]-pe[0]),Math.abs(pa[1]-pe[1]));max.corners=Math.max(max.corners,d);if(d>0.5)fail(i,'artwork corner/anchor pixels',d);}
        }
        return {pass:failures.length===0,geometryPass:geometryPass,opacityPass:opacityPass,status:failures.length?'failed':'passed',frameCount:actual.length,maxErrors:max,firstFailure:firstFailure,failures:failures,tolerances:{position:0.5,scale:0.1,rotation:0.1,opacity:0.5,corners:0.5}};
    }
    return {compare:compare};
}());
if(typeof module!=='undefined')module.exports=KTVerify;

var KTTree=(function(){function flatten(items){var out=[];function walk(list,depth){if(depth>8)throw Error('Precomp nesting exceeds eight levels.');for(var i=0;i<list.length;i++){if(out.length>=200)throw Error('Transfer exceeds 200 nested layers.');var item=list[i];out.push(item);if(item.children)walk(item.children,depth+1);}}walk(items,0);return out;}return {flatten:flatten};}());
if(typeof module!=='undefined')module.exports=KTTree;

/* Batch envelope; every layer retains the existing transform/artwork contract. */
var KTBatchJSON=typeof KTJSON!=='undefined'?KTJSON:JSON;
var KTBatch=(function(){
 function validate(p,build){
  if(!p||p.schemaVersion!==2||p.build!==build||!p.items||!p.items.length||p.items.length>50||!(/^[a-z0-9-]+$/.test(p.sourceKey))||!(/^[a-z0-9-]+$/.test(p.id)))throw Error('Invalid batch envelope or build.');
  if(p.scope!=='selection'&&p.scope!=='composition')throw Error('Invalid batch scope.');
  var plans=[],total=0,count=0;
  function check(items,composition,depth){
   if(depth>8||!items||!items.length||items.length>50)throw Error('Invalid or too-deep nested composition.');var seen={},previous=0;
   for(var i=0;i<items.length;i++){var item=items[i];if(++count>200)throw Error('Transfer exceeds 200 nested layers.');
    if(!item.layer||!(/^[0-9]+$/.test(item.layer.id))||seen['$'+item.layer.id])throw Error('Duplicate or invalid source layer identity.');seen['$'+item.layer.id]=true;
    if(item.source.identity!==p.sourceKey||item.layer.stackingIndex<=previous)throw Error('Batch identity or stacking order differs.');previous=item.layer.stackingIndex;
    if(KTBatchJSON.stringify(item.composition)!==KTBatchJSON.stringify(composition))throw Error('Batch composition settings differ.');
    var plan=KTPlan.create(item,build);if(depth===0)plans.push(plan);total+=plan.totalFrames;
    if(item.layer.type==='symbol'){
     var a=item.layer.artwork,c=item.children&&item.children[0]&&item.children[0].composition;
     if(typeof item.layer.startTime!=='number'||!isFinite(item.layer.startTime)||Math.abs(item.layer.startTime*composition.fps-Math.round(item.layer.startTime*composition.fps))>1e-6||item.layer.inPoint<item.layer.startTime-1e-6||item.layer.outPoint>item.layer.startTime+a.duration+1e-6)throw Error('Invalid nested playback interval.');
     if(!c||c.width!==a.size[0]||c.height!==a.size[1]||c.duration!==a.duration||c.fps!==a.fps||c.fps!==composition.fps)throw Error('Nested symbol composition differs.');check(item.children,c,depth+1);
    }else if(item.children&&item.children.length)throw Error('Only symbols may contain child layers.');
   }
  }
  check(p.items,p.composition,0);
  if(total>90000)throw Error('Batch frame budget exceeded.');return plans;
 }
 return {validate:validate};
}());
if(typeof module!=='undefined'&&module.exports){var KTPlan=require('./plan');module.exports=KTBatch;}

/* ES3. AE exposes default Blending Options even when no layer style is applied. */
var KTLayerStyles = (function () {
    function inspect(group) {
        var out={present:!!group,enabled:false,styles:[],advanced:[],controls:[]},i,p;
        if(!group)return out;
        out.enabled=group.enabled!==false;
        // A disabled parent suppresses all its styles and blending options.
        if(group.canSetEnabled&&group.enabled===false)return out;
        for(i=1;i<=group.numProperties;i++) {
            p=group.property(i);
            out.controls.push({matchName:p.matchName,canSetEnabled:!!p.canSetEnabled,enabled:!!p.enabled});
            if(p.canSetEnabled&&p.enabled)out.styles.push(p.name||p.matchName);
        }
        function visit(parent) {
            var j,child,name,expected;
            for(j=1;j<=parent.numProperties;j++) {
                child=parent.property(j);name=child.matchName;expected=null;
                if(name==='ADBE Layer Fill Opacity2')expected=100;
                if(name==='ADBE R Channel Blend'||name==='ADBE G Channel Blend'||name==='ADBE B Channel Blend')expected=1;
                if(expected!==null&&(child.numKeys||child.expressionEnabled||Number(child.value)!==expected))
                    out.advanced.push(name);
                if(name==='ADBE Blend Ranges'&&(child.numKeys||child.expressionEnabled||child.isModified))out.advanced.push(name);
                if(child.numProperties)visit(child);
            }
        }
        visit(group);
        return out;
    }
    function check(group) {
        var result=inspect(group),e;
        if(result.styles.length||result.advanced.length) {
            e=Error(result.styles.length?'Enabled layer style is not supported yet: '+result.styles.join(', ')+'. Disable or remove it for the bitmap proof.':'Changed or animated advanced blending is not supported yet: '+result.advanced.join(', ')+'. Reset these controls for the bitmap proof.');
            e.details={layerStyles:result};throw e;
        }
        return result;
    }
    return {inspect:inspect,check:check};
}());
if(typeof module!=='undefined'&&module.exports)module.exports=KTLayerStyles;

/* Static shape contents, collected as editable Bezier contours and paint operations. */
var KTAEVectors = (function () {
    function value(p,label){if(!p)throw Error('Missing '+label+'.');if(p.numKeys||p.expressionEnabled)throw Error('Animated '+label+' is not supported. Whole-layer animation remains supported; artwork is never frozen silently.');return p.value;}
    function get(g,n,label,fallback){var p=g.property(n);if(!p&&typeof fallback!=='undefined')return fallback;return value(p,label||n);}
    function rgba(c){if(!c||(c.length!==3&&c.length!==4))throw Error('Shape color must have RGB or RGBA components.');return {color:[c[0],c[1],c[2]],alpha:c.length===4?c[3]:1};}
    function primitive(p){var name=p.matchName,out,size,pos,pre;
        if(name==='ADBE Vector Shape - Group'){var v=get(p,'ADBE Vector Shape','path geometry');return KTVector.path(v.vertices,v.inTangents,v.outTangents,v.closed);}
        if(name==='ADBE Vector Shape - Rect'||name==='ADBE Vector Shape - Ellipse'){pre=name==='ADBE Vector Shape - Rect'?'ADBE Vector Rect ':'ADBE Vector Ellipse ';size=get(p,pre+'Size','shape size');pos=get(p,pre+'Position','shape position');out=name==='ADBE Vector Shape - Rect'?KTVector.rectangle(size,pos,get(p,pre+'Roundness','corner roundness')):KTVector.ellipse(size,pos);}
        else if(name==='ADBE Vector Shape - Star'){var star=get(p,'ADBE Vector Star Type','polystar type')===1;
            if(get(p,'ADBE Vector Star Outer Roundess','outer roundness',0)!==0||(star&&get(p,'ADBE Vector Star Inner Roundess','inner roundness',0)!==0))throw Error('Rounded polystar points require conversion to a Bezier path before this build can preserve them.');
            out=KTVector.star(get(p,'ADBE Vector Star Points','polystar points'),get(p,'ADBE Vector Star Outer Radius','outer radius'),star?get(p,'ADBE Vector Star Inner Radius','inner radius'):0,get(p,'ADBE Vector Star Position','polystar position'),get(p,'ADBE Vector Star Rotation','polystar rotation'),star);
        }else return null;
        return get(p,'ADBE Vector Shape Direction','path direction',1)===2?KTVector.reverse(out):out;
    }
    function paint(p,paths){var stroke=p.matchName==='ADBE Vector Graphic - Stroke',pre=stroke?'ADBE Vector Stroke ':'ADBE Vector Fill ',c=rgba(get(p,pre+'Color','shape color'));
        if(get(p,'ADBE Vector Blend Mode','shape blend mode',1)!==1)throw Error('Non-Normal shape paint blending is not supported.');
        var composite=p.property('ADBE Vector Composite Order');if(composite){value(composite,'paint composite order');if(composite.isModified)throw Error('A custom Above/Below Previous paint composite override is not supported yet.');}
        var opacity=get(p,pre+'Opacity','paint opacity')/100*c.alpha,item={kind:'paint',paths:paths.slice(0),fill:null,stroke:null};
        if(!stroke){item.fill={color:c.color,opacity:opacity,rule:get(p,'ADBE Vector Fill Rule','fill rule',1)===2?'evenodd':'nonzero'};return item;}
        var dash=p.property('ADBE Vector Stroke Dashes'),dashes=[],offset=0,i,d,n;
        if(dash)for(i=1;i<=dash.numProperties;i++){d=dash.property(i);n=d.matchName;if(n==='ADBE Vector Stroke Offset')offset=value(d,'dash offset');else if(/^ADBE Vector Stroke (Dash|Gap) [123]$/.test(n))dashes.push(value(d,'dash length'));else throw Error('Unsupported stroke dash control: '+n);}
        var taper=p.property('ADBE Vector Stroke Taper'),wave=p.property('ADBE Vector Stroke Wave');
        if(taper&&(get(taper,'ADBE Vector Taper Start Length','taper start',0)!==0||get(taper,'ADBE Vector Taper End Length','taper end',0)!==0))throw Error('Variable-width stroke taper is not supported yet.');
        if(wave&&get(wave,'ADBE Vector Taper Wave Amount','stroke wave',0)!==0)throw Error('Variable-width stroke wave is not supported yet.');
        item.stroke={color:c.color,opacity:opacity,width:get(p,pre+'Width','stroke width'),cap:['butt','round','square'][get(p,pre+'Line Cap','stroke cap',1)-1],join:['miter','round','bevel'][get(p,pre+'Line Join','stroke join',1)-1],miter:get(p,pre+'Miter Limit','stroke miter',4),dashes:dashes,offset:offset};return item;
    }
    function extract(l,t){var count=0;
        function walk(contents,depth){if(depth>16)throw Error('Shape groups are nested too deeply.');var paths=[],nodes=[],i,j,p,n,g,tr,m,child,shape;
            for(i=1;i<=contents.numProperties;i++){p=contents.property(i);if(p.canSetEnabled&&p.enabled===false)continue;n=p.matchName;if(++count>4096)throw Error('Shape layer has too many contents.');
                if(n==='ADBE Vector Group'){
                    tr=p.property('ADBE Vector Transform Group');
                    if(get(p,'ADBE Vector Blend Mode','group blend mode',1)!==1)throw Error('Non-Normal shape-group blending is not supported.');
                    m=KTMath.matrix(get(tr,'ADBE Vector Position','group position'),get(tr,'ADBE Vector Scale','group scale'),get(tr,'ADBE Vector Rotation','group rotation'),get(tr,'ADBE Vector Anchor','group anchor'));
                    var skew=get(tr,'ADBE Vector Skew','group skew'),axis=get(tr,'ADBE Vector Skew Axis','skew axis',0);
                    if(skew){if(Math.abs(skew)>=89)throw Error('Shape skew is too close to a collapsed transform.');var anchor=get(tr,'ADBE Vector Anchor','group anchor'),pos=get(tr,'ADBE Vector Position','group position'),rotation=get(tr,'ADBE Vector Rotation','group rotation'),sc=get(tr,'ADBE Vector Scale','group scale');var sh=KTVector.identity();sh.c=-Math.tan(skew*Math.PI/180);m=KTMath.compose(KTMath.matrix(pos,[100,100],rotation+axis,[0,0]),KTMath.compose(sh,KTMath.matrix([0,0],sc,-axis,anchor)));}
                    child=walk(p.property('ADBE Vectors Group'),depth+1);for(j=0;j<child.paths.length;j++)paths.push(KTVector.transformed(child.paths[j],m));
                    nodes.push({kind:'group',matrix:m,opacity:get(tr,'ADBE Vector Group Opacity','group opacity')/100,children:child.nodes});
                }else if(n==='ADBE Vector Filter - Merge'){
                    var mode=get(p,'ADBE Vector Merge Type','Merge Paths mode');if(mode<1||mode>5)throw Error('Invalid Merge Paths mode.');
                    if(paths.length){if(mode!==1)paths=[{operation:'merge',mode:mode,paths:paths.slice(0)}];nodes=[];}
                }else if(n==='ADBE Vector Graphic - Fill'||n==='ADBE Vector Graphic - Stroke'){
                    if(paths.length)nodes.push(paint(p,paths));
                }else {shape=primitive(p);if(shape)paths.push(shape);else throw Error('Unsupported shape content: '+(p.name||n)+' ['+n+']. Paths, rectangles, ellipses, polygons, stars, groups, solid fills and strokes transfer as vectors. Other procedural operators and gradients need additional conversion; no bitmap fallback is used.');}
            }
            // AE Contents lists the top artwork first; SVG paints back-to-front.
            nodes.reverse();return {paths:paths,nodes:nodes};
        }
        var found=walk(l.property('ADBE Root Vectors Group'),0),root={kind:'group',matrix:KTVector.identity(),opacity:1,children:found.nodes};KTVector.validate(root);
        var bounds=l.sourceRectAtTime(t,true);if(!(bounds.width>0&&bounds.height>0))throw Error('The shape layer has no visible bounds.');
        return {type:'shape',artwork:{representation:'editable-vector','static':true,size:[bounds.width,bounds.height],origin:[bounds.left,bounds.top],vector:root},warnings:['Native vector geometry is preserved through local SVG import. Compare strokes, holes, overlaps and paint order in Animate; native type and layer motion checks do not prove rendered artwork fidelity.']};
    }
    return {extract:extract};
}());

/* Read-only source artwork extraction; unsupported content is never rasterized. */
var KTAEArtwork = (function () {
    function value(p,label) {if(!p)throw Error('Missing '+label+'.');if(p.numKeys||p.expressionEnabled)throw Error('Animated '+label+' is not supported. Animate the whole layer instead.');return p.value;}
    function get(g,name,label) {return value(g.property(name),label||name);}
    function identity(){return {a:1,b:0,c:0,d:1,tx:0,ty:0};}
    function rectangle(l,t) {var b=l.sourceRectAtTime(t,false);if(!(b.width>0&&b.height>0))throw Error('The selected artwork has no visible bounds.');return {origin:[b.left,b.top],size:[b.width,b.height]};}
    function text(l,t) {
        var group=l.property('ADBE Text Properties'),source=group.property('ADBE Text Document'),d=value(source,'source text'),animators=group.property('ADBE Text Animators');
        if(animators&&animators.numProperties)throw Error('Text animators are not supported. Animate the whole text layer.');
        var path=group.property('ADBE Text Path Options');if(path&&path.property('ADBE Text Path')&&get(path,'ADBE Text Path','text path')!==0)throw Error('Text on a path is not supported.');
        if(!d.pointText||!d.text||d.text.length>1000||/[\r\n\t]/.test(d.text))throw Error('Use a single line of point text, up to 1000 characters. Paragraph boxes and multiline text follow this prototype.');
        if(!d.characterRange)throw Error('This AE version cannot verify uniform text styling.');
        var style=d.characterRange(0,d.text.length),fields=['font','fontSize','applyFill','applyStroke','fillColor','fauxBold','fauxItalic','horizontalScale','verticalScale','baselineShift','tracking','allCaps','smallCaps','superscript','subscript'],i,n;
        for(i=0;i<fields.length;i++){n=fields[i];if(typeof style[n]==='undefined')throw Error('Mixed or unavailable text styling: '+n+'. Use one style for this prototype.');}
        if(!style.applyFill||style.applyStroke)throw Error('Use solid-filled text without a text stroke.');
        if(Math.abs(style.horizontalScale-1)>0.00001||Math.abs(style.verticalScale-1)>0.00001||style.baselineShift!==0||style.tracking!==0||style.allCaps||style.smallCaps||style.superscript||style.subscript){var error=Error('Set text character horizontal/vertical scale to 100%, tracking/baseline shift to zero, and caps/baseline to normal. Use Layer Transform Scale for sizing.');error.details={textStyle:{horizontalScaleFactor:style.horizontalScale,verticalScaleFactor:style.verticalScale,tracking:style.tracking,baselineShift:style.baselineShift,allCaps:style.allCaps,smallCaps:style.smallCaps,superscript:style.superscript,subscript:style.subscript}};throw error;}
        if(d.fontObject&&d.fontObject.isSubstitute)throw Error('The source font is missing in After Effects. Choose an installed font before transferring.');
        var align='left';if(d.justification===ParagraphJustification.CENTER_JUSTIFY)align='center';else if(d.justification===ParagraphJustification.RIGHT_JUSTIFY)align='right';else if(d.justification!==ParagraphJustification.LEFT_JUSTIFY)throw Error('Use left, center or right aligned point text.');
        var bounds=rectangle(l,t);
        return {type:'text',artwork:{representation:'editable-text','static':true,size:bounds.size,origin:bounds.origin,text:{content:d.text,font:style.font,fontFamily:d.fontFamily||style.font,fontStyle:d.fontStyle||'Regular',fontSize:style.fontSize,fill:style.fillColor,bold:!!style.fauxBold,italic:!!style.fauxItalic,alignment:align}},warnings:['Native text remains editable. Font metrics and baseline placement differ between AE and Animate; visual text-layout verification is required.']};
    }
    function extract(l,t) {if(l.property('ADBE Text Properties'))return text(l,t);if(l.property('ADBE Root Vectors Group'))return KTAEVectors.extract(l,t);return null;}
    return {extract:extract};
}());

/* Vector footage conversion runs only during an explicit transfer, never a scan. */
var KTAEVectorFiles = (function () {
    function accepts(src){return src&&src.file&&/\.(ai|svg|eps)$/i.test(src.file.name);}
    function describe(src){
        if(!accepts(src)||!src.file.exists)throw Error('Vector source file is missing.');
        if(!src.mainSource.isStill||src.pixelAspect!==1||src.useProxy)throw Error('Vector footage must be a square-pixel still without a proxy.');
        if(!(src.width>0&&src.height>0&&src.width<=32768&&src.height<=32768))throw Error('Vector source dimensions are unsupported.');
        return {file:src.file.fsName,name:src.name||src.file.name,id:String(src.id||''),size:[src.width,src.height],format:src.file.name.split('.').pop().toLowerCase(),modified:src.file.modified?src.file.modified.getTime():null,length:src.file.length};
    }
    function command(){if(typeof app.findMenuCommandId!=='function'||typeof app.executeCommand!=='function')throw Error('AE vector-to-shape command API is unavailable. Convert to shapes manually before transfer.');var id=app.findMenuCommandId('Create Shapes from Vector Layer');if(!id)throw Error('AE vector-to-shape command is unavailable in this version/language. Convert the footage with Layer > Create > Create Shapes from Vector Layer, then push the resulting shape layer.');return id;}
    function extract(sourceComp,l){
        var src=l.source,stamp=describe(src),cmd=command(),temp=null,result=null,problem=null,cleanup=[],viewer=app.activeViewer,selection=app.project.selection||[],selected=[],i;
        for(i=0;i<selection.length;i++)selected.push(selection[i]);
        app.beginUndoGroup('KeyTween: Convert vector artwork');
        try{
            temp=app.project.items.addComp('KeyTween temporary vector conversion',src.width,src.height,1,1,sourceComp.frameRate);
            var input=temp.layers.add(src),tr=input.property('ADBE Transform Group');
            tr.property('ADBE Anchor Point').setValue([0,0]);tr.property('ADBE Position').setValue([0,0]);tr.property('ADBE Scale').setValue([100,100]);tr.property('ADBE Rotate Z').setValue(0);tr.property('ADBE Opacity').setValue(100);
            input.selected=true;temp.time=0;var focus=temp.openInViewer();if(!focus||focus.setActive()===false||app.project.activeItem!==temp)throw Error('Could not focus the isolated vector conversion composition.');
            app.executeCommand(cmd);
            var shape=null,count=0;
            for(i=1;i<=temp.numLayers;i++){var candidate=temp.layer(i);if(candidate===input)continue;if(!candidate.property('ADBE Root Vectors Group'))throw Error('Vector conversion produced non-shape artwork. Outline text and remove embedded raster content in the source.');shape=candidate;count++;}
            if(count!==1||!shape)throw Error('AE did not produce exactly one shape layer. Convert/expand this source to supported vector paths first.');
            if(shape.property('ADBE Mask Parade').numProperties||shape.property('ADBE Effect Parade').numProperties)throw Error('Converted vector uses masks or effects that KeyTween cannot preserve yet.');
            KTLayerStyles.check(shape.property('ADBE Layer Styles'));
            result=KTAEVectors.extract(shape,0);
            tr=shape.property('ADBE Transform Group');
            function fixed(n){var p=tr.property(n);if(!p||p.numKeys||p.expressionEnabled)throw Error('Converted vector has an unexpected animated transform.');return p.value;}
            var m=KTMath.matrix(fixed('ADBE Position'),fixed('ADBE Scale'),fixed('ADBE Rotate Z'),fixed('ADBE Anchor Point')),alpha=fixed('ADBE Opacity')/100,a=result.artwork,o=a.origin,s=a.size;
            // Convert the new shape's local coordinates back into original footage coordinates.
            var corners=[[o[0],o[1]],[o[0]+s[0],o[1]],[o[0],o[1]+s[1]],[o[0]+s[0],o[1]+s[1]]],minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;
            for(i=0;i<corners.length;i++){var x=corners[i][0],y=corners[i][1],px=m.a*x+m.c*y+m.tx,py=m.b*x+m.d*y+m.ty;minX=Math.min(minX,px);minY=Math.min(minY,py);maxX=Math.max(maxX,px);maxY=Math.max(maxY,py);}
            a.origin=[minX,minY];a.size=[maxX-minX,maxY-minY];a.vector={kind:'group',matrix:m,opacity:alpha,children:[a.vector]};KTArtwork.validate({type:'shape',artwork:a});
            var after=describe(src);if(after.modified!==stamp.modified||after.length!==stamp.length)throw Error('Vector source changed during conversion. Refresh footage and push again.');
            result.vectorSource=stamp;result.warnings.push(stamp.format.toUpperCase()+' converted by AE to editable vector paths. Check source appearance: AE conversion may omit unsupported source features; no raster fallback is used.');
        }catch(e){problem=e;}
        finally{
            if(temp)try{temp.remove();}catch(removeError){cleanup.push('temporary composition removal failed: '+String(removeError.message||removeError));}
            try{for(i=0;i<selected.length;i++)selected[i].selected=true;sourceComp.openInViewer();if(viewer)viewer.setActive();}catch(focusError){cleanup.push('viewer restoration failed: '+String(focusError.message||focusError));}
            app.endUndoGroup();
        }
        if(cleanup.length)throw Error((problem?String(problem.message||problem)+'; ':'')+cleanup.join('; '));
        if(problem)throw problem;return result;
    }
    return {accepts:accepts,describe:describe,extract:extract};
}());

/* Render only an owned single-frame queue item; never alter project colour settings. */
var KTAERaster=(function(){
 function ready(){var q=app.project.renderQueue;if(!q||!q.items||typeof q.items.add!=='function'||typeof q.render!=='function')throw Error('AE render queue is unavailable for PSD PNG export.');if(q.rendering)throw Error('Wait until the current AE render has finished before transferring PSD artwork.');}
 function render(comp,time,options,label){
  ready();if(!options.renderFolder)throw Error('PSD export needs the panel working-files staging folder.');
  var folder=new Folder(options.renderFolder);if(!folder.exists)throw Error('PSD render staging folder is unavailable.');
  var q=app.project.renderQueue,owned=null,prior=[],i,om,settings,templates,chosen=null;
  var basename='psd-'+String(comp.id)+'-'+String(options.counter.value++),output=new File(folder.fsName+'/'+basename+'.png');
  if(output.exists)throw Error('PSD render output already exists.');
  var report={engine:'AE-render-queue',frame:Math.round(time*comp.frameRate),workingSpace:app.project.workingSpace||'',linear:!!app.project.linearizeWorkingSpace,depth:app.project.bitsPerChannel,colorEngine:app.project.colorManagementSystem||'Adobe color managed',requireEmbeddedProfile:app.project.bitsPerChannel===32&&!!app.project.workingSpace||!!app.project.linearizeWorkingSpace||!!app.project.workingSpace&&!/^sRGB IEC61966-2\.1$/i.test(app.project.workingSpace)||!!app.project.colorManagementSystem&&!/Adobe/i.test(String(app.project.colorManagementSystem))};
  try{
   for(i=1;i<=q.numItems;i++){var item=q.item(i);if(item.render){prior.push(item);item.render=false;}}
   owned=q.items.add(comp);owned.render=false;owned.setSettings({'Quality':'Best','Resolution':'Full'});owned.timeSpanStart=time;owned.timeSpanDuration=1/comp.frameRate;
   // Format/alpha are read-only in ExtendScript; select and verify an existing template.
   om=owned.outputModule(1);templates=om.templates;var ordered=[],j;
   for(i=0;i<templates.length;i++)if(templates[i]==='_HIDDEN X-Factor 8')ordered.push(templates[i]);
   for(i=0;i<templates.length;i++)if(templates[i]!=='_HIDDEN X-Factor 8')ordered.push(templates[i]);
   for(i=0;i<ordered.length;i++){
    om=owned.outputModule(1);om.applyTemplate(ordered[i]);om=owned.outputModule(1);settings=om.getSettings(GetSettingsFormat.STRING);
    if(/PNG/i.test(String(settings.Format))&&/RGB.*Alpha/i.test(String(settings.Channels))&&/Straight|Unmatted/i.test(String(settings.Color))){chosen=ordered[i];break;}
   }
   if(!chosen)throw Error('AE has no PNG output template with RGB + Alpha and Straight (Unmatted) colour. Save a PNG template with these settings and embedded sRGB profile in the render queue.');
   // Where the host exposes colour settings, request sRGB; never guess read-only keys.
   var settable=om.getSettings(GetSettingsFormat.STRING_SETTABLE),changes={};
   if(Object.prototype.hasOwnProperty.call(settable,'Output Color Profile'))changes['Output Color Profile']='sRGB IEC61966-2.1';
   if(Object.prototype.hasOwnProperty.call(settable,'Embed Color Profile'))changes['Embed Color Profile']=true;
   if(Object.prototype.hasOwnProperty.call(settable,'Convert To Linear Light'))changes['Convert To Linear Light']='Off';
   for(j in changes)if(Object.prototype.hasOwnProperty.call(changes,j)){om.setSetting(j,changes[j]);om=owned.outputModule(1);}
   om.postRenderAction=PostRenderAction.NONE;om.file=output;owned.render=true;
   if(Math.abs(owned.timeSpanDuration-1/comp.frameRate)>1e-7)throw Error('AE did not retain the single-frame render range.');
   q.render();if(owned.status!==RQItemStatus.DONE)throw Error('AE did not finish the PSD PNG render.');
   if(!output.exists){var files=folder.getFiles(),matches=[];for(i=0;i<files.length;i++)if(files[i] instanceof File&&new RegExp('^'+basename+'(?:\\[[0-9]+\\]|[0-9]+)?\\.png(?:[0-9]+)?$','i').test(files[i].name))matches.push(files[i]);if(matches.length!==1)throw Error('AE did not create exactly one PSD PNG.');output=matches[0];}
   report.template=chosen;settings=owned.outputModule(1).getSettings(GetSettingsFormat.STRING);report.outputSettings={};for(j in settings)if(Object.prototype.hasOwnProperty.call(settings,j)&&/^(Format|Channels|Depth|Color|Output Color Profile|Embed Color Profile|Convert To Linear Light|Preserve RGB)$/.test(j))report.outputSettings[j]=settings[j];
   if(report.requireEmbeddedProfile&&options.colorReferenceFile&&!options.skipColorProof){
    owned.render=false;
    if(!options.colorProofCache)options.colorProofCache={};
    if(!Object.prototype.hasOwnProperty.call(options.colorProofCache,chosen))options.colorProofCache[chosen]=colourProof(options,report);
    report.colorProof=options.colorProofCache[chosen];
   }
   return {file:output.fsName,report:report};
  }finally{
   var cleanup=null;try{if(owned)owned.remove();}catch(e){cleanup=e;}for(i=0;i<prior.length;i++){try{prior[i].render=true;}catch(e){cleanup=e;}}if(cleanup)throw Error('PSD export cleanup failed: '+String(cleanup.message||cleanup));
  }
 }
 function colourProof(options,report){
  var input=null,temp=null;
  try{
   var source=new File(options.colorReferenceFile);if(!source.exists)throw Error('Colour-reference source is unavailable.');
   input=app.project.importFile(new ImportOptions(source));
   if(input.width!==256||input.height!==16)throw Error('Unexpected colour-reference dimensions.');
   temp=app.project.items.addComp('KeyTween colour verification',256,16,1,1,30);temp.layers.add(input);
   var rendered=render(temp,0,{renderFolder:options.renderFolder,counter:options.counter,skipColorProof:true},'Colour reference');
   if(rendered.report.template!==report.template)throw Error('Colour-reference output template differs from artwork.');
   return {schema:1,file:rendered.file,template:report.template,workingSpace:report.workingSpace,linear:report.linear,depth:report.depth};
  }finally{try{if(temp)temp.remove();}finally{if(input)input.remove();}}
 }
 function footage(src,layer,options){
  ready();var temp=null,rendered=null;
  function still(p,depth){if(!p)return;if(depth>32)throw Error('PSD effects/style hierarchy is too deep.');if(p.numKeys||p.expressionEnabled)throw Error('Animated PSD effects, masks or styles cannot be preserved in one PNG. Place the layer inside an animated precomp to retain its timeline.');for(var n=1;n<=p.numProperties;n++)still(p.property(n),depth+1);}
  if(layer.property){still(layer.property('ADBE Mask Parade'),0);still(layer.property('ADBE Effect Parade'),0);still(layer.property('ADBE Layer Styles'),0);}
  try{
   if(!options.inspect){
    temp=app.project.items.addComp('KeyTween PSD export '+String(src.id),src.width,src.height,1,1,30);
    layer.copyToComp(temp);var copy=temp.layer(1),tr=copy.property('ADBE Transform Group'),names=['ADBE Anchor Point','ADBE Position','ADBE Scale','ADBE Rotate Z','ADBE Opacity'],values=[[src.width/2,src.height/2],[src.width/2,src.height/2],[100,100],0,100];
    copy.startTime=0;copy.inPoint=0;copy.outPoint=1;copy.stretch=100;copy.enabled=true;copy.solo=false;copy.guideLayer=false;
    for(var i=0;i<names.length;i++){var p=tr.property(names[i]);while(p.numKeys)p.removeKey(p.numKeys);p.expressionEnabled=false;var value=values[i];if(value instanceof Array&&p.value&&p.value.length>value.length){value=value.slice(0);while(value.length<p.value.length)value.push(names[i]==='ADBE Scale'?100:0);}p.setValue(value);}
    rendered=render(temp,0,options,layer.name);
   }
   return {type:'bitmap',artwork:{representation:'raster-artwork','static':true,size:[src.width,src.height],origin:[0,0],trimOffset:[0,0]},sourceFile:rendered?rendered.file:null,flattenedPSD:{sourceFile:src.file.fsName,footageId:String(src.id),frame:0,internalLayers:1,render:rendered?rendered.report:null},warnings:['PSD footage baked by AE as one PNG. Source interpretation and Photoshop appearance are rendered before verified sRGB conversion.']};
  }finally{if(temp)temp.remove();}
 }
 return {ready:ready,render:render,footage:footage};
}());

/* Source precomps remain untouched. Only explicit export may render a static PSD comp. */
var KTAEPrecomps=(function(){
 function psd(comp){var file=null,count=0,visited=0;function walk(c,depth){if(depth>8||++visited>200)return false;for(var i=1;i<=c.numLayers;i++){var l=c.layer(i);if(!l.enabled||l.guideLayer)continue;var src=l.source;if(src&&typeof src.numLayers==='number'){if(!walk(src,depth+1))return false;continue;}if(!src||!src.file||!(/\.psd$/i.test(src.file.name)))return false;if(file&&file!==src.file.fsName)return false;file=src.file.fsName;count++;}return true;}return walk(comp,0)&&count>0;}
 function still(comp,nesting){nesting=nesting||0;if(nesting>8)throw Error('PSD nesting exceeds eight levels.');var count=0;function walk(p,depth){if(!p)return;if(++count>50000||depth>32)throw Error('PSD precomp exceeds the static inspection limit.');if(p.expressionEnabled||p.numKeys)throw Error('PSD precomp has internal animation or expressions; one PNG cannot preserve them.');for(var j=1;j<=p.numProperties;j++)walk(p.property(j),depth+1);}
  for(var i=1;i<=comp.numLayers;i++){var l=comp.layer(i);if(!l.enabled||l.guideLayer)continue;if(l.inPoint>0||l.outPoint<comp.duration||l.timeRemapEnabled)throw Error('PSD precomp has changing internal visibility/timing; one PNG cannot preserve it.');walk(l,0);if(l.source&&typeof l.source.numLayers==='number')still(l.source,nesting+1);}
 }
 function extract(parent,l,options,exportLayer){
  var comp=l.source,depth=options.depth||0,seen=options.seen||[],i,children=[],child;
  if(depth>=8)throw Error('Precomp nesting exceeds eight levels.');for(i=0;i<seen.length;i++)if(seen[i]===comp.id)throw Error('Cyclic precomp reference.');
  if(comp.displayStartTime&&comp.displayStartTime!==0)throw Error('Precomp display start must be zero.');
  if(l.timeRemapEnabled)throw Error('Precomp time remapping is not supported.');
  if(l.collapseTransformation)throw Error('Collapsed precomp transformations are not supported. Disable Collapse Transformations.');
  if(comp.pixelAspect!==1||l.stretch!=null&&l.stretch!==100)throw Error('Precomps require matching FPS, square pixels and 100% time stretch.');
  if(Math.abs(l.startTime*parent.frameRate-Math.round(l.startTime*parent.frameRate))>1e-6)throw Error('Precomp start time must align to a frame.');
  if(l.inPoint<l.startTime-1e-6||l.outPoint>l.startTime+comp.duration+1e-6)throw Error('Precomp visibility extends outside its source timeline. Trim the layer to its source duration.');
  if(psd(comp)){
   var staticError=null;try{still(comp);}catch(e){staticError=e;}
   if(!staticError){KTAERaster.ready();var rendered=null;if(!options.inspect)rendered=KTAERaster.render(comp,0,options,l.name);
    return {type:'bitmap',artwork:{representation:'raster-artwork','static':true,size:[comp.width,comp.height],origin:[0,0]},sourceFile:rendered?rendered.file:null,flattenedPSD:{compositionId:String(comp.id),frame:0,internalLayers:comp.numLayers,render:rendered?rendered.report:null},warnings:['PSD composition baked by AE as one PNG, including internal layer styles. Outer layer animation remains native; PNG output is converted and verified as sRGB.']};
   }
  }
  if(comp.frameRate!==parent.frameRate)throw Error('Animated precomps require matching FPS (30 fps).');
  var next={inspect:options.inspect,depth:depth+1,seen:seen.concat([comp.id]),renderFolder:options.renderFolder,colorReferenceFile:options.colorReferenceFile,colorProofCache:options.colorProofCache,counter:options.counter,budget:options.budget};
  var visible=0;for(i=1;i<=comp.numLayers;i++)if(comp.layer(i).enabled&&!comp.layer(i).guideLayer)visible++;if(visible>50)throw Error('Precomp exceeds 50 visible child layers.');
  for(i=1;i<=comp.numLayers;i++){child=comp.layer(i);if(!child.enabled||child.guideLayer)continue;try{children.push(exportLayer(comp,child,next));}catch(e){throw Error('Inside '+l.name+' → layer '+i+' ('+child.name+'): '+String(e.message||e));}}
  if(!children.length)throw Error('Precomp has no visible transferable child layers.');
  return {type:'symbol',artwork:{representation:'editable-symbol','static':false,size:[comp.width,comp.height],origin:[0,0],duration:comp.duration,fps:comp.frameRate},children:children,warnings:['Precomp retained as a synchronized graphic symbol with editable child layers. Compare clipping and nested playback in Animate.']};
 }
 return {extract:extract,isPSD:psd,checkStatic:still};
}());

/* Loaded after the shared ES3 modules. Every entry reports its running build. */
var KeyTweenAE = (function () {
    var BUILD='0.1.0-dev.20';
    function info() {
        var permission=null;
        try { permission=app.preferences.getPrefAsLong('Main Pref Section','Pref_SCRIPTING_FILE_NETWORK_SECURITY')===1; } catch(e) {}
        return {build:BUILD,host:'After Effects',version:app.version,fileWritePermission:permission};
    }
    function interpolation(t) { if(t===KeyframeInterpolationType.HOLD)return 'hold';if(t===KeyframeInterpolationType.LINEAR)return 'linear';return 'bezier'; }
    function ease(e) { var out=[],i;for(i=0;i<e.length;i++)out.push({speed:e[i].speed,influence:e[i].influence});return out; }
    function property(p,spatial) {
        if(p.expressionEnabled)throw Error('Expressions are not supported. Disable the expression before transfer.');
        var out={value:p.value,keys:[],expression:false,spatial:spatial},i,k,a,b;
        for(i=1;i<=p.numKeys;i++) {
            k={time:p.keyTime(i),value:p.keyValue(i),inType:interpolation(p.keyInInterpolationType(i)),outType:interpolation(p.keyOutInterpolationType(i)),inEase:ease(p.keyInTemporalEase(i)),outEase:ease(p.keyOutTemporalEase(i)),autoBezier:p.keyTemporalAutoBezier(i),roving:false};
            if(spatial) {
                k.roving=p.keyRoving(i);a=p.keyInSpatialTangent(i);b=p.keyOutSpatialTangent(i);
                k.spatialIn=a;k.spatialOut=b;
                k.spatialLinear=Math.abs(a[0])+Math.abs(a[1])+Math.abs(b[0])+Math.abs(b[1])<1e-7;
            }
            out.keys.push(k);
        }
        return out;
    }
    function exportLayer(comp,l,options) {
        options=options||{};if(!options.colorProofCache)options.colorProofCache={};if(!options.counter)options.counter={value:0};
        if(!options.budget)options.budget={layers:0,frames:0};options.budget.layers++;options.budget.frames+=Math.ceil(comp.duration*comp.frameRate-1e-7);
        if(options.budget.layers>200||options.budget.frames>90000)throw Error('Transfer exceeds 200 nested layers or 90,000 layer-frames. Transfer a smaller selection.');
        var src=l.source,psdFootage=src instanceof FootageItem&&src.file&&/\.psd$/i.test(src.file.name),trans=l.property('ADBE Transform Group');
        if(!trans||!l.property('ADBE Mask Parade')||!l.property('ADBE Effect Parade'))throw Error('Camera, light and non-artwork layers are not supported.');
        if(l.nullLayer)throw Error('Null layers are not transferable artwork.');

        if(!l.enabled)throw Error('Hidden layers are excluded from transfer. Enable the layer to transfer it.');
        if(l.guideLayer)throw Error('Guide layers are excluded from transfer.');
        if(l.adjustmentLayer)throw Error('Adjustment layers are not supported.');
        if(l.threeDLayer||l.parent)throw Error('Parented and 3D layers are not supported in this prototype.');
        if(l.blendingMode!==BlendingMode.NORMAL||l.hasTrackMatte||l.isTrackMatte)throw Error('Blend modes and track mattes are not supported.');
        if(!psdFootage&&(l.property('ADBE Mask Parade').numProperties||l.property('ADBE Effect Parade').numProperties))throw Error('Masks and effects require artwork fallback, which is not enabled yet.');
        if(l.timeRemapEnabled||l.motionBlur)throw Error('Time remapping and layer motion blur are not supported.');
        if(!psdFootage)KTLayerStyles.check(l.property('ADBE Layer Styles'));
        if(comp.pixelAspect!==1)throw Error('Use a square-pixel composition.');
        checkExpressions(l);
        var extracted=null;if(src instanceof CompItem)extracted=KTAEPrecomps.extract(comp,l,options,exportLayer);else extracted=KTAEArtwork.extract(l,Math.max(0,l.inPoint));
        if(!extracted&&KTAEVectorFiles.accepts(src)){
            if(options.inspect){extracted={type:'bitmap',artwork:{representation:'raster-artwork','static':true,size:[src.width,src.height],origin:[0,0]},vectorSource:KTAEVectorFiles.describe(src),pendingVector:true,warnings:[]};}
            else extracted=KTAEVectorFiles.extract(comp,l);
        }
        if(!extracted){
        if(!(src instanceof FootageItem)||!src.file||!src.file.exists||!src.mainSource.isStill||!(/\.(png|jpe?g|psd|tiff?)$/i.test(src.file.name)))throw Error('Select an AI/SVG/EPS vector, PNG/JPEG/PSD/TIFF still, single-style point text, or a static vector shape layer.');
        var psdSource=null;
        if(/\.psd$/i.test(src.file.name)){
            var fileName=decodeURIComponent(src.file.name),sourceName=src.name||'',suffix='/'+fileName,prefix=fileName+'/';
            if(sourceName===fileName)psdSource={mode:'merged'};
            else if(sourceName.slice(-suffix.length)===suffix)psdSource={mode:'layer',name:sourceName.slice(0,-suffix.length)};
            else if(sourceName.slice(0,prefix.length)===prefix)psdSource={mode:'layer',name:sourceName.slice(prefix.length)};
            else psdSource={mode:'ae-footage',name:sourceName};
        }
        if(src.pixelAspect!==1)throw Error('Use square-pixel artwork and composition.');
        if(src.useProxy)throw Error('Disable source proxies before this proof.');
        if(src.mainSource.invertAlpha&&!psdFootage)throw Error('Inverted alpha is not supported.');
        if(typeof AlphaMode!=='undefined'&&src.mainSource.alphaMode===AlphaMode.PREMULTIPLIED&&!psdSource)throw Error('Premultiplied alpha requires a separate interpretation test. Use straight alpha.');
            if(psdFootage)extracted=KTAERaster.footage(src,l,options);
            else extracted={type:'bitmap',artwork:{representation:'raster-artwork','static':true,size:[src.width,src.height],origin:[0,0],trimOffset:[0,0]},sourceFile:src.file.fsName,psdSource:psdSource,warnings:['Image exported as sRGB PNG; compare AE footage color interpretation visually.']};
        }
        var pos=trans.property('ADBE Position'),scale=trans.property('ADBE Scale'),rotation=trans.property('ADBE Rotate Z'),opacity=trans.property('ADBE Opacity'),anchor=trans.property('ADBE Anchor Point');
        if(pos.dimensionsSeparated)throw Error('Separated position dimensions require sampled native support in a later build.');
        if(anchor.numKeys||anchor.expressionEnabled)throw Error('Use a static anchor for the first proof.');
        var properties={position:property(pos,true),scale:property(scale,false),rotation:property(rotation,false),opacity:property(opacity,false),anchor:property(anchor,false)};
        var total=Math.ceil(comp.duration*comp.frameRate-1e-7),reference=[],i,t,visible,s,p,r,o;
        if(total>18000)throw Error('Prototype limit: 18,000 frames.');
        for(i=0;!options.inspect&&i<total;i++) {
            t=i/comp.frameRate;visible=t>=l.inPoint-1e-7&&t<l.outPoint-1e-7;
            p=pos.valueAtTime(t,false);s=scale.valueAtTime(t,false);r=rotation.valueAtTime(t,false);o=opacity.valueAtTime(t,false);
            reference.push({frame:i,time:t,visible:visible,position:[p[0],p[1]],scale:[s[0],s[1]],rotation:r,opacity:o});
        }
        // AE returns 3D arrays for 2D scale/anchor in some versions; normalize deliberately.
        function two(p) {p.value=[p.value[0],p.value[1]];for(var j=0;j<p.keys.length;j++)p.keys[j].value=[p.keys[j].value[0],p.keys[j].value[1]];}
        two(properties.position);two(properties.scale);two(properties.anchor);
        return {schemaVersion:1,build:BUILD,timeDomain:'composition-relative-seconds',target:{kind:'new-matching'},source:{host:'After Effects',version:app.version,projectId:app.project.file?app.project.file.name:'unsaved-project',compositionId:String(comp.id)},scope:'selected',composition:{name:comp.name,width:comp.width,height:comp.height,pixelAspect:comp.pixelAspect,fps:comp.frameRate,duration:comp.duration,displayStart:comp.displayStartTime,rangeStart:0,rangeEnd:comp.duration,background:comp.bgColor},layer:{id:String(l.id||l.index),name:l.name,stackingIndex:l.index,type:extracted.type,startTime:l.startTime,inPoint:l.inPoint,outPoint:l.outPoint,artwork:extracted.artwork,properties:properties},reference:reference,sourceFile:extracted.sourceFile||null,psdSource:extracted.psdSource||null,vectorSource:extracted.vectorSource||null,pendingVector:!!extracted.pendingVector,flattenedPSD:extracted.flattenedPSD||null,children:extracted.children||null,warnings:extracted.warnings};
    }
    function checkExpressions(l){
        var visited=0;
        function walk(g,depth){if(!g)return;if(++visited>20000||depth>32)throw Error('Layer property tree exceeds the compatibility scan limit.');if(g.expressionEnabled)throw Error('Expressions are not supported: '+(g.name||g.matchName||'property')+'.');if(g.numProperties)for(var i=1;i<=g.numProperties;i++)walk(g.property(i),depth+1);}
        walk(l,0);
    }
    function compatibility(){
        var comp=app.project&&app.project.activeItem,rows=[],i,l,p;
        if(!(comp instanceof CompItem))return {build:BUILD,composition:null,rows:[],reason:'Open a composition to check compatibility.'};
        if(comp.numLayers>500)return {build:BUILD,composition:{id:String(comp.id),name:comp.name},rows:[],reason:'Compatibility scan limit: 500 layers. Check a smaller composition.'};
        var nestedCount=0,nestedFrames=0;var visible=0;for(i=1;i<=comp.numLayers;i++)if(comp.layer(i).enabled&&!comp.layer(i).guideLayer)visible++;
        var reason=null;if(comp.frameRate!==30)reason='Composition is '+comp.frameRate+' fps. Set the After Effects composition to 30 fps before transfer; Animate will use 30 fps.';if(visible>50||visible*Math.ceil(comp.duration*comp.frameRate)>90000)reason='Composition transfer exceeds 50 layers or 90,000 layer-frames. Transfer a smaller selection.';
        for(i=1;i<=comp.numLayers;i++){
            l=comp.layer(i);var row={index:i,name:l.name,id:String(l.id||i),status:'supported',reason:null};
            try{p=exportLayer(comp,l,{inspect:true});var checked=KTTree.flatten([p]);for(var ci=0;ci<checked.length;ci++){KTPlan.validateSource(checked[ci],BUILD);nestedCount++;nestedFrames+=Math.ceil(checked[ci].composition.duration*checked[ci].composition.fps);}if(nestedCount>200||nestedFrames>90000)reason='Composition including precomp children exceeds 200 layers or 90,000 layer-frames. Transfer a smaller selection.';
                if(Math.min(comp.duration,l.outPoint)<=Math.max(0,l.inPoint))throw Error('Layer has no visible frames inside the composition.');
                row.vector=p.layer.type==='shape'?p.layer.artwork.vector:null;row.sourceFile=p.sourceFile;row.psdSource=p.psdSource;row.size=p.layer.artwork.size;row.vectorSource=p.vectorSource;row.children=[];var nested=KTTree.flatten(p.children||[]);for(var ni=0;ni<nested.length;ni++){var nc=nested[ni];row.children.push({index:nc.layer.stackingIndex,name:nc.layer.name,status:nc.pendingVector?'pending':'supported',sourceFile:nc.sourceFile,psdSource:nc.psdSource,size:nc.layer.artwork.size,vectorSource:nc.vectorSource,vector:nc.layer.type==='shape'?nc.layer.artwork.vector:null});}if(p.flattenedPSD){row.status='pending';row.reason='PSD artwork will be baked as one sRGB PNG during transfer.';}
                if(p.pendingVector){row.status='pending';row.reason='Vector contents require AE conversion during Push/Pull. The read-only scan does not convert your project.';}
            }catch(e){row.status='unsupported';row.reason=String(e.message||e);}
            rows.push(row);
        }
        return {build:BUILD,composition:{id:String(comp.id),name:comp.name,width:comp.width,height:comp.height,fps:comp.frameRate},rows:rows,reason:reason};
    }
    function exportSelection(args) {
        var comp=app.project&&app.project.activeItem;
        if(!(comp instanceof CompItem))throw Error('Open the source composition in AE.');
        if(comp.frameRate!==30)throw Error('Composition is '+comp.frameRate+' fps. Set it to 30 fps before transfer.');
        if(!args.scope){if(comp.selectedLayers.length!==1)throw Error('Select one layer or use a batch scope.');return exportLayer(comp,comp.selectedLayers[0],args);}
        if(args.scope!=='selection'&&args.scope!=='composition')throw Error('Invalid export scope.');
        var layers=[],items=[],warnings=[],i,l;
        if(args.scope==='selection')layers=comp.selectedLayers;
        else for(i=1;i<=comp.numLayers;i++){l=comp.layer(i);if(l.enabled&&!l.guideLayer)layers.push(l);else warnings.push('Excluded hidden/guide layer '+i+': '+l.name);}
        if(!layers.length)throw Error('No visible layers to transfer.');
        if(layers.length>50||layers.length*Math.ceil(comp.duration*comp.frameRate)>90000)throw Error('Prototype batch limit: 50 layers and 90,000 total sampled layer-frames.');
        for(i=0;i<layers.length;i++){
            try{items.push(exportLayer(comp,layers[i],args));}
            catch(e){e.message='Layer '+layers[i].index+' ('+layers[i].name+'): '+e.message;throw e;}
        }
        // A persisted marker survives renaming/moving the AE file. Comp ID distinguishes duplicates.
        var comment=comp.comment||'',match=/\[KeyTween:([a-z0-9-]+)\]/.exec(comment),token;
        if(match)token=match[1];else {token=(new Date().getTime()).toString(36)+'-'+Math.floor(Math.random()*1000000000).toString(36);comp.comment=comment+(comment?'\n':'')+'[KeyTween:'+token+']';}
        var all=KTTree.flatten(items);for(i=0;i<all.length;i++)all[i].source.identity=token+'-'+comp.id;
        items.sort(function(a,b){return a.layer.stackingIndex-b.layer.stackingIndex;});
        return {schemaVersion:2,build:BUILD,scope:args.scope,sourceKey:token+'-'+comp.id,composition:items[0].composition,items:items,warnings:warnings};
    }
    function example(args) {
        var file=new File(args.asset);if(!file.exists)throw Error('Bundled test image is missing. Reinstall the prototype.');
        app.beginUndoGroup('KeyTween: Load Test Example');
        try {
            var comp=app.project.items.addComp('KeyTween — Test example '+BUILD,300,250,1,10,30);
            var footage=app.project.importFile(new ImportOptions(file)),l=comp.layers.add(footage),tr=l.property('ADBE Transform Group');
            l.name='Product — bitmap proof';l.inPoint=0.5;l.outPoint=9;
            tr.property('ADBE Anchor Point').setValue([40,25]);
            function keys(p,times,values,kind) {
                var i,j,eins,eouts,dim;
                for(i=0;i<times.length;i++)p.setValueAtTime(times[i],values[i]);
                for(i=1;i<=p.numKeys;i++) {
                    p.setInterpolationTypeAtKey(i,KeyframeInterpolationType.LINEAR,KeyframeInterpolationType.LINEAR);
                    if(kind==='position') {
                        p.setSpatialAutoBezierAtKey(i,false);p.setSpatialContinuousAtKey(i,false);
                        // A 2D layer can expose a ThreeD_SPATIAL property in AE.
                        // Match the host's tangent vectors, not the layer's 2D flag.
                        var incoming=p.keyInSpatialTangent(i),outgoing=p.keyOutSpatialTangent(i),axis;
                        for(axis=0;axis<incoming.length;axis++)incoming[axis]=0;
                        for(axis=0;axis<outgoing.length;axis++)outgoing[axis]=0;
                        p.setSpatialTangentsAtKey(i,incoming,outgoing);
                    }
                    if(args.easing==='easy'||args.easing==='asymmetric') {
                        dim=p.keyInTemporalEase(i).length;eins=[];eouts=[];
                        for(j=0;j<dim;j++){eins.push(new KeyframeEase(0,args.easing==='asymmetric'?55:33.333333));eouts.push(new KeyframeEase(0,args.easing==='asymmetric'?20:33.333333));}
                        p.setTemporalEaseAtKey(i,eins,eouts);
                        p.setInterpolationTypeAtKey(i,KeyframeInterpolationType.BEZIER,KeyframeInterpolationType.BEZIER);
                        p.setTemporalAutoBezierAtKey(i,false);
                    }
                }
            }
            keys(tr.property('ADBE Position'),[0.5,3,5,8.5],[[70,65],[160,90],[160,90],[90,160]],'position');
            keys(tr.property('ADBE Scale'),[0.5,4,8.5],[[60,80],[85,45],[45,65]],'scale');
            keys(tr.property('ADBE Rotate Z'),[0.5,8.5],[0,450],'rotation');
            keys(tr.property('ADBE Opacity'),[0.5,2,6,8.5],[0,100,100,40],'opacity');
            if(args.easing==='hold') {
                var op=tr.property('ADBE Opacity');op.setInterpolationTypeAtKey(2,KeyframeInterpolationType.LINEAR,KeyframeInterpolationType.HOLD);
                op.setValueAtKey(3,65);
            }
            var square=comp.layers.addShape(),contents=square.property('ADBE Root Vectors Group');
            square.name='Square — scale test';square.inPoint=0.5;square.outPoint=9;
            contents.addProperty('ADBE Vector Shape - Rect');
            contents.addProperty('ADBE Vector Graphic - Fill');
            // Reacquire indexed properties after addProperty invalidates their old references.
            contents.property('ADBE Vector Shape - Rect').property('ADBE Vector Rect Size').setValue([44,44]);
            contents.property('ADBE Vector Graphic - Fill').property('ADBE Vector Fill Color').setValue([1,0.72,0.3]);
            square.property('ADBE Transform Group').property('ADBE Position').setValue([245,48]);
            keys(square.property('ADBE Transform Group').property('ADBE Scale'),[0.5,4,8.5],[[70,70],[135,135],[85,85]],'scale');
            var text=comp.layers.addText('KeyTween'),textProp=text.property('ADBE Text Properties').property('ADBE Text Document'),doc=textProp.value;
            text.name='Text — rotation test';text.inPoint=0.5;text.outPoint=9;
            if(doc.resetCharStyle)doc.resetCharStyle();doc.font='ArialMT';doc.fontSize=18;doc.fauxBold=false;doc.fauxItalic=false;doc.horizontalScale=1;doc.verticalScale=1;doc.baselineShift=0;doc.tracking=0;doc.applyFill=true;doc.fillColor=[0.88,0.92,1];doc.applyStroke=false;
            doc.justification=ParagraphJustification.CENTER_JUSTIFY;textProp.setValue(doc);
            var rect=text.sourceRectAtTime(1,false),textTr=text.property('ADBE Transform Group');
            textTr.property('ADBE Anchor Point').setValue([rect.left+rect.width/2,rect.top+rect.height/2]);
            textTr.property('ADBE Scale').setValue([100,100]);
            textTr.property('ADBE Position').setValue([235,190]);
            keys(textTr.property('ADBE Rotate Z'),[0.5,8.5],[0,360],'rotation');
            if(args.easing==='vectors'){
                var curved=comp.layers.addShape(),vc=curved.property('ADBE Root Vectors Group');curved.name='Path — curved vector test';curved.inPoint=0.5;curved.outPoint=9;
                vc.addProperty('ADBE Vector Shape - Group');vc.addProperty('ADBE Vector Graphic - Stroke');vc.addProperty('ADBE Vector Graphic - Fill');
                var contour=new Shape();contour.vertices=[[-35,-20],[30,-20],[35,20],[-30,25]];contour.inTangents=[[0,0],[-18,-25],[0,0],[0,0]];contour.outTangents=[[18,-25],[0,0],[0,0],[0,0]];contour.closed=true;
                vc.property('ADBE Vector Shape - Group').property('ADBE Vector Shape').setValue(contour);
                vc.property('ADBE Vector Graphic - Fill').property('ADBE Vector Fill Color').setValue([0.25,0.7,0.85]);
                vc.property('ADBE Vector Graphic - Stroke').property('ADBE Vector Stroke Color').setValue([0.95,0.95,1]);
                vc.property('ADBE Vector Graphic - Stroke').property('ADBE Vector Stroke Width').setValue(3);
                curved.property('ADBE Transform Group').property('ADBE Position').setValue([75,185]);
                keys(curved.property('ADBE Transform Group').property('ADBE Scale'),[0.5,4,8.5],[[70,70],[115,115],[85,85]],'scale');
            }
            if(args.easing==='precomps'){var childComp=comp;comp=app.project.items.addComp('KeyTween Precomp Proof '+BUILD,300,250,1,10,30);comp.bgColor=childComp.bgColor;l=comp.layers.add(childComp);l.name='Precomp — editable child timelines';l.inPoint=0;l.outPoint=10;var preTr=l.property('ADBE Transform Group');preTr.property('ADBE Anchor Point').setValue([150,125]);preTr.property('ADBE Position').setValue([150,125]);keys(preTr.property('ADBE Scale'),[0,4,9],[[100,100],[70,70],[100,100]],'scale');}
            var i;for(i=1;i<=comp.numLayers;i++)comp.layer(i).selected=false;
            l.selected=true;comp.time=1;comp.selected=true;
            var viewer=null,active=null,activationReturn=null,warnings=[];
            try {
                viewer=comp.openInViewer();
                if(viewer){var focused=viewer.setActive();if(typeof focused==='boolean')activationReturn=focused;if(typeof viewer.active==='boolean')active=viewer.active;}
            } catch(focusError) {warnings.push('The example was created, but bringing its viewer forward reported: '+String(focusError.message||focusError));}
            if(!viewer)warnings.push('Open '+comp.name+' in the Project panel. Product is already selected.');
            else if(active!==true&&activationReturn!==true)warnings.push('The composition viewer opened. Focus was not confirmed; click its tab if needed.');
            return {build:BUILD,host:info(),example:args.easing||'linear',compositionId:String(comp.id),created:true,viewerOpened:!!viewer,viewerActive:active,activationReturn:activationReturn,warnings:warnings,layers:['bitmap: transform proof','native AE square: scale','native AE text: rotation'].concat(args.easing==='vectors'?['native AE curved path: scale']:[]),message:(args.easing==='precomps'?'Precomp test created with editable bitmap, square and text child timelines. ':'')+'Test composition created: bitmap, scaling square and rotating text. Select any combination for Push Selection, or use Push Composition. '+(warnings.length?warnings.join(' '):'Viewer opened.')};
        } finally {app.endUndoGroup();}
    }
    function dispatch(action,args) {
        try {
            args=args||{};if(args.build&&args.build!==BUILD)throw Error('AE host script build mismatch. Reopen the panel.');
            // ExtendScript has a documented nested-conditional evaluation defect.
            // Explicit branches keep the setup handshake strictly read-only.
            var data=null;
            if(action==='info')data=info();
            else if(action==='example')data=example(args);
            else if(action==='export')data=exportSelection(args);
            else if(action==='compatibility')data=compatibility();
            else if(action==='composition-info'){var active=app.project&&app.project.activeItem;data={composition:active&&active instanceof CompItem?{id:String(active.id),width:active.width,height:active.height}:null};}
            if(action==='choose-folder'){var folder=Folder.selectDialog(args.purpose==='images'?'Choose where to store images linked in Animate':'Choose an empty KeyTween working folder');data={path:folder?folder.fsName:null};}
            if(!data)throw Error('Unknown AE action.');return KTJSON.stringify({ok:true,build:BUILD,action:action,data:data});
        } catch(e) {return KTJSON.stringify({ok:false,build:BUILD,error:String(e.message||e),line:e.line||null,details:e.details||null});}
    }
    return {dispatch:dispatch,dispatchJSON:function(action,argsJSON){return dispatch(action,KTJSON.parse(argsJSON));}};
}());

KeyTweenAE;
