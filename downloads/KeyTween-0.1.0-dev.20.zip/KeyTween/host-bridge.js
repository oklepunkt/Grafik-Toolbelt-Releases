'use strict';

// This function is serialized into the Adobe engine. Keep it strict ES3, including
// error handling: a broken bundle must not also break the bootstrap error report.
function hostEntry(host, scriptPath, action, argsJSON, requestId, build) {
    var phase = 'bootstrap', reply, api;
    function quote(value) {
        return '"' + String(value).replace(/["\\\x00-\x1f\u2028\u2029]/g, function (c) {
            return '\\u' + ('0000' + c.charCodeAt(0).toString(16)).slice(-4);
        }) + '"';
    }
    function envelope(ok, text, line) {
        return '{"bridge":1,"requestId":' + quote(requestId) + ',"build":' + quote(build) +
            ',"host":' + quote(host) + ',"phase":' + quote(phase) + ',"ok":' + (ok ? 'true' : 'false') +
            (ok ? ',"reply":' : ',"error":') + quote(text) + ',"line":' + (Number(line) || 0) + '}';
    }
    try {
        if (host === 'AEFT') {
            phase = 'load-script';
            var file = new File(scriptPath);
            if (!file.exists) throw Error('The installed AE script is missing. Reinstall KeyTween.');
            api = $.evalFile(file);
            if (!api || typeof api.dispatchJSON !== 'function') throw Error('The AE script did not return its entry point. Close and reopen both KeyTween panels.');
            phase = 'dispatch';
            reply = api.dispatchJSON(action, argsJSON);
        } else if (host === 'FLPR') {
            phase = 'load-and-dispatch';
            if (!FLfile.exists(scriptPath)) throw Error('The installed Animate script is missing. Reinstall KeyTween.');
            reply = fl.runScript(scriptPath, 'KeyTweenANDispatch', action, argsJSON);
        } else throw Error('Unsupported Adobe application.');
        if (typeof reply !== 'string' || !reply.length) throw Error('The host script returned no result. Do not repeat an import until its test document has been inspected.');
        return envelope(true, reply, 0);
    } catch (e) {
        return envelope(false, String(e.message || e), e.line || e.lineNumber || 0);
    }
}

function literal(value) {
    return JSON.stringify(value).replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
}

function expression(host, scriptPath, action, args, requestId, build) {
    if (host !== 'AEFT' && host !== 'FLPR') throw Error('Unsupported Adobe application.');
    // A single explicitly returning expression preserves the result through CEP.
    const values = [host, scriptPath, action, JSON.stringify(Object.assign({}, args, {build})), requestId, build];
    return '(' + hostEntry.toString() + ')(' + values.map(literal).join(',') + ')';
}

function decode(response, request, record) {
    const hostName = request.host === 'AEFT' ? 'After Effects' : 'Animate';
    record.responseType = typeof response;
    record.responseLength = typeof response === 'string' ? response.length : 0;
    function fail(code, message) {
        record.code = code;
        const error = Error(message);
        error.bridge = Object.assign({}, record);
        throw error;
    }
    if (typeof response !== 'string' || !response.trim()) {
        record.phase = 'host-transport';
        fail('EMPTY_HOST_REPLY', hostName + ' returned an empty response to “' + request.action + '”. Close and reopen both KeyTween panels, then run Check Setup. If it repeats, copy diagnostics.');
    }
    let outer;
    try { outer = JSON.parse(response); }
    catch (e) {
        record.phase = 'host-transport';
        fail('NON_JSON_HOST_REPLY', hostName + ' could not return the host-script result for “' + request.action + '”. Copy Diagnostics includes the response type and length.');
    }
    if (!outer || outer.bridge !== 1 || outer.requestId !== request.requestId || outer.host !== request.host || outer.build !== request.build || typeof outer.ok !== 'boolean') {
        fail('BRIDGE_PROTOCOL_MISMATCH', 'The host response does not match this request/build. Close and reopen both panels.');
    }
    record.phase = outer.phase;
    record.bootstrapResponded = true;
    if (!outer.ok) {
        record.line = outer.line || null;
        fail('HOST_BOOTSTRAP_FAILED', hostName + ' failed during ' + outer.phase + ': ' + outer.error + (outer.line ? ' (host line ' + outer.line + ')' : ''));
    }
    let result;
    try { result = JSON.parse(outer.reply); }
    catch (e) { fail('INVALID_SCRIPT_REPLY', 'The host script returned an invalid response during “' + request.action + '”. Copy diagnostics before retrying.'); }
    if (!result || typeof result.ok !== 'boolean') fail('INVALID_SCRIPT_REPLY', 'The host script returned an incomplete response.');
    record.scriptBuild = result.build;
    if (result.build !== request.build) fail('SCRIPT_BUILD_MISMATCH', 'Mixed build detected. Close and reopen both KeyTween panels.');
    record.hostScriptResponded = true;
    if (!result.ok) {
        record.line = result.line || null;
        record.details = result.details || null;
        fail('HOST_ACTION_FAILED', hostName + ': ' + result.error + (result.line ? ' (host line ' + result.line + ')' : ''));
    }
    if (result.data === null || typeof result.data !== 'object') fail('INVALID_SCRIPT_REPLY', 'The host script returned no action data.');
    record.code = 'OK';
    return result.data;
}

function call(options) {
    const started = Date.now();
    const record = {action:options.action, requestId:options.requestId, host:options.host, build:options.build, phase:'host-transport', hostScriptResponded:false};
    return new Promise((resolve, reject) => {
        let settled = false;
        function finish(error, data) {
            if (settled) return;
            settled = true;
            record.elapsedMs = Date.now() - started;
            if (options.onRecord) { try { options.onRecord(Object.assign({}, record)); } catch (ignored) {} }
            if (error) { error.bridge = Object.assign({}, record); reject(error); }
            else resolve(data);
        }
        try {
            const code = expression(options.host, options.scriptPath, options.action, options.args, options.requestId, options.build);
            options.evalScript(code, response => {
                if (settled) return;
                try { finish(null, decode(response, options, record)); }
                catch (error) { finish(error); }
            });
        } catch (error) { record.code = 'BRIDGE_INVOCATION_FAILED'; finish(error); }
        // Deliberately no automatic retry: a lost reply may follow a successful mutation.
    });
}

module.exports = {expression, decode, call};
